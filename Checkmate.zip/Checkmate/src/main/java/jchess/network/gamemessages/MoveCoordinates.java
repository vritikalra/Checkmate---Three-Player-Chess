package jchess.network.gamemessages;

import java.io.Serializable;

public class MoveCoordinates implements Serializable {
    
    private int beginX;
    private int beginY;
    private int endX;
    private int endY;
    
    public MoveCoordinates(int beginX, int beginY, int endX, int endY) {
        this.beginX = beginX;
        this.beginY = beginY;
        this.endX = endX;
        this.endY = endY;
    }
    
    public int getBeginX() {
        return beginX;
    }
    
    public int getBeginY() {
        return beginY;
    }
    
    public int getEndX() {
        return endX;
    }
    
    public int getEndY() {
        return endY;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MoveCoordinates that = (MoveCoordinates) o;
        return beginX == that.beginX &&
                beginY == that.beginY &&
                endX == that.endX &&
                endY == that.endY;
    }
    
    @Override
    public String toString() {
        return "MoveCoordinates{" +
                "beginX=" + beginX +
                ", beginY=" + beginY +
                ", endX=" + endX +
                ", endY=" + endY +
                '}';
    }
}
