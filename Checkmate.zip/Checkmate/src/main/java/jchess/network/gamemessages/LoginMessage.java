package jchess.network.gamemessages;

import java.io.Serializable;
import java.util.Objects;

public class LoginMessage implements Serializable {
    private int gameId;
    private boolean isObserver;
    private String nick;
    private String encryptedGamePassword;
    
    public LoginMessage(int gameId, boolean isObserver, String nick, String encryptedGamePassword) {
        this.gameId = gameId;
        this.isObserver = isObserver;
        this.nick = nick;
        this.encryptedGamePassword = encryptedGamePassword;
    }
    
    public int getGameId() {
        return gameId;
    }
    
    public boolean isObserver() {
        return isObserver;
    }
    
    public String getNick() {
        return nick;
    }
    
    public String getEncryptedGamePassword() {
        return encryptedGamePassword;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LoginMessage that = (LoginMessage) o;
        return gameId == that.gameId &&
                isObserver == that.isObserver &&
                Objects.equals(nick, that.nick) &&
                Objects.equals(encryptedGamePassword, that.encryptedGamePassword);
    }
    
    @Override
    public String toString() {
        return "LoginMessage{" +
                "gameId=" + gameId +
                ", isObserver=" + isObserver +
                ", nick='" + nick + '\'' +
                ", encryptedGamePassword='" + encryptedGamePassword + '\'' +
                '}';
    }
}
