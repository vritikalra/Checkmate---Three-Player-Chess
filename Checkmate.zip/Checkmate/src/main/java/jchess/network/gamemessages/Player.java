/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.network.gamemessages;

import jchess.gamelogic.shared.PlayerColor;

import java.io.Serializable;
import java.util.Objects;


/**
 * Class representing the player in the game
 */
public class Player implements Serializable {

    public String name;
    public PlayerColor color;
    private boolean alive; // speed chess

    public enum playerTypes {

        localUser, networkUser, computer
    }

    public playerTypes playerType;
    public boolean goDown;


    public Player(String name, PlayerColor color) {
        this.name = name;
        this.color = color;
        this.goDown = false;
        this.alive = true;
    }

    /**
     * Method setting the players name
     *
     * @param name name of player
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Method getting the players name
     *
     * @return name of player
     */
    public String getName() {
        return this.name;
    }

    /**
     * Method setting the players type
     *
     * @param type type of player - enumerate
     */
    public void setType(playerTypes type) {
        this.playerType = type;
    }

    /**
     * @return true if the player is alive, otherwise false (speed chess only)
     */
    public boolean isAlive() {
        return alive;
    }

    /**
     * sets whether or not the player is alive
     * @param alive true if the player is alive
     */
    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return goDown == player.goDown &&
                Objects.equals(name, player.name) &&
                color == player.color &&
                playerType == player.playerType;
    }
    
}
