package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Reads game messages from an ObjectInputStream and calls the respective functions on listeners implementing the
 * GameMessageListener interface. Reading and propagating the game messages will only be done when listeners are
 * registered in order not to loose a message.
 */
public class NetworkGameMessagePushReader implements GameMessagePushReader {
    
    private static final long TIMEOUT_MS = 20_1000;
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private ObjectInputStream input;
    private Thread readThread = null;
    private final ArrayList<GameMessageListener> listeners = new ArrayList<>();
    private Lock waitForListenerLock = new ReentrantLock();
    
    interface GameMessageReceiverFunction {
        void accept(GameMessageListener gameMessageListener) throws IOException, ClassNotFoundException;
    }
    
    public NetworkGameMessagePushReader(ObjectInputStream input) {
        this.input = input;
    
        waitForListenerLock.lock();
    }
    
    @Override
    public void addGameMessageListener(GameMessageListener receiver) {
        synchronized (listeners) {
            listeners.add(receiver);
        }
    
        waitForListenerLock.unlock();
        
        if (readThread == null)
            startReading();
    }
    
    @Override
    public void removeGameMessageListener(GameMessageListener receiver) {
        synchronized (listeners) {
            listeners.remove(receiver);
        }
    
        if (listeners.isEmpty())
            waitForListenerLock.lock();
    }
    
    private void startReading() {
        readThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.interrupted()) {
                    handleMessage();
                }
            }
            
            private void handleMessage() {
                try {
                    String messageIdentifier = input.readUTF();
                    
                    handleMessage(messageIdentifier);
                } catch (IOException | ClassNotFoundException | TimeoutException e) {
                    try {
                        notifyListeners(receiver -> receiver.connectionExceptionOccurred(e));
                    } catch (IOException | ClassNotFoundException | TimeoutException e2) {
                        LOGGER.log(Level.WARNING, "Unexpected IOException calling local function", e2);
                    }
                }
            }
            
            private void handleMessage(String messageIdentifier) throws IOException, ClassNotFoundException, TimeoutException {
                switch (messageIdentifier) {
                    case "#message":
                        notifyListeners(receiver -> receiver.receiveChatMessage(input.readUTF()));
                        break;
                    case "#connectionInfo":
                        notifyListeners(receiver -> receiver.receiveConnectionInfo((ConnectionInfo) input.readObject()));
                        break;
                    case "#errorConnection":
                        notifyListeners(GameMessageListener::receiveErrorConnection);
                        break;
                    case "#login":
                        notifyListeners(receiver -> receiver.receiveLoginMessage((LoginMessage) input.readObject()));
                        break;
                    case "#move":
                        notifyListeners(receiver -> receiver.receiveMove((MoveCoordinates) input.readObject()));
                        break;
                    case "#settings":
                        notifyListeners(receiver -> receiver.receiveSettings((Settings) input.readObject()));
                        break;
                    case "#undoAsk":
                        notifyListeners(GameMessageListener::receiveUndoAsk);
                        break;
                    case "#undoAnswerPositive":
                        notifyListeners(GameMessageListener::receiveUndoPositive);
                        break;
                    case "#undoAnswerNegative":
                        notifyListeners(GameMessageListener::receiveUndoNegative);
                        break;
                }
            }
            
            private void notifyListeners(GameMessageReceiverFunction function) throws IOException, ClassNotFoundException, TimeoutException {
                waitForListeners();
                
                synchronized (listeners) {
                    for (GameMessageListener listener : listeners) {
                        function.accept(listener);
                    }
                }
            }
            
            private void waitForListeners() throws TimeoutException {
                try {
                    if (!waitForListenerLock.tryLock(TIMEOUT_MS, TimeUnit.MILLISECONDS))
                        throw new TimeoutException();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        readThread.start();
    }
    
    @Override
    public void close() throws Exception {
        synchronized (this) {
            if (readThread != null) {
                readThread.interrupt();
                readThread = null;
            }
        }
        input.close();
    }
}
