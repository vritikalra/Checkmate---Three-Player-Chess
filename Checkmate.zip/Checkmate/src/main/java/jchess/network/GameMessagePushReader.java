package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

public interface GameMessagePushReader extends AutoCloseable {
    
    interface GameMessageListener {
        void receiveChatMessage(String message);
        
        void receiveConnectionInfo(ConnectionInfo connectionInfo);
        
        void receiveErrorConnection();
        
        void receiveLoginMessage(LoginMessage loginMessage);
        
        void receiveMove(MoveCoordinates move);
        
        void receiveSettings(Settings settings);
        
        void receiveUndoAsk();
        
        void receiveUndoPositive();
        
        void receiveUndoNegative();
        
        /**
         * An error occurred while trying to read from the InputStream.
         */
        void connectionExceptionOccurred(Exception e);
    }
    
    void addGameMessageListener(GameMessageListener listener);
    
    void removeGameMessageListener(GameMessageListener listener);
    
}
