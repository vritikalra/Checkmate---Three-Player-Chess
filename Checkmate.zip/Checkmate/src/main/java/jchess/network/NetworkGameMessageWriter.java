package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.io.ObjectOutputStream;

public class NetworkGameMessageWriter implements GameMessageWriter {
    
    private ObjectOutputStream output;
    
    public NetworkGameMessageWriter(ObjectOutputStream output) {
        this.output = output;
    }
    
    @Override
    public void writeChatMessage(String message) throws IOException {
        output.writeUTF("#message");
        output.writeUTF(message);
        output.flush();
    }
    
    @Override
    public void writeConnectionInfo(ConnectionInfo connectionInfo) throws IOException {
        output.writeUTF("#connectionInfo");
        output.writeObject(connectionInfo);
        output.flush();
    }
    
    @Override
    public void writeErrorConnection() throws IOException {
        output.writeUTF("#errorConnection");
        output.flush();
    }
    
    @Override
    public void writeLoginMessage(LoginMessage message) throws IOException {
        output.writeUTF("#login");
        output.writeObject(message);
        output.flush();
    }
    
    @Override
    public void writeMove(MoveCoordinates move) throws IOException {
        output.writeUTF("#move");
        output.writeObject(move);
        output.flush();
    }
    
    @Override
    public void writeSettings(Settings settings) throws IOException {
        output.writeUTF("#settings");
        output.writeObject(settings);
        output.flush();
    }
    
    @Override
    public void writeUndoAsk() throws IOException {
        output.writeUTF("#undoAsk");
        output.flush();
    }
    
    @Override
    public void writeUndoPositive() throws IOException {
        output.writeUTF("#undoAnswerPositive");
        output.flush();
    }
    
    @Override
    public void writeUndoNegative() throws IOException {
        output.writeUTF("#undoAnswerNegative");
        output.flush();
    }
    
    @Override
    public void close() throws Exception {
        output.close();
    }
}
