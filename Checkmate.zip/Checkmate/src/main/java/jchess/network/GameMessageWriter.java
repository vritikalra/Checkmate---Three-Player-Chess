package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;

public interface GameMessageWriter extends AutoCloseable {
    
    interface GameMessageWriterFunction {
        void write(GameMessageWriter writer) throws IOException;
    }
    
    void writeChatMessage(String message) throws IOException;
    
    void writeConnectionInfo(ConnectionInfo connectionInfo) throws IOException;
    
    void writeErrorConnection() throws IOException;
    
    void writeLoginMessage(LoginMessage message) throws IOException;
    
    void writeMove(MoveCoordinates move) throws IOException;
    
    void writeSettings(Settings settings) throws IOException;
    
    void writeUndoAsk() throws IOException;
    
    void writeUndoPositive() throws IOException;
    
    void writeUndoNegative() throws IOException;
    
}
