/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.client;

import jchess.MultiLanguage;
import jchess.gui.gameview.Chat;
import jchess.gui.gameview.GameView;
import jchess.network.GameMessagePushReader;
import jchess.network.GameMessageWriter;
import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import javax.swing.JOptionPane;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class responsible for encapsulating message handling to and from the server.
 */
public class Client implements GameMessagePushReader.GameMessageListener, Chat.MessageTarget, AutoCloseable {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private Socket socket;
    private GameMessagePushReader gameMessagePushReader;
    private GameMessageWriter gameMessageWriter;
    private String nick;
    public GameView gameView;
    private boolean wait4undoAnswer = false;
    private boolean isObserver = false;
    
    public Client(Socket socket, GameMessagePushReader gameMessagePushReader, GameMessageWriter gameMessageWriter, String nick) {
        this.socket = socket;
        this.gameMessagePushReader = gameMessagePushReader;
        this.gameMessageWriter = gameMessageWriter;
        this.nick = nick;
    }
    
    public void startListening() {
        gameMessagePushReader.addGameMessageListener(this);
    }
    
    /**
     *  Method responsible for sending the move which was taken by a player
     */
    void sendMove(int beginX, int beginY, int endX, int endY) //sending new move to server
    {
        LOGGER.fine("running function: sendMove(" + beginX + ", " + beginY + ", " + endX + ", " + endY + ")");
        try {
            gameMessageWriter.writeMove(new MoveCoordinates(beginX, beginY, endX, endY));
        } catch (IOException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            close();
        }
    }
    
    void sendUndoAsk() {
        LOGGER.fine("sendUndoAsk");
        try {
            this.wait4undoAnswer = true;
            gameMessageWriter.writeUndoAsk();
        } catch (IOException exc) {
            LOGGER.log(Level.SEVERE, null, exc);
            close();
        }
    }
    
    private void sendUndoAnswerPositive() {
        try {
            gameMessageWriter.writeUndoPositive();
        } catch (IOException exc) {
            LOGGER.log(Level.SEVERE, null, exc);
            close();
        }
    }
    
    private void sendUndoAnswerNegative() {
        try {
            gameMessageWriter.writeUndoNegative();
        } catch (IOException exc) {
            LOGGER.log(Level.SEVERE, null, exc);
            close();
        }
    }
    
    /**
     * Method responsible for sending to the server information about
     * moves of a player
     */
    public void sendMassage(String str) //sending new move to server
    {
        LOGGER.fine("running function: sendMessage(" + str + ")");
        try {
            gameMessageWriter.writeChatMessage(str);
        } catch (IOException ex) {
            LOGGER.log(Level.SEVERE, null, ex);
            close();
        }
    }
    
    @Override
    public void receiveChatMessage(String message) {
        gameView.getChat().addMessage(message);
    }
    
    @Override
    public void receiveConnectionInfo(ConnectionInfo connectionInfo) {
        LOGGER.warning("Unexpected connection info message for " + nick + ": " + connectionInfo);
    }
    
    @Override
    public void receiveErrorConnection() {
        gameView.getChat().addMessage("** " + MultiLanguage.get("error_connecting_one_of_player") + " **");
    }
    
    @Override
    public void receiveLoginMessage(LoginMessage loginMessage) {
        LOGGER.warning("Unexpected login message for " + nick + ": " + loginMessage);
    }
    
    @Override
    public void receiveMove(MoveCoordinates move) {
        //game.simulateMove(move.getBeginX(), move.getBeginY(), move.getEndX(), move.getEndY());
    }
    
    @Override
    public void receiveSettings(Settings settings) {
        gameView.setSettings(settings);
        
        // TODO: this will collide with the other client for local games
        gameView.getChat().setMessageTarget(this);
        
        // TODO: this will collide with the other client for local games, both are starting the game
        //game.newGame();//start new Game
    }
    
    @Override
    public void receiveUndoAsk() {
        if (this.isObserver)
            return;
        
        int result = JOptionPane.showConfirmDialog(
                null,
                MultiLanguage.get("your_oponent_plase_to_undo_move_do_you_agree"),
                MultiLanguage.get("confirm_undo_move"),
                JOptionPane.YES_NO_OPTION
        );
        
        if (result == JOptionPane.YES_OPTION) {
            //game.chessboardView.undo();
            //game.switchActive();
            this.sendUndoAnswerPositive();
        } else {
            this.sendUndoAnswerNegative();
        }
    }
    
    @Override
    public void receiveUndoPositive() {
        if (!(this.wait4undoAnswer || this.isObserver))
            return;
        
        this.wait4undoAnswer = false;
        //String lastMove = game.historyTable.getMoves().get(game.historyTable.getMoves().size() - 1);
        //game.chat.addMessage("** " + MultiLanguage.get("permission_ok_4_undo_move") + ": " + lastMove + "**");
        //game.chessboardView.undo();
    }
    
    @Override
    public void receiveUndoNegative() {
        if (!this.wait4undoAnswer)
            return;
    
        gameView.getChat().addMessage(MultiLanguage.get("no_permission_4_undo_move"));
    }
    
    @Override
    public void connectionExceptionOccurred(Exception e) {
        gameView.getChat().addMessage("** " + MultiLanguage.get("error_connecting_to_server") + " **");
        LOGGER.log(Level.SEVERE, null, e);
        close();
    }
    
    @Override
    public void close() {
        try {
            if (gameMessagePushReader != null)
                gameMessagePushReader.close();
            if (gameMessageWriter != null)
                gameMessageWriter.close();
            if (socket != null)
                socket.close();
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing connection to server", e);
        }
    }
}
