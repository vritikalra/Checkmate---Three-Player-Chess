package jchess.gui.client;

import jchess.network.GameMessagePushReader;
import jchess.network.GameMessageWriter;
import jchess.network.NetworkGameMessagePushReader;
import jchess.network.NetworkGameMessageWriter;
import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Client handling the login message and response (ConnectionInfo)
 */
public class JoinClient implements GameMessagePushReader.GameMessageListener, AutoCloseable {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private LoginMessage loginMessage;
    private JoinStatusUpdate joinStatusUpdate;
    
    private Socket socket = null;
    private GameMessagePushReader gameMessagePushReader = null;
    private GameMessageWriter gameMessageWriter = null;
    
    public interface JoinStatusUpdate {
        void successfullyJoined(Client client);
        
        void connectionExceptionOccurred(Exception e);
    }
    
    public JoinClient(String ip, int port, LoginMessage loginMessage, JoinStatusUpdate joinStatusUpdate) {
        this.loginMessage = loginMessage;
        this.joinStatusUpdate = joinStatusUpdate;
        
        try {
            socket = new Socket(ip, port);
            gameMessagePushReader = new NetworkGameMessagePushReader(new ObjectInputStream(socket.getInputStream()));
            gameMessageWriter = new NetworkGameMessageWriter(new ObjectOutputStream(socket.getOutputStream()));
            
            gameMessagePushReader.addGameMessageListener(this);
            
            gameMessageWriter.writeLoginMessage(loginMessage);
        } catch (IOException e) {
            close();
            joinStatusUpdate.connectionExceptionOccurred(e);
        }
    }
    
    @Override
    public void receiveConnectionInfo(ConnectionInfo connectionInfo) {
        LOGGER.fine("receiveConnectionInfo for " + loginMessage.getNick() + ": " + connectionInfo);
        gameMessagePushReader.removeGameMessageListener(this);
        
        if (connectionInfo != ConnectionInfo.ALL_IS_OK) {
            joinStatusUpdate.connectionExceptionOccurred(new ConnectException("Response from server indicates a problem: " + connectionInfo.name()));
            close();
            return;
        }
        
        joinStatusUpdate.successfullyJoined(new Client(socket, gameMessagePushReader, gameMessageWriter, loginMessage.getNick()));
    }
    
    @Override
    public void close() {
        try {
            if (gameMessageWriter != null)
                gameMessageWriter.close();
            if (gameMessagePushReader != null)
                gameMessagePushReader.close();
            if (socket != null)
                socket.close();
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing connection to server", e);
        }
    }
    
    private void endConnectionDueToWrongMessage() {
        LOGGER.warning("Connection info expected but received message of another type");
        joinStatusUpdate.connectionExceptionOccurred(new ConnectException("Connection info expected but received message of another type"));
        close();
    }
    
    @Override
    public void receiveChatMessage(String message) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveLoginMessage(LoginMessage loginMessage) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveErrorConnection() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveMove(MoveCoordinates move) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveSettings(Settings settings) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoAsk() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoPositive() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoNegative() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void connectionExceptionOccurred(Exception e) {
        LOGGER.log(Level.WARNING, "Connection error experienced", e);
        close();
    }
}
