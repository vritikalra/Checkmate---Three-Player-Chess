package jchess.gui.image;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.net.URL;

/**
 * Responsible for loading images from disk and holding a cache of already loaded images.
 * There is no cache invalidation functionality as image files are expected not to be changed on disk.
 */
class ImageLoader {
    
    static Image loadImage(String imageLink, ImageObserver observer) {
        URL url = ImageLoader.class.getResource(imageLink);
        System.out.println("ImageLoader.loadImage: url = " + url);
        
        if (url == null) {
            System.out.println("Image file not found: " + imageLink);
            return null;
        }
        
        try {
            Toolkit tk = Toolkit.getDefaultToolkit();
            Image image = tk.getImage(url);
            tk.prepareImage(image, -1, -1, observer);
            return image;
        } catch (Exception e) {
            System.out.println("some error loading image!");
            e.printStackTrace();
            return null;
        }
    }
    
}
