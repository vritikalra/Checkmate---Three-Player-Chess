package jchess.gui.image;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 * Responsible for resizing an image and holding a cache of already resized images.
 */
public class ImageResizer {
    
    public Image resizeImage(Image image, int maxWidth, int maxHeight) {
        int imageWidth = image.getWidth(null);
        int imageHeight = image.getHeight(null);
        if(imageWidth < 0 || imageHeight < 0)
            return image;
        
        int resizedWidth = imageWidth>=imageHeight ? maxWidth : Math.round(maxWidth * (float) imageWidth / imageHeight);
        int resizedHeight = imageHeight>=imageWidth ? maxHeight : Math.round(maxHeight * (float)imageHeight / imageWidth);
        if(resizedWidth <= 0 || resizedHeight <= 0)
            return image;
        
        return drawResizedImage(image, resizedWidth, resizedHeight);
    }
    
    protected Image drawResizedImage(Image image, int resizedWidth, int resizedHeight) {
        BufferedImage resized = new BufferedImage(resizedWidth, resizedHeight, BufferedImage.TYPE_INT_ARGB_PRE);
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.drawImage(image, 0, 0, resizedWidth, resizedHeight, null);
        g2d.dispose();
        return resized;
    }
    
}
