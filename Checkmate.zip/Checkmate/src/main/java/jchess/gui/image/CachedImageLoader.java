package jchess.gui.image;

import java.awt.Image;
import java.awt.image.ImageObserver;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

class CachedImageLoader {
    
    private static ConcurrentHashMap<String, Image> imageCache = new ConcurrentHashMap<>();
    
    /**
     * Each entry contains multiple observers being interested in one specific image loading process.
     */
    private static ConcurrentHashMap<String, MultiImageObserver> multipleImageObservers = new ConcurrentHashMap<>();
    
    /**
     * Can be passed to image operations as ImageObserver and populates the update event to all registered ImageObservers.
     */
    private static class MultiImageObserver implements ImageObserver {
        
        private CopyOnWriteArraySet<ImageObserver> imageObservers = new CopyOnWriteArraySet<>();
        
        private void addObserver(ImageObserver observer) {
            imageObservers.add(observer);
        }
        
        @Override
        public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
            boolean waitingForMore = false;
            for (ImageObserver imageObserver : imageObservers) {
                waitingForMore = waitingForMore || imageObserver.imageUpdate(img, infoflags, x, y, width, height);
            }
            return waitingForMore;
        }
    }
    
    /**
     * Method to load image by a given name with extension
     * @param path relative path of image to load eg. "images/chessboard.jpg"
     * @return image or null if cannot load
     */
    static Image loadImage(String path, ImageObserver observer) {
        MultiImageObserver multiObserver = getMultiObserver(path, observer);
        return imageCache.computeIfAbsent(path, s -> ImageLoader.loadImage(path, multiObserver));
    }
    
    private static MultiImageObserver getMultiObserver(String path, ImageObserver observer) {
        if(observer == null)
            return null;
    
        MultiImageObserver multiObserver = multipleImageObservers.computeIfAbsent(path, k -> new MultiImageObserver());
        multiObserver.addObserver(observer);
        
        return multiObserver;
    }
}
