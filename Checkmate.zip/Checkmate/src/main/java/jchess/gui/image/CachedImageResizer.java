package jchess.gui.image;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.util.HashMap;

public class CachedImageResizer extends ImageResizer {
    
    private final HashMap<Image,Image> resizedImageCache = new HashMap<>();
    
    @Override
    public Image resizeImage(Image image, int maxWidth, int maxHeight) {
        if(isLoading(image)) {
            // do not fill cache with incomplete images
            return image;
        }
        
        return super.resizeImage(image, maxWidth, maxHeight);
    }
    
    @Override
    protected Image drawResizedImage(Image image, int resizedWidth, int resizedHeight) {
        synchronized (resizedImageCache) {
            Image cachedImage = resizedImageCache.get(image);
            
            if (cachedImage == null || cachedImage.getWidth(null) != resizedWidth || cachedImage.getHeight(null) != resizedHeight) {
                cachedImage = super.drawResizedImage(image, resizedWidth, resizedHeight);
                resizedImageCache.put(image, cachedImage);
            }
            
            return cachedImage;
        }
    }
    
    private static boolean isLoading(Image image) {
        return (Toolkit.getDefaultToolkit().checkImage(image, -1, -1, null) & (ImageObserver.ALLBITS|ImageObserver.ABORT)) == 0;
    }
}
