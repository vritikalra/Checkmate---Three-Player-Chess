package jchess.gui.image;

import jchess.Config;

import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public class Themes {
    
    private static String activeThemeName;
    private static List<String> themeNames;
    
    static {
        activeThemeName = readActiveThemeNameFromConfig();
        themeNames = listThemeNamesFromResources();
        preloadActiveTheme();
    }
    
    public static String getActiveThemeName() {
        return activeThemeName;
    }
    
    public static void setActiveThemeName(String themeName) {
        activeThemeName = themeName;
        storeActiveThemeNameToConfig(themeName);
        preloadActiveTheme();
    }
    
    public static List<String> getThemeNames() {
        return themeNames;
    }
    
    public static Image loadThemedImage(String fileName, ImageObserver observer) {
        return loadThemedImage(fileName, activeThemeName, observer);
    }
    
    public static Image loadThemedImage(String fileName, String themeName, ImageObserver observer) {
        return CachedImageLoader.loadImage(buildThemeBasePath(themeName) + fileName, observer);
    }
    
    private static String buildThemeBasePath(String themeName) {
        return "/theme/" + themeName + "/images/";
    }
    
    private static void preloadActiveTheme() {
        List<String> imageNames = getAllImageNamesOfTheme(activeThemeName);
        for (String fileName : imageNames) {
            loadThemedImage(fileName, null);
        }
    }
    
    private static String readActiveThemeNameFromConfig() {
        Properties configFile = Config.getConfigFile();
        System.out.println("ConfigFile THEME: " + configFile.getProperty("THEME"));
        return configFile.getProperty("THEME", "default");
    }
    
    private static List<String> listThemeNamesFromResources() {
        return listChildrenOfResourceFolder("/theme");
    }
    
    synchronized static List<String> listChildrenOfResourceFolder(String folderPath) {
        try {
            Path pathToResource = resourceAsPath(folderPath);
            
            return Files.walk(pathToResource, 1)
                    .skip(1) // skip the theme path itself
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .map(s -> s.replace("/", "")) // remove ending '/'
                    .collect(Collectors.toList());
        } catch (FileNotFoundException e) {
            return Collections.emptyList();
        } catch (IOException e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
    
    private static synchronized Path resourceAsPath(String pathToResource) throws IOException {
        URI uri;
        try {
            URL url = Themes.class.getResource(pathToResource);
            if (url == null)
                throw new FileNotFoundException();
            uri = url.toURI();
        } catch (URISyntaxException e) {
            uri = null;
        }
        if (uri != null && uri.getScheme().equals("jar")) {
            FileSystem fileSystem = getFileSystem(uri);
            return fileSystem.getPath(pathToResource);
        } else {
            Path path = uri == null ? Paths.get(pathToResource) : Paths.get(uri);
            if (!Files.exists(path))
                throw new FileNotFoundException();
            return path;
        }
    }
    
    private static FileSystem getFileSystem(URI uri) throws IOException {
        try {
            return FileSystems.getFileSystem(uri);
        } catch (FileSystemNotFoundException e) {
            return FileSystems.newFileSystem(uri, Collections.<String, String>emptyMap());
        }
    }
    
    private static List<String> getAllImageNamesOfTheme(String themeName) {
        return listChildrenOfResourceFolder(buildThemeBasePath(themeName));
    }
    
    private static void storeActiveThemeNameToConfig(String themeName) {
        Properties prp = Config.getConfigFile();
        prp.setProperty("THEME", themeName);
        try {
            //FileOutputStream fOutStr = new FileOutputStream(ThemeChooseWindow.class.getResource("config.txt").getFile());
            FileOutputStream fOutStr = new FileOutputStream("config.txt");
            prp.store(fOutStr, null);
            fOutStr.flush();
            fOutStr.close();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
    
}
