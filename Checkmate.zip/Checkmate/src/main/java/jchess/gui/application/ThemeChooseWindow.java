/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.application;

import jchess.MultiLanguage;
import jchess.gui.image.Themes;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public class ThemeChooseWindow extends JDialog implements ActionListener, ListSelectionListener {
    
    private Frame parent;
    private JList<String> themesList;
    private JButton themePreviewButton;
    private JButton okButton;

    ThemeChooseWindow(Frame parent) throws Exception {
        super(parent);
        this.parent = parent;
    
        if(Themes.getThemeNames().isEmpty()) {
            throw new Exception(MultiLanguage.get("error_when_creating_theme_config_window"));
        }
    
        this.setTitle(MultiLanguage.get("choose_theme_window_title"));
        Dimension winDim = new Dimension(550, 230);
        this.setMinimumSize(winDim);
        this.setMaximumSize(winDim);
        this.setSize(winDim);
        this.setResizable(false);
        this.setLayout(null);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.themesList = new JList<>(new Vector<>(Themes.getThemeNames()));
        this.themesList.setLocation(new Point(10, 10));
        this.themesList.setSize(new Dimension(100, 120));
        this.add(this.themesList);
        this.themesList.setSelectionMode(0);
        this.themesList.addListSelectionListener(this);
        this.themePreviewButton = new JButton();
        this.themePreviewButton.setLocation(new Point(110, 10));
        this.themePreviewButton.setSize(new Dimension(420, 120));
        this.add(this.themePreviewButton);
        this.okButton = new JButton("OK");
        this.okButton.setLocation(new Point(175, 140));
        this.okButton.setSize(new Dimension(200, 50));
        this.add(this.okButton);
        this.okButton.addActionListener(this);
        this.setModal(true);
        
        getRootPane().setDefaultButton(okButton);
        
        this.themesList.setSelectedValue(Themes.getActiveThemeName(), true);
    }

    @Override
    public void valueChanged(ListSelectionEvent event) {
        showThemePreview(this.themesList.getSelectedValue());
    }
    
    private void showThemePreview(String themeName) {
        Image previewImage = Themes.loadThemedImage("Preview.png", themeName, this.themePreviewButton);
        if (previewImage == null) {
            System.err.println("Cannot find preview image for theme " + themeName);
//                TODO: add noPreview.png
//                this.themePreview = new ImageIcon(Themes.getNoPreviewImage());
            this.themePreviewButton.setIcon(null);
        } else {
            this.themePreviewButton.setIcon(new ImageIcon(previewImage));
        }
    }

    /**
     * Method wich is changing a pawn into queen, rook, bishop or knight
     *
     * @param evt Capt information about performed action
     */
    public void actionPerformed(ActionEvent evt) {
        if (evt.getSource() == this.okButton) {
            String selectedTheme = this.themesList.getSelectedValue();
            Themes.setActiveThemeName(selectedTheme);
            this.setVisible(false);
            parent.repaint();
        }
    }
}
