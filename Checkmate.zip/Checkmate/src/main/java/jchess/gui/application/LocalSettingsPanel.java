/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 */
package jchess.gui.application;

import jchess.MultiLanguage;
import jchess.gui.GameCreationFacade;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.text.BadLocationException;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.util.ArrayList;

/**
 * Class responsible for drawing the fold with local game settings
 */
public class LocalSettingsPanel extends JPanel implements ActionListener, TextListener {

    private final String[] TIMES = {"1", "3", "5", "8", "10", "15", "20", "25", "30", "60", "120"};

    private final String[] PLAYER_AMOUNT = {"2 Players", "3 Players"};

    private final String[] GAME_SCENARIO = { "Classical Chess", "Fantasy Chess" };

    private JDialog parent;//needed to close newGame window
    private JComboBox<String> colorComboBox;//to choose color of player
    private JLabel startingPlayerColor=new JLabel("Choose starting player: ");
    private JRadioButton opponentCompRadioButton;//choose opponent
    private JRadioButton opponentHumanRadioButton;//choose opponent (human)
    private JSlider computerLevelSlider;//slider to choose jChess Engine level
    private JTextField firstNameTextField;//editable field 4 nickname
    private JTextField secondNameTextField;//editable field 4 nickname
    private JTextField thirdNameTextField;//editable field 4 nickname


    private JButton okButton;
    private JCheckBox whiteOnTopCheckBox;
    private JCheckBox timeGameCheckBox;
    private JComboBox<String> time4GameComboBox;
    private JComboBox<String> playerNumberComboBox; //combo box to switch between 2 or 3 players
    private JComboBox<String> gameScenario;// to select between Classical Chess or Fantasy Chess

    LocalSettingsPanel(JDialog parent) {
        super();
        this.parent = parent;
        addComponents();
    }

    /**
     * Method witch is checking correction of edit tables
     *
     * @param e Object where is saving this what contents edit tables
     */
    public void textValueChanged(TextEvent e) {
        if(!(e.getSource() instanceof JTextField))
            return;

        JTextField target = (JTextField) e.getSource();
        if (target == this.firstNameTextField || target == this.secondNameTextField || target == this.thirdNameTextField) {
            int len = target.getText().length();
            if (len > 8) {
                try {
                    target.setText(target.getText(0, 7));
                } catch (BadLocationException exc) {
                    System.out.println("Something wrong in editables: \n" + exc);
                }
            }
        }
    }

    /**
     * Method responsible for changing the options which can make a player
     * when he want to start new local game
     *
     * @param e where is saving data of performed action
     */
    public void actionPerformed(ActionEvent e) {
        Object target = e.getSource();
        if (target == this.opponentCompRadioButton) //toggle enabled of controls depends of opponent (if computer)
        {
            this.computerLevelSlider.setEnabled(true);//enable level of computer abilities
            this.secondNameTextField.setEnabled(false);//disable field with name of player2
        } else if (target == this.opponentHumanRadioButton) //else if opponent will be HUMAN
        {
            this.computerLevelSlider.setEnabled(false);//disable level of computer abilities
            this.secondNameTextField.setEnabled(true);//enable field with name of player2
        } else if (target == this.playerNumberComboBox) {
            if(this.playerNumberComboBox.getSelectedIndex()==0){
                this.thirdNameTextField.setEnabled(false);
                this.colorComboBox.removeItemAt(2);
                whiteOnTopCheckBox.setEnabled(true);
            }
            else{
                this.thirdNameTextField.setEnabled(true);
                this.colorComboBox.addItem(MultiLanguage.get("red"));
                whiteOnTopCheckBox.setEnabled(false);
            }
        } else if (target == this.okButton) //if clicked OK button (on finish)
        {
            validateInput();
            startGame();
        }
    }

    private void validateInput() {
        if (this.firstNameTextField.getText().length() > 9) {//make names short to 10 digits
            this.firstNameTextField.setText(this.trimString(firstNameTextField, 9));
        }
        if (this.secondNameTextField.getText().length() > 9) {//make names short to 10 digits
            this.secondNameTextField.setText(this.trimString(secondNameTextField, 9));
        }
        if (this.thirdNameTextField.getText().length() > 9) {//make names short to 10 digits
            this.thirdNameTextField.setText(this.trimString(thirdNameTextField, 9));
        }
        if (!this.opponentCompRadioButton.isSelected()
                && (this.firstNameTextField.getText().length() == 0 || this.secondNameTextField.getText().length() == 0 || this.thirdNameTextField.getText().length() == 0)) {
            JOptionPane.showMessageDialog(this, MultiLanguage.get("fill_names"));
            return;
        }
        if ((this.opponentCompRadioButton.isSelected() && this.firstNameTextField.getText().length() == 0)) { //TODO impelement 3 Players Game with Comp
            JOptionPane.showMessageDialog(this, MultiLanguage.get("fill_name"));
            return;
        }

        this.parent.setVisible(false);//hide parent

        System.out.println("time4Game.getActionCommand() = " + this.time4GameComboBox.getActionCommand());
    }

    private void startGame() {
        Integer timeLimit = null;
        if (timeGameCheckBox.isSelected()) {
            timeLimit = Integer.parseInt(this.TIMES[this.time4GameComboBox.getSelectedIndex()]) * 60;
        }

        int numberPlayers = 2; //number of players --> 2 by default
        if (this.playerNumberComboBox.getSelectedIndex() != -1) {
            numberPlayers = this.playerNumberComboBox.getSelectedIndex() + 2; //since index 0 is 2 players, index 1 is 3 players...
            System.out.println("Anzahl Spieler: " + numberPlayers);
        }

        ArrayList<String> playerNames=new ArrayList<>();
        playerNames.add(this.firstNameTextField.getText());
        playerNames.add(this.secondNameTextField.getText());
        if(numberPlayers==3){
            playerNames.add(this.thirdNameTextField.getText());
        }

        GameCreationFacade.GameMetaData metaData = GameCreationFacade.createLocalGame(
                JChessApp.getApplication(),
                playerNames,
                this.colorComboBox.getSelectedIndex(),
                this.opponentCompRadioButton.isSelected(),
                this.whiteOnTopCheckBox.isSelected() && this.whiteOnTopCheckBox.isEnabled(),
                timeLimit,
                "Fantasy Chess".equals(this.gameScenario.getSelectedItem())
        );
        JChessView.getInstance().addNewTab(metaData.title, metaData.component);
    }

    private void addComponents() {
        String[] PLAYER_COLORS = {
                MultiLanguage.get("white"), MultiLanguage.get("black"), MultiLanguage.get("red")
        };

        this.colorComboBox = new JComboBox<>(PLAYER_COLORS);
        this.colorComboBox.removeItemAt(2); //because default is 2 players

        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        this.okButton = new JButton(MultiLanguage.get("ok"));
        JLabel compLevLab = new JLabel(MultiLanguage.get("computer_level"));

        this.firstNameTextField = new JTextField("", 10);
        this.firstNameTextField.setSize(new Dimension(200, 50));
        this.firstNameTextField.setText("Player 1");
        this.secondNameTextField = new JTextField("", 10);
        this.secondNameTextField.setSize(new Dimension(200, 50));
        this.secondNameTextField.setText("Player 2");
        this.thirdNameTextField = new JTextField("", 10);
        this.thirdNameTextField.setSize(200, 50);
        this.thirdNameTextField.setText("Player 3");
        this.thirdNameTextField.setEnabled(false);



        JLabel firstNameLab = new JLabel(MultiLanguage.get("first_player_name") + ": ");
        JLabel secondNameLab = new JLabel(MultiLanguage.get("second_player_name") + ": ");
        JLabel thirdNameLab = new JLabel(MultiLanguage.get("third_player_name") + ": ");
        //group 4 radio buttons
        this.computerLevelSlider = new JSlider();
        whiteOnTopCheckBox = new JCheckBox(MultiLanguage.get("white_on_top"));
        this.timeGameCheckBox = new JCheckBox(MultiLanguage.get("time_game_min"));
        this.time4GameComboBox = new JComboBox<>(TIMES);

        this.playerNumberComboBox = new JComboBox<>(PLAYER_AMOUNT);
        this.playerNumberComboBox.addActionListener(this);

        this.gameScenario = new JComboBox<>(GAME_SCENARIO);

        this.opponentCompRadioButton = new JRadioButton(MultiLanguage.get("against_computer"), false);
        this.opponentHumanRadioButton = new JRadioButton(MultiLanguage.get("against_other_human"), true);

        this.setLayout(gbl);
        this.opponentCompRadioButton.addActionListener(this);
        this.opponentHumanRadioButton.addActionListener(this);
        this.okButton.addActionListener(this);

        this.firstNameTextField.addActionListener(this);
        this.secondNameTextField.addActionListener(this);
        this.thirdNameTextField.addActionListener(this);

        ButtonGroup opponentChooserButtonGroup = new ButtonGroup();
        opponentChooserButtonGroup.add(opponentCompRadioButton);
        opponentChooserButtonGroup.add(opponentHumanRadioButton);
        this.computerLevelSlider.setEnabled(false);
        this.computerLevelSlider.setMaximum(3);
        this.computerLevelSlider.setMinimum(1);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(3, 3, 3, 3);
        gbl.setConstraints(opponentCompRadioButton, gbc);
        this.add(opponentCompRadioButton);
        
        gbc.gridx = 1;
        gbl.setConstraints(opponentHumanRadioButton, gbc);
        this.add(opponentHumanRadioButton);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbl.setConstraints(firstNameLab, gbc);
        this.add(firstNameLab);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbl.setConstraints(firstNameTextField, gbc);
        this.add(firstNameTextField);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbl.setConstraints(startingPlayerColor, gbc);
        this.add(startingPlayerColor);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbl.setConstraints(colorComboBox, gbc);
        this.add(colorComboBox);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbl.setConstraints(secondNameLab, gbc);
        this.add(secondNameLab);
        
        gbc.gridy = 4;
        gbl.setConstraints(secondNameTextField, gbc);
        this.add(secondNameTextField);
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbl.setConstraints(thirdNameLab, gbc);
        this.add(thirdNameLab);
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbl.setConstraints(thirdNameTextField, gbc);
        this.add(thirdNameTextField);
        
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 0, 0);
        gbl.setConstraints(compLevLab, gbc);
        this.add(compLevLab);
        
        gbc.gridy = 7;
        gbl.setConstraints(computerLevelSlider, gbc);
        this.add(computerLevelSlider);
        
        gbc.gridy = 8;
        gbl.setConstraints(whiteOnTopCheckBox, gbc);
        this.add(whiteOnTopCheckBox);
        
        gbc.gridy = 9;
        gbc.gridwidth = 1;
        gbl.setConstraints(timeGameCheckBox, gbc);
        this.add(timeGameCheckBox);
        
        gbc.gridx = 1;
        gbc.gridy = 9;
        gbc.gridwidth = 1;
        gbl.setConstraints(time4GameComboBox, gbc);
        this.add(time4GameComboBox);
        
        gbc.gridx = 1;
        gbc.gridy = 10;
        gbc.gridwidth = 0;
        gbl.setConstraints(gameScenario,gbc);
        this.add(gameScenario);
        
        gbc.gridx = 0;
        gbc.gridy = 11;
        gbc.gridwidth = 1;
        gbl.setConstraints(playerNumberComboBox, gbc);
        this.add(playerNumberComboBox);
        
        gbc.gridx = 1;
        gbc.gridy = 11;
        gbc.gridwidth = 0;
        gbl.setConstraints(okButton, gbc);
        this.add(okButton);
        
        this.opponentCompRadioButton.setEnabled(false);//for now, because not implemented!
    }

    /**
     * Method responsible for trimming white symbols from strings
     *
     * @param txt    Where is capt value to equal
     * @param length How long is the string
     * @return result trimmed String
     */
    private String trimString(JTextField txt, int length) {
        try {
            return txt.getText(0, length);
        } catch (BadLocationException exc) {
            System.out.println("Something wrong in editables: \n" + exc);
            return null;
        }
    }

    JButton getOkButton() {
        return okButton;
    }


}