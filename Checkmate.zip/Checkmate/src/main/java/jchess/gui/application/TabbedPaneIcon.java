package jchess.gui.application;

import javax.swing.Icon;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * this class draws a close (X) icon
 */
class TabbedPaneIcon implements Icon {

    private static int SIZE = 16;

    private int posX;
    private int posY;

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        this.posX = x;
        this.posY = y;

        Color col = g.getColor();

        g.setColor(Color.black);
        int pY = y + 2;
        g.drawLine(x + 3, pY + 3, x + 10, pY + 10);
        g.drawLine(x + 3, pY + 4, x + 9, pY + 10);
        g.drawLine(x + 4, pY + 3, x + 10, pY + 9);
        g.drawLine(x + 10, pY + 3, x + 3, pY + 10);
        g.drawLine(x + 10, pY + 4, x + 4, pY + 10);
        g.drawLine(x + 9, pY + 3, x + 3, pY + 9);
        g.setColor(col);
    }

    @Override
    public int getIconWidth() {
        return SIZE;
    }

    @Override
    public int getIconHeight() {
        return SIZE;
    }

    public Rectangle getBounds() {
        return new Rectangle(posX, posY, SIZE, SIZE);
    }
}
