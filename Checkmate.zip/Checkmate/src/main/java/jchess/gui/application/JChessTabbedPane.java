/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>..
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.application;

import jchess.gui.image.Themes;

import javax.swing.JTabbedPane;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.ImageObserver;

/**
 * this class draws the tabs
 * reacts to mouse events: close tab, create tab
 */
public class JChessTabbedPane extends JTabbedPane implements MouseListener, ImageObserver {

    private JChessView view;
    private TabbedPaneIcon closeIcon;
    private Image addIcon;
    private Rectangle addIconRect;

    JChessTabbedPane(JChessView view) {
        super();
        this.view = view;
        this.closeIcon = new TabbedPaneIcon();
        this.addIcon = Themes.loadThemedImage("add-tab-icon.png", this);
        this.setDoubleBuffered(true);
        super.addMouseListener(this);
    }

    private void updateAddIconRect() {
        if (this.getTabCount() > 0) {
            Rectangle rect = this.getBoundsAt(this.getTabCount() - 1);
            this.addIconRect = new Rectangle(rect.x + rect.width + 5, rect.y, this.addIcon.getWidth(this), this.addIcon.getHeight(this));
        } else {
            this.addIconRect = null;
        }
    }

    /**
     * New game tab
     * @param title Title of game-tab
     * @param component Content of Tab
     */
    @Override
    public void addTab(String title, Component component) {
        super.addTab(title, closeIcon, component);
        System.out.println("Present number of tabs: " + this.getTabCount());
        this.updateAddIconRect();
    }

    @Override
    public void mousePressed(MouseEvent e) { }

    @Override
    public void mouseReleased(MouseEvent e) { }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) { }

    @Override
    public void mouseExited(MouseEvent mouseEvent) { }

    @Override
    public void mouseClicked(MouseEvent e) {
        Rectangle rect;
        int tabNumber = getUI().tabForCoordinate(this, e.getX(), e.getY());
        if (tabNumber >= 0) {
            rect = ((TabbedPaneIcon) getIconAt(tabNumber)).getBounds();
            if (rect.contains(e.getX(), e.getY())) {
                System.out.println("Removing tab with " + tabNumber + " number!...");
                this.removeTabAt(tabNumber);//remove tab
                this.updateAddIconRect();
            }
            if (this.getTabCount() == 0) {
                // show new game popup if there is no game
                view.showNewGamePopup();
            }
        } else if (this.addIconRect != null && this.addIconRect.contains(e.getX(), e.getY())) {
            System.out.println("newGame by + button");
            view.showNewGamePopup();
        }
    }

    @Override
    public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
        this.updateAddIconRect();
        super.imageUpdate(img, infoflags, x, y, width, height);
        return true;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (addIconRect != null) {
            g.drawImage(addIcon, addIconRect.x, addIconRect.y, null);
        }
    }

    @Override
    public void update(Graphics g) {
        this.repaint();
    }
}

