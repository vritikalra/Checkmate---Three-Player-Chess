/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 */
package jchess.gui.application;

import jchess.MultiLanguage;
import jchess.gui.GameCreationFacade;
import jchess.gui.client.Client;
import jchess.gui.client.JoinClient;
import jchess.gui.gameview.GameView;
import jchess.network.MD5;
import jchess.server.GameManager;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

/**
 * Class responible for drawing Network Settings, when player want to start
 * a game on a network
 *
 */
public class NetworkSettingsPanel extends JPanel implements ActionListener {

    private JDialog parent;
    private JRadioButton serverRadioButton;
    private JRadioButton clientRadioButton;
    private JPanel optionsPanel;
    private JTextField nickTextField;
    private JPasswordField passwordPasswordField;
    private JTextField gameIdTextField;
    
    private JButton startButton;
    private ServerOptionsPanel serverOptionsPanel;
    private ClientOptionsPanel clientOptionsPanel;

    NetworkSettingsPanel(JDialog parent) {
        super();
        this.parent = parent;
        addComponents();
    }
    
    private void addComponents() {
        this.serverRadioButton = new JRadioButton(MultiLanguage.get("create_server"), true);
        this.clientRadioButton = new JRadioButton(MultiLanguage.get("connect_2_server"), false);
        ButtonGroup serverOrClient = new ButtonGroup();
        serverOrClient.add(this.serverRadioButton);
        serverOrClient.add(this.clientRadioButton);
        this.serverRadioButton.addActionListener(this);
        this.clientRadioButton.addActionListener(this);
    
        JLabel labelNick = new JLabel(MultiLanguage.get("nickname"));
        JLabel labelPassword = new JLabel(MultiLanguage.get("password"));
        JLabel labelGameID = new JLabel(MultiLanguage.get("game_id"));
        JLabel labelOptions = new JLabel(MultiLanguage.get("server_options"));

        this.nickTextField = new JTextField();
        this.passwordPasswordField = new JPasswordField();
        this.gameIdTextField = new JTextField();

        this.optionsPanel = new JPanel();
        this.clientOptionsPanel = new ClientOptionsPanel();
        this.serverOptionsPanel = new ServerOptionsPanel();
    
        this.startButton = new JButton(MultiLanguage.get("start"));
        this.startButton.addActionListener(this);

        //add components
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        this.setLayout(gbl);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbl.setConstraints(serverRadioButton, gbc);
        this.add(serverRadioButton);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbl.setConstraints(clientRadioButton, gbc);
        this.add(clientRadioButton);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbl.setConstraints(labelGameID, gbc);
        this.add(labelGameID);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbl.setConstraints(gameIdTextField, gbc);
        this.add(gameIdTextField);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbl.setConstraints(labelNick, gbc);
        this.add(labelNick);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbl.setConstraints(nickTextField, gbc);
        this.add(nickTextField);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbl.setConstraints(labelPassword, gbc);
        this.add(labelPassword);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbl.setConstraints(passwordPasswordField, gbc);
        this.add(passwordPasswordField);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbl.setConstraints(labelOptions, gbc);
        this.add(labelOptions);

        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbl.setConstraints(optionsPanel, gbc);
        this.add(optionsPanel);

        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.gridwidth = 2;
        gbl.setConstraints(startButton, gbc);
        this.add(startButton);

        this.optionsPanel.add(serverOptionsPanel);
    }

    /**
     * Method for showing settings which the player is interested with
     */
    public void actionPerformed(ActionEvent arg0) {
        if (arg0.getSource() == this.serverRadioButton) //show options for server
        {
            this.optionsPanel.removeAll();
            this.optionsPanel.add(serverOptionsPanel);
            this.optionsPanel.revalidate();
            this.optionsPanel.requestFocus();
            this.optionsPanel.repaint();
        } else if (arg0.getSource() == this.clientRadioButton) //show options for client
        {
            this.optionsPanel.removeAll();
            this.optionsPanel.add(clientOptionsPanel);
            this.optionsPanel.revalidate();
            this.optionsPanel.requestFocus();
            this.optionsPanel.repaint();
        } else if (arg0.getSource() == this.startButton) //click start button
        {
            String error = "";
            if (this.gameIdTextField.getText().isEmpty()) {
                error += MultiLanguage.get("fill_game_id") + "\n";
            }
            if (!this.gameIdTextField.getText().matches("^[0-9]+$")) {
                error += MultiLanguage.get("game_id_only_digits") + "\n";
            }
            if (this.nickTextField.getText().length() == 0) {
                error += MultiLanguage.get("fill_name") + "\n";
            }
            if (this.passwordPasswordField.getPassword().length <= 4) {
                error += MultiLanguage.get("fill_pass_with_more_than_4_signs") + "\n";
            }
            if (this.clientRadioButton.isSelected() && this.clientOptionsPanel.serverIpTextField.getText().length() == 0) {
                error += MultiLanguage.get("please_fill_field") + " IP \n";
            } else if (this.clientRadioButton.isSelected()) {
                Pattern ipPattern = Pattern.compile("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}");
                if (!ipPattern.matcher(this.clientOptionsPanel.serverIpTextField.getText()).matches()) {
                    error += MultiLanguage.get("bad_ip_format") + "\n";
                }
            }
            if (error.length() > 0) {
                JOptionPane.showMessageDialog(this, error);
                return;
            }
            String encryptedPassword = MD5.encrypt(this.passwordPasswordField.getPassword());
            
            if (this.serverRadioButton.isSelected()) {
                try {
                    GameCreationFacade.startServer(
                            Integer.parseInt(gameIdTextField.getText()),
                            encryptedPassword,
                            !serverOptionsPanel.withoutObserversCheckBox.isSelected(),
                            !serverOptionsPanel.disableChatCheckBox.isSelected()
                    );
                } catch (GameManager.BadGameIdException e) {
                    JOptionPane.showMessageDialog(this, MultiLanguage.get("game_id_already_existing"));
                    return;
                }
            }
    
            GameCreationFacade.joinNetworkGame(
                    clientOptionsPanel.serverIpTextField.getText(),
                    Integer.parseInt(gameIdTextField.getText()),
                    clientOptionsPanel.onlyWatchCheckBox.isSelected(),
                    nickTextField.getText(),
                    encryptedPassword,
                    new JoinClient.JoinStatusUpdate() {
                        @Override
                        public void successfullyJoined(Client client) {
                            parent.setVisible(false); //hide parent
                            //create new game and draw chessboard
                            // TODO set updateTarget and make networking work with the new game logic
                            GameView newGUI = new GameView(null, null);
                            JChessView.getInstance().addNewTab("Network game, gameID: " + gameIdTextField.getText(), newGUI); /*client.sett.playerWhite.getName()+" vs "+client.sett.playerBlack.getName()*/
                            newGUI.add(newGUI.getChat());
                            client.gameView = newGUI;
                            client.startListening();
                        }
                
                        @Override
                        public void connectionExceptionOccurred(Exception e) {
                            JOptionPane.showMessageDialog(NetworkSettingsPanel.this, MultiLanguage.get("error_connecting_to_server"));
                            e.printStackTrace();
                        }
                    }
            );
        }
    }

    /**
     *  Method witch is saving the latest network settings
     */
    private static class ServerOptionsPanel extends JPanel //options for server
    {
    
        JTextField gameTimeTextField;
        JCheckBox withoutObserversCheckBox;
        JCheckBox disableChatCheckBox;

        ServerOptionsPanel() {
            super();
    
            JLabel labelGameTime = new JLabel(MultiLanguage.get("time_game_min"));
            gameTimeTextField = new JTextField();
            withoutObserversCheckBox = new JCheckBox(MultiLanguage.get("without_observers"));
            disableChatCheckBox = new JCheckBox(MultiLanguage.get("without_chat"));

            //temporary disabled options
            labelGameTime.setEnabled(false);
            this.gameTimeTextField.setEnabled(false);
            this.disableChatCheckBox.setEnabled(false);
            //------------------------
    
            GridBagLayout gbl = new GridBagLayout();
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.BOTH;
            this.setLayout(gbl);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.gridwidth = 2;
            gbl.setConstraints(labelGameTime, gbc);
            this.add(labelGameTime);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.gridwidth = 2;
            gbl.setConstraints(gameTimeTextField, gbc);
            this.add(gameTimeTextField);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbl.setConstraints(withoutObserversCheckBox, gbc);
            this.add(withoutObserversCheckBox);

            gbc.gridx = 1;
            gbc.gridy = 2;
            gbc.gridwidth = 1;
            gbl.setConstraints(disableChatCheckBox, gbc);
            this.add(disableChatCheckBox);
        }
    }

    /**
     *  Method responible for drawing clients panel
     */
    private static class ClientOptionsPanel extends JPanel //options for client
    {
    
        JTextField serverIpTextField;
        JCheckBox onlyWatchCheckBox;

        ClientOptionsPanel() {
            super();
    
            JLabel serverIpLabel = new JLabel(MultiLanguage.get("server_ip"));
            this.serverIpTextField = new JTextField();
            this.onlyWatchCheckBox = new JCheckBox(MultiLanguage.get("only_observe"));
    
            GridBagLayout gbl = new GridBagLayout();
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.BOTH;
            this.setLayout(gbl);

            gbc.gridx = 0;
            gbc.gridy = 0;
            gbl.setConstraints(serverIpLabel, gbc);
            this.add(serverIpLabel);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbl.setConstraints(serverIpTextField, gbc);
            this.add(serverIpTextField);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbl.setConstraints(onlyWatchCheckBox, gbc);
            this.add(onlyWatchCheckBox);
        }
    }
    
    JButton getStartButton() {
        return startButton;
    }
}
