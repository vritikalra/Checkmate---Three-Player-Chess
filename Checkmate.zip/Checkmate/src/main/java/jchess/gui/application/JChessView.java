/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jchess.gui.application;

import jchess.MultiLanguage;
import jchess.gui.gameview.GameView;
import org.jdesktop.application.Action;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.TaskMonitor;

import javax.swing.ActionMap;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;


/**
 * The application's main frame.
 */
public class JChessView extends FrameView implements ActionListener {

    private static JChessView instance;

    public static JChessView getInstance() {
        return instance;
    }

    static void createInstance(SingleFrameApplication app) {
        instance = new JChessView(app);
    }
    
    private final SingleFrameApplication singleFrameApplication;
    
    private JMenu gameMenu;
    private JTabbedPane gamesPane;
    private JMenuItem loadGameItem;
    private JPanel mainPanel;
    private JMenuBar menuBar;
    private JMenuItem moveBackItem;
    private JMenuItem moveForwardItem;
    private JMenuItem newGameItem;
    private JMenu optionsMenu;
    private JProgressBar progressBar;
    private JMenuItem rewindToBegin;
    private JMenuItem rewindToEnd;
    private JMenuItem saveGameItem;
    private JLabel statusAnimationLabel;
    private JLabel statusMessageLabel;
    private JPanel statusPanel;
    private JMenuItem themeSettingsMenu;
    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;

    private JDialog aboutBox;
    private JDialog newGameFrame;

    private JChessView(SingleFrameApplication app) {
        super(app);
        
        this.singleFrameApplication = app;

        getFrame().setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getFrame().setMinimumSize(new Dimension(800,600));
        initComponents();
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, e -> statusMessageLabel.setText(""));
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, e -> {
            busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
            statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(evt -> {
            String propertyName = evt.getPropertyName();
            if ("started".equals(propertyName)) {
                if (!busyIconTimer.isRunning()) {
                    statusAnimationLabel.setIcon(busyIcons[0]);
                    busyIconIndex = 0;
                    busyIconTimer.start();
                }
                progressBar.setVisible(true);
                progressBar.setIndeterminate(true);
            } else if ("done".equals(propertyName)) {
                busyIconTimer.stop();
                statusAnimationLabel.setIcon(idleIcon);
                progressBar.setVisible(false);
                progressBar.setValue(0);
            } else if ("message".equals(propertyName)) {
                String text = (String) (evt.getNewValue());
                statusMessageLabel.setText((text == null) ? "" : text);
                messageTimer.restart();
            } else if ("progress".equals(propertyName)) {
                int value = (Integer) (evt.getNewValue());
                progressBar.setVisible(true);
                progressBar.setIndeterminate(false);
                progressBar.setValue(value);
            }
        });

        showNewGamePopup();
    }

    public void addNewTab(String title, Component component) {
        gamesPane.addTab(title, component);
    }

    void showNewGamePopup() {
        if (newGameFrame == null) {
            newGameFrame = new NewGameWindow();
        }
        singleFrameApplication.show(newGameFrame);
    }

    // will be called when an action in the menu bar is clicked
    public void actionPerformed(ActionEvent event) {
        Object target = event.getSource();
        if (target == newGameItem) {
            showNewGamePopup();
        } else if (target == saveGameItem) { //saveGame
            if (this.gamesPane.getTabCount() == 0) {
                JOptionPane.showMessageDialog(null, MultiLanguage.get("save_not_called_for_tab"));
                return;
            }
            while (true) {
                JFileChooser fc = new JFileChooser();
                int retVal = fc.showSaveDialog(this.gamesPane);
                if (retVal == JFileChooser.APPROVE_OPTION) {
                    File selFile = fc.getSelectedFile();
                    GameView tempGUI = (GameView) this.gamesPane.getComponentAt(this.gamesPane.getSelectedIndex());
                    if (!selFile.exists()) {
                        try {
                            selFile.createNewFile();
                        } catch (java.io.IOException exc) {
                            System.out.println("error creating file: " + exc);
                        }
                    } else if (selFile.exists()) {
                        int opt = JOptionPane.showConfirmDialog(tempGUI, MultiLanguage.get("file_exists"), MultiLanguage.get("file_exists"), JOptionPane.YES_NO_OPTION);
                        if (opt == JOptionPane.NO_OPTION)//if user choose to now overwrite
                        {
                            continue; // go back to file choose
                        }
                    }
                    if (selFile.canWrite()) {
                        //tempGUI.saveGame(selFile);
                    }
                    System.out.println("fc.getSelectedFile().isFile() = " + fc.getSelectedFile().isFile());
                    break;
                } else if (retVal == JFileChooser.CANCEL_OPTION) {
                    break;
                }
            }
        } else if (target == loadGameItem) { //loadGame
            JFileChooser fc = new JFileChooser();
            int retVal = fc.showOpenDialog(this.gamesPane);
            if (retVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                if (file.exists() && file.canRead()) {
                    //Game.loadGame(file);
                }
            }
        } else if (target == this.themeSettingsMenu) {
            try {
                ThemeChooseWindow choose = new ThemeChooseWindow(this.getFrame());
                singleFrameApplication.show(choose);
            } catch (Exception exc) {
                JOptionPane.showMessageDialog(
                        singleFrameApplication.getMainFrame(),
                        exc.getMessage()
                );
                System.out.println("Something wrong creating window - perhaps themeList is null");
            }
        }
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = singleFrameApplication.getMainFrame();
            aboutBox = new JChessAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        singleFrameApplication.show(aboutBox);
    }

    /**
     * This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {

        mainPanel = new JPanel();
        gamesPane = new JChessTabbedPane(this);
        menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu();
        newGameItem = new JMenuItem();
        loadGameItem = new JMenuItem();
        saveGameItem = new JMenuItem();
        JMenuItem exitMenuItem = new JMenuItem();
        gameMenu = new JMenu();
        moveBackItem = new JMenuItem();
        moveForwardItem = new JMenuItem();
        rewindToBegin = new JMenuItem();
        rewindToEnd = new JMenuItem();
        optionsMenu = new JMenu();
        themeSettingsMenu = new JMenuItem();
        JMenu helpMenu = new JMenu();
        JMenuItem aboutMenuItem = new JMenuItem();
        statusPanel = new JPanel();
        JSeparator statusPanelSeparator = new JSeparator();
        statusMessageLabel = new JLabel();
        statusAnimationLabel = new JLabel();
        progressBar = new JProgressBar();

        mainPanel.setMaximumSize(new java.awt.Dimension(800, 600));
        mainPanel.setMinimumSize(new java.awt.Dimension(800, 600));
        mainPanel.setName("mainPanel");
        mainPanel.setPreferredSize(new java.awt.Dimension(800, 600));

        gamesPane.setName("gamesPane");

        GroupLayout mainPanelLayout = new GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
                mainPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(mainPanelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(gamesPane, GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
                mainPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(mainPanelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(gamesPane, GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE))
        );

        menuBar.setName("menuBar");
    
        org.jdesktop.application.ResourceMap resourceMap = getResourceMap();
        fileMenu.setText(resourceMap.getString("fileMenu.text"));
        fileMenu.setName("fileMenu");

        newGameItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        newGameItem.setText(resourceMap.getString("newGameItem.text"));
        newGameItem.setName("newGameItem");
        fileMenu.add(newGameItem);
        newGameItem.addActionListener(this);

        loadGameItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        loadGameItem.setText(resourceMap.getString("loadGameItem.text"));
        loadGameItem.setName("loadGameItem");
        fileMenu.add(loadGameItem);
        loadGameItem.addActionListener(this);

        saveGameItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        saveGameItem.setText(resourceMap.getString("saveGameItem.text"));
        saveGameItem.setName("saveGameItem");
        fileMenu.add(saveGameItem);
        saveGameItem.addActionListener(this);
        
        ActionMap actionMap = getContext().getActionMap(JChessView.class, this);
        exitMenuItem.setAction(actionMap.get("quit"));
        exitMenuItem.setName("exitMenuItem");
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        gameMenu.setText(resourceMap.getString("gameMenu.text"));
        gameMenu.setName("gameMenu");

        moveBackItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        moveBackItem.setText(resourceMap.getString("moveBackItem.text"));
        moveBackItem.setName("moveBackItem");
        moveBackItem.addActionListener(evt -> moveBackItemActionPerformed(evt));
        gameMenu.add(moveBackItem);

        moveForwardItem.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        moveForwardItem.setText(resourceMap.getString("moveForwardItem.text"));
        moveForwardItem.setName("moveForwardItem");
        moveForwardItem.addActionListener(evt -> moveForwardItemActionPerformed(evt));
        gameMenu.add(moveForwardItem);

        rewindToBegin.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        rewindToBegin.setText(resourceMap.getString("rewindToBegin.text"));
        rewindToBegin.setName("rewindToBegin");
        rewindToBegin.addActionListener(evt -> rewindToBeginActionPerformed(evt));
        gameMenu.add(rewindToBegin);

        rewindToEnd.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        rewindToEnd.setText(resourceMap.getString("rewindToEnd.text"));
        rewindToEnd.setName("rewindToEnd");
        rewindToEnd.addActionListener(evt -> rewindToEndActionPerformed(evt));
        gameMenu.add(rewindToEnd);

        menuBar.add(gameMenu);

        optionsMenu.setText(resourceMap.getString("optionsMenu.text"));
        optionsMenu.setName("optionsMenu");

        themeSettingsMenu.setText(resourceMap.getString("themeSettingsMenu.text"));
        themeSettingsMenu.setName("themeSettingsMenu");
        optionsMenu.add(themeSettingsMenu);
        themeSettingsMenu.addActionListener(this);

        menuBar.add(optionsMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text"));
        helpMenu.setName("helpMenu");

        aboutMenuItem.setAction(actionMap.get("showAboutBox"));
        aboutMenuItem.setName("aboutMenuItem");
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel");

        statusPanelSeparator.setName("statusPanelSeparator");

        statusMessageLabel.setName("statusMessageLabel");

        statusAnimationLabel.setHorizontalAlignment(SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel");

        progressBar.setName("progressBar");

        GroupLayout statusPanelLayout = new GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
                statusPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(statusPanelSeparator, GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
                        .addGroup(statusPanelLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(statusMessageLabel)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 616, Short.MAX_VALUE)
                                .addComponent(progressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(statusAnimationLabel)
                                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
                statusPanelLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(statusPanelLayout.createSequentialGroup()
                                .addComponent(statusPanelSeparator, GroupLayout.PREFERRED_SIZE, 2, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(statusPanelLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(statusMessageLabel)
                                        .addComponent(statusAnimationLabel)
                                        .addComponent(progressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }

    private void moveBackItemActionPerformed(java.awt.event.ActionEvent e) {
        GameView activeGameView = getActiveTabGame();
        if(activeGameView != null)
            activeGameView.undo();
    }

    private void moveForwardItemActionPerformed(java.awt.event.ActionEvent e) {
        GameView activeGameView = getActiveTabGame();
        if(activeGameView != null)
            activeGameView.redo();
    }

    private void rewindToBeginActionPerformed(java.awt.event.ActionEvent e) {
        GameView activeGameView = getActiveTabGame();
    }

    private void rewindToEndActionPerformed(java.awt.event.ActionEvent e) {
        GameView activeGameView = getActiveTabGame();
    }

    private GameView getActiveTabGame() {
        int index = gamesPane.getSelectedIndex();
        if(index != -1)
            return (GameView) gamesPane.getComponentAt(index);
        else
            return null;
    }
}
