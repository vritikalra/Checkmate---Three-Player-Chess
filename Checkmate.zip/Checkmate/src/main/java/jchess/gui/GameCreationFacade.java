package jchess.gui;

import jchess.gamelogic.GameFactory;
import jchess.gamelogic.shared.GameUpdateTarget;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gui.client.JoinClient;
import jchess.gui.gameview.GameView;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.Player;
import jchess.network.gamemessages.Settings;
import jchess.server.GameManager;
import jchess.server.Server;
import org.jdesktop.application.SingleFrameApplication;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameCreationFacade {

    public static class GameMetaData {
        public final String title;
        public final Component component;

        public GameMetaData(String title, Component component) {
            this.title = title;
            this.component = component;
        }
    }


    public static GameMetaData createLocalGame(SingleFrameApplication owner, ArrayList<String> playerNames, int startingPlayer, boolean againstComputer, boolean whiteOnTop, Integer timeLimitSeconds, boolean isFantasyChess) {
        if (playerNames.size()==2) {

            List<PlayerColor> players = new ArrayList<>(2);
            players.add(PlayerColor.WHITE);
            players.add(PlayerColor.BLACK);

            GameView newGUI = new GameView(owner, players);
            GameUpdateTarget game = new GameFactory().createGame(newGUI, players, startingPlayer, isFantasyChess);
            newGUI.setUpdateTarget(game);

            Settings sett = newGUI.getSettings();//sett local settings variable
            Player player1 = sett.playerWhite;//set local player variable
            Player player2 = sett.playerBlack;//set local player variable
            sett.gameMode = Settings.gameModes.newGame;
            sett.gameType = Settings.gameTypes.local;
            
            if(startingPlayer == 0) {
                player1.setName(playerNames.get(0));
                player2.setName(playerNames.get(1));
            } else {
                player1.setName(playerNames.get(1));
                player2.setName(playerNames.get(0));
            }
            
            player1.setType(Player.playerTypes.localUser);//set type of player
            player2.setType(Player.playerTypes.localUser);//set type of player
            if (againstComputer) {
                player2.setType(Player.playerTypes.computer);
            }
            
            sett.whiteOnTop = whiteOnTop;
            
            if (timeLimitSeconds != null) {
                sett.timeLimitSet = true;
                sett.timeForGame = timeLimitSeconds;
            }

            game.start(timeLimitSeconds);
            
            System.out.println("****************\nStarting new game: " + player1.name + " vs. " + player2.name
                    + "\ntime 4 game: " + sett.timeForGame + "\ntime limit set: " + sett.timeLimitSet
                    + "\nwhite on top?: " + sett.whiteOnTop + "\n****************");//4test

            return new GameMetaData(playerNames.get(0)+ " vs " + playerNames.get(1), newGUI);
        }
        else if(playerNames.size()==3){
            List<PlayerColor> players = new ArrayList<>(3);
            players.add(PlayerColor.WHITE);
            players.add(PlayerColor.BLACK);
            players.add(PlayerColor.RED);
    
            GameView newGUI = new GameView(owner, players);
            GameUpdateTarget game = new GameFactory().createGame(newGUI, players, startingPlayer, false);
            newGUI.setUpdateTarget(game);


            game.start(timeLimitSeconds);

            return new GameMetaData(playerNames.get(0)+ " vs " + playerNames.get(1)+ " vs " + playerNames.get(2), newGUI);
        } else {
            throw new RuntimeException("Number of players not supported: " + playerNames.size());
        }
    }
    
    public static void startServer(int gameId, String encryptedPassword, boolean observersAllowed, boolean chatEnabled) throws GameManager.BadGameIdException {
        Server.getInstance().getGameManager().createGame(gameId, encryptedPassword, observersAllowed, chatEnabled);

        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {
            Logger.getLogger(GameCreationFacade.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void joinNetworkGame(String serverIp, int gameId, boolean joinAsObserver, String playerName, String encryptedPassword, JoinClient.JoinStatusUpdate joinStatusUpdate) {
        LoginMessage loginMessage = new LoginMessage(gameId, joinAsObserver, playerName, encryptedPassword);
        new JoinClient(serverIp, Server.PORT, loginMessage, joinStatusUpdate);
    }
    
}
