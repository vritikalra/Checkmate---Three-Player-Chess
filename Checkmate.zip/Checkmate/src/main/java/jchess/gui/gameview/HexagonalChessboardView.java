package jchess.gui.gameview;

import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gui.image.CachedImageResizer;
import jchess.gui.image.ImageResizer;
import jchess.gui.image.Themes;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Stream;

public class HexagonalChessboardView extends ChessboardView {

    private static final boolean DEBUG = false;
    
    private static final GeoPoint ABSOLUTE_IMAGE_CENTER = new GeoPoint(1000,866);
    private static final int PIZZA_PIECES_COUNT = 6;
    private static final int CHESS_PIECES_SIZE = 125;
    
    private static ImageResizer imageResizer = new CachedImageResizer();
    private int chessboardSize;  //getWidth and getHigh also possible instead
    
    private Collection<BoardCoordinate> availableMoves = new ArrayList<>();
    private Square activeSquare;

    private Quad[] quads;

    private Quad[][] pizzaPiece1;

    public HexagonalChessboardView() {
        this.setActiveSquare(null);
        
        createQuads();
    }
    
    private void createQuads() {
        pizzaPiece1 = new Quad[4][4];
    
        //line l
        pizzaPiece1[0][0]=new Quad("l-8", 538, 65, 653, 65, 481, 165, 610, 190);
        pizzaPiece1[1][0]=new Quad("l-7", 653, 65, 769, 65, 610, 190, 740, 217);
        pizzaPiece1[2][0]=new Quad("l-6", 769, 65, 884, 67, 740, 217, 870, 239);
        pizzaPiece1[3][0]=new Quad("l-5", 884, 67, 1000, 66, 870, 239, 1000, 265);
        //line k
        pizzaPiece1[0][1]=new Quad("k-8", 481, 165, 610, 190, 422, 265, 567, 314);
        pizzaPiece1[1][1]=new Quad("k-7", getQuadById("l-7"), getQuadById("k-8"), 711, 364);
        pizzaPiece1[2][1]=new Quad("k-6", getQuadById("l-6"), getQuadById("k-7"), 855, 414);
        pizzaPiece1[3][1]=new Quad("k-5", getQuadById("l-5"), getQuadById("k-6"), 1000, 464);
        //line j
        pizzaPiece1[0][2]=new Quad("j-8", getQuadById("k-8").getLowerLeft().x, getQuadById("k-8").getLowerLeft().y, getQuadById("k-8").getLowerRight().x, getQuadById("k-8").getLowerRight().y, 366, 366, 523, 441);
        pizzaPiece1[1][2]=new Quad("j-7", getQuadById("k-7"), getQuadById("j-8"), 682, 515);
        pizzaPiece1[2][2]=new Quad("j-6", getQuadById("k-6"), getQuadById("j-7"), 842, 590);
        pizzaPiece1[3][2]=new Quad("j-5", getQuadById("k-5"), getQuadById("j-6"), 1000, 664);
        //line i
        pizzaPiece1[0][3]=new Quad("i-8", getQuadById("j-8").getLowerLeft().x, getQuadById("j-8").getLowerLeft().y, getQuadById("j-8").getLowerRight().x, getQuadById("j-8").getLowerRight().y, 307, 466, 480, 566);
        pizzaPiece1[1][3]=new Quad("i-7",getQuadById("j-7"),getQuadById("i-8"),653,665);
        pizzaPiece1[2][3]=new Quad("i-6",getQuadById("j-6"),getQuadById("i-7"),826,764);
        pizzaPiece1[3][3]=new Quad("i-5",getQuadById("j-5"),getQuadById("i-6"),1000,866);
        
        Quad[][] pizzaPiece2 = rotatePizzaPiece(pizzaPiece1);
        Quad[][] pizzaPiece3 = rotatePizzaPiece(pizzaPiece2);
        Quad[][] pizzaPiece4 = rotatePizzaPiece(pizzaPiece3);
        Quad[][] pizzaPiece5 = rotatePizzaPiece(pizzaPiece4);
        Quad[][] pizzaPiece6 = rotatePizzaPiece(pizzaPiece5);
    
        addBoardCoordinates(pizzaPiece1, new int[]{11,10,9,8}, new int[]{7,6,5,4}, true);   // top left
        addBoardCoordinates(pizzaPiece2, new int[]{11,10,9,8}, new int[]{11,10,9,8}, false);// top right
        addBoardCoordinates(pizzaPiece3, new int[]{7,6,5,4}, new int[]{11,10,9,8}, true);   // right
        addBoardCoordinates(pizzaPiece4, new int[]{7,6,5,4}, new int[]{0,1,2,3}, false);    // bottom right
        addBoardCoordinates(pizzaPiece5, new int[]{0,1,2,3}, new int[]{0,1,2,3}, true);    // bottom left
        addBoardCoordinates(pizzaPiece6, new int[]{0,1,2,3}, new int[]{7,6,5,4}, false);    // left
        
        quads = Stream.of(pizzaPiece1, pizzaPiece2, pizzaPiece3, pizzaPiece4, pizzaPiece5, pizzaPiece6)
                .flatMap(Arrays::stream)
                .flatMap(Arrays::stream)
                .toArray(Quad[]::new);
    }
    
    private void addBoardCoordinates(Quad[][] pizzaPiece, int[] xLegend, int[] yLegend, boolean invert) {
        for(int y=0; y<pizzaPiece[0].length; y++) {
            for(int x=0; x<pizzaPiece.length; x++) {
                Quad quad = invert ? pizzaPiece[y][x] : pizzaPiece[x][y];
                quad.setBoardCoordinate(new BoardCoordinate(xLegend[x], yLegend[y]));
            }
        }
    }

    private Quad getQuadById(String Id) {
        for (Quad[] quadArr : pizzaPiece1) {
            for(Quad quad:quadArr) {
                if (quad!=null && quad.getId().equals(Id)) {
                    return quad;
                }
            }
        }
        throw new RuntimeException("Quad not found: " + Id);
    }

    private Quad getQuad(BoardCoordinate boardCoordinate) {
        for (Quad quad : quads) {
            if (boardCoordinate.equals(quad.getBoardCoordinate())) {
                return quad;
            }
        }
        return null;
    }

    private Quad[][] rotatePizzaPiece(Quad[][] pizzaPiece) {
        Quad[][] rotated = new Quad[pizzaPiece.length][pizzaPiece[0].length];
        for(int y=0; y<pizzaPiece[0].length; y++) {
            for(int x=0; x<pizzaPiece.length; x++) {
                rotated[x][y] = rotateQuad(pizzaPiece[x][y]);
            }
        }
        return rotated;
    }

    private Quad rotateQuad(Quad quad) {
        return new Quad(
                "",
                rotate(quad.getUpperLeft()),
                rotate(quad.getUpperRight()),
                rotate(quad.getLowerLeft()),
                rotate(quad.getLowerRight())
        );
    }
    
    GeoPoint rotate(GeoPoint geoPoint) {
        final double angleDegree = 360.0 / PIZZA_PIECES_COUNT;
        
        double angleRadians = Math.toRadians(angleDegree);

        double dx = geoPoint.x - ABSOLUTE_IMAGE_CENTER.x;
        double dy = geoPoint.y - ABSOLUTE_IMAGE_CENTER.y;
    
        return new GeoPoint(
                ABSOLUTE_IMAGE_CENTER.x + dx * Math.cos(angleRadians) - dy * Math.sin(angleRadians),
                ABSOLUTE_IMAGE_CENTER.y + dx * Math.sin(angleRadians) + dy * Math.cos(angleRadians));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        drawChessboardImage(g);
        
        drawSelectedSquare(g);
    
        drawPieces(g);
        
        // draw available moves
        for(BoardCoordinate coordinate : availableMoves) {
            Quad quad = getQuad(coordinate);
            if(quad == null)
                continue;
    
            int midX = scaleX(quad.calculateMiddle().x);
            int midY = scaleY(quad.calculateMiddle().y);
            g.drawImage(getResizedAbleSquareImage(scaleX(CHESS_PIECES_SIZE)/2),
                    midX - scaleX(CHESS_PIECES_SIZE)/4,
                    midY - scaleY(CHESS_PIECES_SIZE)/4, null);
        }
        
        if(DEBUG) {
            drawAllQuads(g);
        }
    }
    
    private void drawChessboardImage(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        g.drawImage(getResizedChessboardImage(), 0, 0, this); // see javadoc for more info on the parameters
        
        g2d.dispose();
    }
    
    private void drawSelectedSquare(Graphics g) {
        if(activeSquare == null)
            return;
        
        Graphics2D g2d = (Graphics2D) g.create();
    
        for (Quad q : quads) {
            if(q.getBoardCoordinate().x != activeSquare.pozX || q.getBoardCoordinate().y != activeSquare.pozY)
                continue;
    
            Polygon polygon = new Polygon();
            polygon.addPoint(scaleX(q.getUpperLeft().x),scaleY(q.getUpperLeft().y));
            polygon.addPoint(scaleX(q.getUpperRight().x),scaleY(q.getUpperRight().y));
            polygon.addPoint(scaleX(q.getLowerRight().x),scaleY(q.getLowerRight().y));
            polygon.addPoint(scaleX(q.getLowerLeft().x),scaleY(q.getLowerLeft().y));
    
            g2d.setColor(new Color(255, 0, 0, 80));
            g2d.fillPolygon(polygon);
            
            break;
        }
        
        g2d.dispose();
    }
    
    private void drawPieces(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // draw pieces on squares
        for (Quad q : quads) {
            if (q.getPiece() != null) {
                int midX = scaleX(q.calculateMiddle().x);
                int midY = scaleY(q.calculateMiddle().y);
                q.getPiece().draw(g, midX - scaleX(CHESS_PIECES_SIZE)/2f, midY - scaleY(CHESS_PIECES_SIZE)/2f, scaleX(CHESS_PIECES_SIZE), this);
            }
        }
        
        g2d.dispose();
    }
    
    private void drawAllQuads(Graphics g) {
        int chessboardMax = chessboardSize - 1;
        g.setColor(Color.BLACK);
        g.drawLine(0, 0, chessboardMax, 0);
        g.drawLine(chessboardMax, chessboardMax, chessboardMax, 0);
        g.drawLine(chessboardMax, chessboardMax, 0, chessboardMax);
        g.drawLine(0, 0, 0, chessboardMax);
    
        Graphics2D dashed = (Graphics2D) g.create();
        dashed.setStroke(new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{5}, 0));

        for (Quad q : quads) {

            // draw edges
            dashed.setColor(Color.RED);
            dashed.drawLine(scaleX(q.getUpperLeft().x), scaleY(q.getUpperLeft().y), scaleX(q.getUpperRight().x), scaleY(q.getUpperRight().y));
            dashed.setColor(Color.BLUE);
            dashed.drawLine(scaleX(q.getLowerRight().x), scaleY(q.getLowerRight().y), scaleX(q.getUpperRight().x), scaleY(q.getUpperRight().y));
            dashed.setColor(Color.GREEN);
            dashed.drawLine(scaleX(q.getLowerRight().x), scaleY(q.getLowerRight().y), scaleX(q.getLowerLeft().x), scaleY(q.getLowerLeft().y));
            dashed.setColor(Color.CYAN);
            dashed.drawLine(scaleX(q.getUpperLeft().x), scaleY(q.getUpperLeft().y), scaleX(q.getLowerLeft().x), scaleY(q.getLowerLeft().y));
            
            // draw rect around center
            int midX = scaleX(q.calculateMiddle().x);
            int midY = scaleY(q.calculateMiddle().y);
            g.setColor(Color.YELLOW);
            final int r = 1;
            g.drawRoundRect( midX - r, midY - r, 2*r, 2*r, 2*r, 2*r);
            
            // draw inner rect for chess piece
            g.setColor(Color.BLACK);
            g.drawRect(
                    midX - scaleX(CHESS_PIECES_SIZE)/2,
                    midY - scaleY(CHESS_PIECES_SIZE)/2,
                    scaleX(CHESS_PIECES_SIZE),
                    scaleX(CHESS_PIECES_SIZE));
            
            // draw board coordinate
            String id = "";
            if(q.getBoardCoordinate() != null) {
                final String[] alphabet = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"};
                id += alphabet[q.getBoardCoordinate().x] + "," + (q.getBoardCoordinate().y+1);
            }
            g.setColor(Color.BLACK);
            g.drawString(id, midX - 10, midY - 7);
        }
    
        dashed.dispose();
    }

    private int scaleX(double absoluteX) {
        return (int) Math.round((absoluteX / 2000) * chessboardSize);
    }
    
    private int scaleY(double absoluteY) {
        return (int) Math.round((absoluteY / 2000) * chessboardSize);
    }

    private int descaleX(double relativeX) {
        return (int) Math.round((2000 * relativeX) / chessboardSize);
    }

    private int descaleY(double relativeY) {
        return (int) Math.round((2000 * relativeY) / chessboardSize);
    }
    
    @Override
    public void update(Graphics g) {
        repaint();
    }
    
    @Override
    public void resetPieces() {
        for(Quad quad : quads) {
            quad.setPiece(null);
        }
    }
    
    @Override
    public void setPiece(BoardCoordinate boardCoordinate, Piece piece) {
        for(Quad quad : quads) {
            if(quad.getBoardCoordinate().equals(boardCoordinate)) {
                quad.setPiece(piece);
                break;
            }
        }
    }
    
    @Override
    public void setAvailableMoves(Collection<BoardCoordinate> possible) {
        this.availableMoves = possible;
    }
    
    @Override
    public Square getSquare(int x, int y) {
        int absoluteX = descaleX(x);
        int absoluteY = descaleY(y);

        for(Quad q : quads) {
            if(q.contains(absoluteX, absoluteY)) {
               // System.out.println(q.getBoardCoordinate().x + ", "+q.getBoardCoordinate().y);
                return new Square(q.getBoardCoordinate().x, q.getBoardCoordinate().y, q.getPiece());
            }
        }
        return null;
    }
    
    
    @Override
    public Collection<BoardCoordinate> getAvailableMoves() {
        return availableMoves;
    }
    
    @Override
    public Square getActiveSquare() {
        return activeSquare;
    }
    
    @Override
    public void setActiveSquare(Square activeSquare) {
        this.activeSquare = activeSquare;
    }
    
    @Override
    public void updateChessboardBounds(int size, int x, int y) {
        chessboardSize = size;
        this.setSize(size,size);
        setLocation(x, y);
    }

    private Image getResizedChessboardImage() {
        return imageResizer.resizeImage(Themes.loadThemedImage("threePlayerChessboard.png", this), this.chessboardSize, this.chessboardSize);
    }
    
    private Image getResizedAbleSquareImage(int size) {
        return imageResizer.resizeImage(Themes.loadThemedImage("able_square.png", this), size, size);
    }

    @Override
    public double getWidthRatio() {
        return 1.154734411085450;
    }
}
