/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package jchess.gui.gameview;

import jchess.gamelogic.shared.PlayerColor;

/**
 * Class to represent separate wall-clock for one player.
 * Full ChessClock is represented by GameClock object (two clock - one for each player)
 */
public class CountDown {

    private int timeLeft; // in seconds
    private PlayerColor player;

    // for testing
    CountDown() {}

    CountDown(PlayerColor player, int timeLeft) {
        this.player = player;
        this.timeLeft = timeLeft;
    }

    public PlayerColor getPlayer() {
        return player;
    }

    /**
     * Method to get left time
     *
     * @return Player int integer of seconds
     */
    int getTimeLeft() {
        return this.timeLeft;
    }

    String getTimeLeftString() {
        return buildMinutesString() + ":" + buildSecondsString();
    }

    /**
     * Method to init clock with given time
     *
     * @param timeLeft tell method with how much time init clock in seconds
     */
    void setTimeLeft(int timeLeft) {
        this.timeLeft = timeLeft;
    }

    /**
     * Method to prepare time in nice looking String
     *
     * @return String of actual left game time with ':' digits in mm:ss format
     */
    public String toString() {
        return "["+player.getName()+"] " + buildMinutesString() + ":" + buildSecondsString();
    }

    private String buildMinutesString() {
        int minutes = this.getTimeLeft() / 60;

        if (minutes < 10) {
            return "0" + minutes;
        } else {
            return "" + minutes;
        }
    }

    private String buildSecondsString() {
        int seconds = this.getTimeLeft() % 60;

        if (seconds < 10) {
            return "0" + seconds;
        } else {
            return "" + seconds;
        }
    }
}
