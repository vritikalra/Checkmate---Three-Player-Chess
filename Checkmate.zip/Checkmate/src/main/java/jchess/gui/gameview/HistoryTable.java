/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.gameview;

import jchess.gamelogic.shared.PlayerColor;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;
import java.util.List;
import java.util.Map;

/**
 * managing GUI of
 * - move history as a table
 */
public class HistoryTable {

    final static int WIDTH = 180;

    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;

    HistoryTable() {
        super();

        this.tableModel = new DefaultTableModel();

        JTable table = new JTable(this.tableModel);
        table.setMinimumSize(new Dimension(WIDTH, 100));

        this.scrollPane = new JScrollPane(table);
        this.scrollPane.setMaximumSize(new Dimension(WIDTH, 100));
        this.scrollPane.setAutoscrolls(true);
    }

    /**
     * updates the history
     * @param history data containing the history
     */
    void showHistory(Map<PlayerColor, List<String>> history) {
        PlayerColor[] header = history.keySet().toArray(new PlayerColor[0]);
        String[][] moves = new String[header.length][];
        for(int i = 0; i < header.length; i++) {
            moves[i] = history.get(header[i]).toArray(new String[0]);
        }

        tableModel.setColumnIdentifiers(history.keySet().toArray());
        tableModel.setDataVector(moves, header);
    }

    JScrollPane getScrollPane() {
        return scrollPane;
    }
}
