/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.gameview;

import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PromotedPieceType;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class responsible for promotion of a pawn.
 * When pawn reach the end of the chessboard it can be change to rook,
 * bishop, queen or knight. For what pawn is promoted decides player.
 */
public class PawnPromotionWindow extends JDialog implements ActionListener {

    private JButton knightButton;
    private JButton bishopButton;
    private JButton rookButton;
    private JButton queenButton;
    private PromotedPieceType promoted;

    /**
     *
     * @param parent Information about the current piece
     * @param color the player color
     */
    PawnPromotionWindow(Frame parent, PlayerColor color) {
        super(parent);
        this.setTitle("Choose piece");
        this.setMinimumSize(new Dimension(520, 130));
        this.setSize(new Dimension(520, 130));
        this.setMaximumSize(new Dimension(520, 130));
        this.setResizable(false);
        this.setLayout(new GridLayout(1, 4));

        this.knightButton = new JButton();
        this.bishopButton = new JButton();
        this.rookButton = new JButton();
        this.queenButton = new JButton();

        this.knightButton.addActionListener(this);
        this.bishopButton.addActionListener(this);
        this.rookButton.addActionListener(this);
        this.queenButton.addActionListener(this);

        this.add(queenButton);
        this.add(rookButton);
        this.add(bishopButton);
        this.add(knightButton);
        setColor(color);
    }

    /**
     * Method setting the color fo promoted pawn
     *
     * @param playerColor The players color
     */
    public void setColor(PlayerColor playerColor) {
        knightButton.setIcon(new ImageIcon(new Piece(playerColor, GuiPieceFigure.KNIGHT_FIGURE).getImage(knightButton)));
        bishopButton.setIcon(new ImageIcon(new Piece(playerColor, GuiPieceFigure.BISHOP_FIGURE).getImage(bishopButton)));
        rookButton.setIcon(new ImageIcon(new Piece(playerColor, GuiPieceFigure.ROOK_FIGURE).getImage(rookButton)));
        queenButton.setIcon(new ImageIcon(new Piece(playerColor, GuiPieceFigure.QUEEN_FIGURE).getImage(queenButton)));
    }

    /**
     * Method wich is changing a pawn into queen, rook, bishop or knight
     *
     * @param arg0 Capt information about performed action
     */
    public void actionPerformed(ActionEvent arg0) {
        if (arg0.getSource() == queenButton) {
            promoted = PromotedPieceType.QUEEN_PROMOTION;
        } else if (arg0.getSource() == rookButton) {
            promoted = PromotedPieceType.ROOK_PROMOTION;
        } else if (arg0.getSource() == bishopButton) {
            promoted = PromotedPieceType.BISHOP_PROMOTION;
        } else {
            promoted = PromotedPieceType.KNIGHT_PROMOTION;
        }
        this.setVisible(false);
    }

    PromotedPieceType getPromoted() {
        return promoted;
    }
}
