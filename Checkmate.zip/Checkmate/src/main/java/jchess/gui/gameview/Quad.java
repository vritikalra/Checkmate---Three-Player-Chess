package jchess.gui.gameview;

import jchess.gamelogic.shared.BoardCoordinate;

import java.awt.Polygon;

public class Quad {
    //Watch out: Overwritten equals method

    private final String id;
    private final GeoPoint upperLeft;
    private final GeoPoint upperRight;
    private final GeoPoint lowerLeft;
    private final GeoPoint lowerRight;
    private final Polygon polygon;
    
    private BoardCoordinate boardCoordinate = null;
    private Piece piece = null;

    public Quad(String id, GeoPoint upperLeft, GeoPoint upperRight, GeoPoint lowerLeft, GeoPoint lowerRight) {
        this.id = id;
        this.upperLeft = upperLeft;
        this.upperRight = upperRight;
        this.lowerLeft = lowerLeft;
        this.lowerRight = lowerRight;

        this.polygon = new Polygon();
        polygon.addPoint((int)upperLeft.x,(int)upperLeft.y);
        polygon.addPoint((int)upperRight.x,(int)upperRight.y);
        polygon.addPoint((int)lowerRight.x,(int)lowerRight.y);
        polygon.addPoint((int)lowerLeft.x,(int)lowerLeft.y);
    }

    public Quad(String id, double upperLeftX, double upperLeftY, double upperRightX, double upperRightY, double lowerLeftX, double lowerLeftY, double lowerRightX, double lowerRightY) {
        this(id, new GeoPoint(upperLeftX, upperLeftY), new GeoPoint(upperRightX, upperRightY), new GeoPoint(lowerLeftX, lowerLeftY), new GeoPoint(lowerRightX, lowerRightY));
    }

    public Quad(String id, Quad upperQuad, Quad leftQuad, double lowerRightX, double lowerRightY) {
        this(id, upperQuad.getLowerLeft(), upperQuad.getLowerRight(), leftQuad.getLowerRight(), new GeoPoint(lowerRightX, lowerRightY));
    }
    
    public String getId() {
        return id;
    }
    
    public GeoPoint getUpperLeft() {
        return upperLeft;
    }

    public GeoPoint getUpperRight() {
        return upperRight;
    }

    public GeoPoint getLowerLeft() {
        return lowerLeft;
    }

    public GeoPoint getLowerRight() {
        return lowerRight;
    }
    
    public BoardCoordinate getBoardCoordinate() {
        return boardCoordinate;
    }
    
    public void setBoardCoordinate(BoardCoordinate boardCoordinate) {
        this.boardCoordinate = boardCoordinate;
    }
    
    public Piece getPiece() {
        return piece;
    }
    
    public void setPiece(Piece piece) {
        this.piece = piece;
    }
    
    public GeoPoint calculateMiddle() {
        return new GeoPoint(
                (upperLeft.x + upperRight.x + lowerLeft.x + lowerRight.x) / 4,
                (upperLeft.y + upperRight.y + lowerLeft.y + lowerRight.y) / 4
        );
    }

    boolean contains(double x, double y) {
        return polygon.contains(x, y);
    }
    
    @Override
    public String toString() {
        return "Quad{" +
                "upperLeft=" + upperLeft +
                ", upperRight=" + upperRight +
                ", lowerLeft=" + lowerLeft +
                ", lowerRight=" + lowerRight +
                '}';
    }
}
