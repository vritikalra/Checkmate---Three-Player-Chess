/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jchess.gui.gameview;

import jchess.gamelogic.shared.PlayerColor;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * managing GUI of the clock
 */
public class GameClock extends JPanel {

    static final int FIELD_WIDTH = 90; // width of one rectangle
    private static final int FIELD_HEIGHT = 30; // height of one rectangle
    private static final int MARGIN_TOP = 20; // margin to the top
    private static final int MARGIN_LEFT_STRING = 10, MARGIN_TOP_STRING = 20; // adjustments for strings
    private static final Font FONT = new Font("Serif", Font.PLAIN, 14);
    private static final Font FONT_ACTIVE = new Font("Serif", Font.BOLD, 14);

    private List<CountDown> countDowns;
    private PlayerColor activePlayer;

    /**
     * @param players all players
     */
    GameClock(List<PlayerColor> players) {
        super();

        // setup countdowns
        countDowns = players.stream().map(player -> new CountDown(player, 0)).collect(Collectors.toList());
    }

    void showTime(Map<PlayerColor, Integer> times) {
        for(Map.Entry<PlayerColor, Integer> playerTime : times.entrySet()) {
            Optional<CountDown> c = countDowns.stream().filter(countdown -> countdown.getPlayer() == playerTime.getKey()).findAny();
            c.ifPresent(countDown -> countDown.setTimeLeft(playerTime.getValue()));
        }
        repaint();
    }

    void setActivePlayer(PlayerColor activePlayer) {
        this.activePlayer = activePlayer;
        repaint();
    }

    /**
     * Annotation to superclass Graphics drawing the clock graphics
     *
     * @param g Graphics2D Capt object to paint
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawBackground(g2d);
        drawText(g2d);
    }

    /**
     * draws the background of the clock
     * @param g2d the Graphics2D object to paint
     */
    private void drawBackground(Graphics2D g2d) {
        // draw header
        for(int i = 0; i < countDowns.size(); i++) {
            g2d.setColor(countDowns.get(i).getPlayer().getTextBackgroundColor());
            g2d.fillRect(i*FIELD_WIDTH, MARGIN_TOP, FIELD_WIDTH, FIELD_HEIGHT); // background
            g2d.setColor(Color.BLACK);
            g2d.drawRect(i*FIELD_WIDTH, MARGIN_TOP, FIELD_WIDTH, FIELD_HEIGHT); // border
        }

        // draw clock
        g2d.setColor(Color.BLACK);
        for(int i = 0; i < countDowns.size(); i++) {
            g2d.drawRect(i*FIELD_WIDTH, MARGIN_TOP + FIELD_HEIGHT, FIELD_WIDTH, FIELD_HEIGHT);
        }
    }

    /**
     * draws the text of the lock
     * @param g2d the Graphics2D object to paint
     */
    private void drawText(Graphics2D g2d) {

        // draw header
        for(int i = 0; i < countDowns.size(); i++) {
            CountDown curr = countDowns.get(i);
            String playerName = curr.getPlayer().getName();
            g2d.setColor(curr.getPlayer().getTextColor());
            if(curr.getPlayer() == activePlayer) {
                g2d.setFont(FONT_ACTIVE);
                playerName = "> " + playerName;
            } else {
                g2d.setFont(FONT);
            }
            g2d.drawString(playerName, i*FIELD_WIDTH + MARGIN_LEFT_STRING, MARGIN_TOP + MARGIN_TOP_STRING);
        }

        // draw clock
        g2d.setFont(FONT);
        g2d.setColor(Color.BLACK);
        for(int i = 0; i < countDowns.size(); i++) {
            g2d.drawString(countDowns.get(i).getTimeLeftString(), i*FIELD_WIDTH + MARGIN_LEFT_STRING, MARGIN_TOP + FIELD_HEIGHT + MARGIN_TOP_STRING);
        }
    }

    /**
     * Annotation to superclass Graphics updating clock graphics
     *
     * @param g Graphics2D Capt object to paint
     */
    @Override
    public void update(Graphics g) {
        paint(g);
    }
}