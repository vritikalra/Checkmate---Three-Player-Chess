/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jchess.gui.gameview;

import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gui.image.CachedImageResizer;
import jchess.gui.image.ImageResizer;
import jchess.gui.image.Themes;
import jchess.network.gamemessages.Settings;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;

/**
 * managing GUI of
 * - chessboardView
 * - labels (1,2,3... and a,b,c...)
 * - pieces
 */
public class UsualChessboardView extends ChessboardView {
    
    static final int LABEL_THICKNESS = 20;
    
    private static ImageResizer imageResizer = new CachedImageResizer();
    
    private Collection<BoardCoordinate> availableMoves = new ArrayList<>();
    private Square activeSquare;
    private Image horizontalLabel;
    private Image verticalLabel;
    private float squareSize = 1;
    private int chessboardSize = 1;
    private Settings settings;
    
    public Square[][] squares;
    
    /**
     * ChessboardView class constructor
     *
     * @param settings      reference to Settings class object for this chessboardView
     */
    public UsualChessboardView(Settings settings) {
        this.settings = settings;
        this.setActiveSquare(null);
        resetPieces();
        this.setDoubleBuffered(true);
        this.createLabels();
    }
    
    /**
     * Method to set the piece of a specific field
     * If piece is null, then it is considered to be empty.
     * @param boardCoordinate
     * @param piece piece containing the figure and the player color
     */
    @Override
    public void setPiece(BoardCoordinate boardCoordinate, Piece piece) {
        squares[boardCoordinate.x][boardCoordinate.y].setPiece(piece);
    }
    
    @Override
    public void resetPieces() {
        this.squares = new Square[8][8]; // init of 8x8 chessboard
        for (int i = 0; i < 8; i++) {//create object for each square
            for (int y = 0; y < 8; y++) {
                this.squares[i][y] = new Square(i, y, null);
            }
        }
    }
    
    @Override
    public void setAvailableMoves(Collection<BoardCoordinate> availableMoves) {
        this.availableMoves = availableMoves;
    }
    
    @Override
    public Collection<BoardCoordinate> getAvailableMoves() {
        return availableMoves;
    }
    
    /**
     * method to get reference to square from given x and y integeres
     *
     * @param x x position on chessboard
     * @param y y position on chessboard
     * @return reference to searched square
     */
    @Override
    public Square getSquare(int x, int y) {
        
        // first check if the click was inside the board
        final int labelThickness = horizontalLabel.getHeight(null);
        int minX, minY, maxX, maxY;
        if(settings.renderLabels) {
            minX = labelThickness;
            minY = labelThickness;
            maxX = minX + chessboardSize;
            maxY = minY + chessboardSize;
        } else {
            minX = 0;
            minY = 0;
            maxX = minX + chessboardSize;
            maxY = minY + chessboardSize;
        }
        if (x < minX || x > maxX || y < minY || y > maxY) {
            System.out.println("click out of chessboard.");
            return null;
        }
        
        // then convert the x,y coordinates to the square object
        if (this.settings.renderLabels) {
            x -= this.horizontalLabel.getHeight(null);
            y -= this.horizontalLabel.getHeight(null);
        }
        
        int indexX = (int) (x / squareSize);
        int indexY = (int) (y / squareSize);
        
        return squares[indexX][adaptYToWhiteOnTop(indexY)];
    }
    
    /**
     * Annotations to superclass Game updating and painting the chessboardView
     */
    @Override
    public void update(Graphics g) {
        repaint();
    }
    
    /**
     * @return the position of the top left corner (inside the labels)
     */
    private Point getTopLeftPoint() {
        if (this.settings.renderLabels) {
            return new Point(verticalLabel.getWidth(null), this.horizontalLabel.getHeight(null));
        }
        return new Point(0,0);
    }
    
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Point topLeftPoint = this.getTopLeftPoint();
        if (this.settings.renderLabels) {
            if (topLeftPoint.x <= 0 && topLeftPoint.y <= 0) {
                //if renderLabels and (0,0), than draw it! (for first run)
                this.createLabels();
            }
            g2d.drawImage(this.horizontalLabel, 0, 0, null);
            g2d.drawImage(this.horizontalLabel, 0, chessboardSize + topLeftPoint.y, null);
            g2d.drawImage(this.verticalLabel, 0, 0, null);
            g2d.drawImage(this.verticalLabel, chessboardSize + topLeftPoint.x, 0, null);
        }
        
        //draw an Image of chessboard
        g2d.drawImage(getResizedChessboardImage(), topLeftPoint.x, topLeftPoint.y, null);
        
        // draw pieces on squares
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                if (this.squares[x][y].piece != null) {
                    this.squares[x][y].piece.draw(g, x * squareSize + topLeftPoint.x, adaptYToWhiteOnTop(y) * squareSize + topLeftPoint.y, (int) squareSize, this);
                }
            }
        }
        
        // draw selected square
        if(activeSquare != null) {
            g2d.drawImage(getResizedSelectedSquareImage(),
                    (int) (activeSquare.pozX * squareSize + topLeftPoint.x),
                    (int) (adaptYToWhiteOnTop(activeSquare.pozY) * squareSize + topLeftPoint.y), null);
        }
        
        // draw available moves
        for(BoardCoordinate coordinate : availableMoves) {
            g2d.drawImage(getResizedAbleSquareImage(),
                    (int) (coordinate.x * squareSize + topLeftPoint.x),
                    (int) (adaptYToWhiteOnTop(coordinate.y) * squareSize + topLeftPoint.y), null);
        }
    }
    
    private int adaptYToWhiteOnTop(int y) {
        if(settings.whiteOnTop)
            return 7 - y;
        else
            return y;
    }
    
    
    @Override
    public void updateChessboardBounds(int size, int x, int y) {
        chessboardSize = size;
        squareSize = size / 8f;
        if (settings.renderLabels) {
            size += 2 * (horizontalLabel.getHeight(null));
        }
        setSize(size, size);
        setLocation(x, y);
        createLabels();
    }

    private void createLabels() {
        
        final int squareSize = (int) this.squareSize;
        final int length = squareSize * 8 + (2 * LABEL_THICKNESS);
        
        // label on top and bottom
        BufferedImage image = new BufferedImage(length + LABEL_THICKNESS, LABEL_THICKNESS, BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D graphics = image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setColor(Color.white);
        
        graphics.fillRect(0, 0, length + LABEL_THICKNESS, LABEL_THICKNESS);
        graphics.setColor(Color.black);
        graphics.setFont(new Font("Arial", Font.BOLD, 12));
        int addX = (squareSize / 2);
        if (this.settings.renderLabels) {
            addX += LABEL_THICKNESS;
        }
        
        final String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h"};
        
        if (!this.settings.whiteOnTop) {
            for (int i = 1; i <= letters.length; i++) {
                graphics.drawString(letters[i - 1], (squareSize * (i - 1)) + addX, 10 + (LABEL_THICKNESS / 3));
            }
        } else {
            int j = 1;
            for (int i = letters.length; i > 0; i--, j++) {
                graphics.drawString(letters[i - 1], (squareSize * (j - 1)) + addX, 10 + (LABEL_THICKNESS / 3));
            }
        }
        graphics.dispose();
        this.horizontalLabel = image;
        
        // label on left and right
        image = new BufferedImage(LABEL_THICKNESS, length + LABEL_THICKNESS, BufferedImage.TYPE_3BYTE_BGR);
        graphics = image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setColor(Color.white);
        graphics.fillRect(0, 0, LABEL_THICKNESS, length + LABEL_THICKNESS);
        graphics.setColor(Color.black);
        graphics.setFont(new Font("Arial", Font.BOLD, 12));
        
        if (this.settings.whiteOnTop) {
            for (int i = 1; i <= 8; i++) {
                graphics.drawString(Integer.toString(i), 3 + (LABEL_THICKNESS / 3), (squareSize * (i - 1)) + addX);
            }
        } else {
            int j = 1;
            for (int i = 8; i > 0; i--, j++) {
                graphics.drawString(Integer.toString(i), 3 + (LABEL_THICKNESS / 3), (squareSize * (j - 1)) + addX);
            }
        }
        graphics.dispose();
        this.verticalLabel = image;
    }
    
    private Image getResizedChessboardImage() {
        return imageResizer.resizeImage(Themes.loadThemedImage("chessboard.png", this), chessboardSize, chessboardSize);
    }
    
    private Image getResizedAbleSquareImage() {
        return imageResizer.resizeImage(Themes.loadThemedImage("able_square.png", this), (int) squareSize, (int) squareSize);
    }
    
    private Image getResizedSelectedSquareImage() {
        return imageResizer.resizeImage(Themes.loadThemedImage("sel_square.png", this), (int) squareSize, (int) squareSize);
    }
    
    @Override
    public Square getActiveSquare() {
        return activeSquare;
    }
    
    @Override
    public void setActiveSquare(Square activeSquare) {
        this.activeSquare = activeSquare;
    }

    @Override
    public double getWidthRatio() {
        return 1;
    }
}
