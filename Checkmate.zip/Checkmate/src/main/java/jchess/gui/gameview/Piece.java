/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.gameview;

import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gui.image.CachedImageResizer;
import jchess.gui.image.ImageResizer;
import jchess.gui.image.Themes;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.ImageObserver;

public class Piece {
    
    private static ImageResizer imageResizer = new CachedImageResizer();

    private PlayerColor color;
    private GuiPieceFigure figure;
    
    Piece(PlayerColor color, GuiPieceFigure figure) {
        this.color = color;
        this.figure = figure;
    }

    void draw(Graphics g, float posX, float posY, int size, ImageObserver observer) {
        Graphics2D g2d = (Graphics2D) g;
        
        Image resizedImage = getResizedImage(size, observer);

        float centerX = (size - resizedImage.getWidth(null)) / 2f;
        float centerY = (size - resizedImage.getHeight(null)) / 2f;

        g2d.drawImage(resizedImage, (int) (posX + centerX), (int) (posY + centerY), null);
    }
    
    private Image getResizedImage(int size, ImageObserver observer) {
        return imageResizer.resizeImage(getImage(observer), size, size);
    }
    
    public Image getImage(ImageObserver observer) {
        String imageFileName = figure.imageName +"-"+ color.getSymbol()+".png";
        return Themes.loadThemedImage(imageFileName, observer);
    }

    public PlayerColor getColor() {
        return color;
    }

}
