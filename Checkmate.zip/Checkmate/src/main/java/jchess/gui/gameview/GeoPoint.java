package jchess.gui.gameview;

public class GeoPoint {
    
    final double x, y;

    public GeoPoint(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    @Override
    public String toString() {
        return x + "," + y;
    }
}
