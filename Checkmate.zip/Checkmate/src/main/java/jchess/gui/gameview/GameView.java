/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.gui.gameview;

import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.GameUpdateTarget;
import jchess.gamelogic.shared.GuiActionTarget;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PositionMessage;
import jchess.gamelogic.shared.PromotedPieceType;
import jchess.network.gamemessages.Settings;
import org.jdesktop.application.SingleFrameApplication;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * managing GUI of
 * - chessboardView
 * - clock
 * - move history table
 */
public class GameView extends JPanel implements GuiActionTarget, MouseListener, ComponentListener {

    // dependency injection
    private GameUpdateTarget updateTarget;
    private SingleFrameApplication singleFrameApplication;
    
    private PawnPromotionWindow promotionBox;
    
    private List<PlayerColor> players;
    private Settings settings;
    private boolean blockedChessboard;
    private ChessboardView chessboardView;
    private PlayerColor activePlayer;
    private GameClock gameClock;
    private HistoryTable historyTable;
    private Chat chat;
    

    public GameView(SingleFrameApplication singleFrameApplication, List<PlayerColor> players) {
        this.singleFrameApplication = singleFrameApplication;
        this.players = players;
        
        settings = new Settings();

        // history
        historyTable = new HistoryTable();
        debugShowDummy();
        add(historyTable.getScrollPane());

        // chessboardView
        if(players.size() == 2) {
            chessboardView = new UsualChessboardView(this.settings);
        } else if(players.size() == 3){
            settings.renderLabels=false;
            chessboardView = new HexagonalChessboardView();
        } else {
            throw new IllegalArgumentException();
        }
        
        chessboardView.setVisible(true);
        chessboardView.addMouseListener(this);
        chessboardView.setLocation(new Point(0, 0));
        this.add(chessboardView);

        // clock
        gameClock = new GameClock(players);
        gameClock.setSize(new Dimension(200, 100));
        add(gameClock);

        // chat
        chat = new Chat();
        chat.setSize(new Dimension(380, 100));
        chat.setLocation(new Point(0, 500));
        chat.setMinimumSize(new Dimension(400, 100));

        // miscellaneous
        blockedChessboard = false;
        setLayout(null);
        addComponentListener(this);
        setDoubleBuffered(true);
    }
    
    public void setUpdateTarget(GameUpdateTarget updateTarget) {
        this.updateTarget = updateTarget;
    }
    
    private void debugShowDummy() {
        Map<PlayerColor, List<String>> data = new HashMap<>();
        List<String> moves = new ArrayList<>();
        moves.add("abc");
        moves.add("def");
        data.put(PlayerColor.BLACK, moves);
        data.put(PlayerColor.WHITE, moves);
        historyTable.showHistory(data);
    }

    public void undo() {
        updateTarget.undo();
    }

    public void redo() {
        updateTarget.redo();
    }

    @Override
    public void showActivePlayer(PlayerColor activePlayer) {
        this.activePlayer = activePlayer;
        this.gameClock.setActivePlayer(activePlayer);
    }

    @Override
    public void showTime(Map<PlayerColor, Integer> playerTimes) {
        gameClock.showTime(playerTimes);
    }

    @Override
    public void showPosition(PositionMessage message) {
        chessboardView.resetPieces();
        for(PositionMessage.PiecePlacement placement : message.getPiecePlacements()) {
            chessboardView.setPiece(placement.getBoardCoordinate(), new Piece(placement.getPlayerColor(), placement.getFigure()));
        }
        repaint();
    }
    
    @Override
    public void showGameEnded(EndingType endingType, PlayerColor winner) {
        this.blockedChessboard = true;
        switch(endingType) {
            case CHECKMATE:
                JOptionPane.showMessageDialog(null, "Checkmate!\n"+winner+" has won.");
                break;
            case STALEMATE:
                JOptionPane.showMessageDialog(null, "Stalemate!\n"+winner+" has won.");
                break;
            case TIMEOUT:
                JOptionPane.showMessageDialog(null, "Timeout!\n"+winner+" has won.");
                break;
            case FANTASY_SORCERER_KILLS_ALL_ENEMY_PIECES:
                JOptionPane.showMessageDialog(null, "Congratulations, the sorcerer reached the opponents side. Now it can cast it's magic.");
                break;
        }
    }
    
    @Override
    public void showPossibleDestinationMarkers(Collection<BoardCoordinate> possible) {
        chessboardView.setAvailableMoves(possible);
        chessboardView.repaint();
    }

    @Override
    public PromotedPieceType showPromotionChooser(PlayerColor color) {
        return showPawnPromotionBox(color);
    }
    
    @Override
    public void unblockChessboard() {
        this.blockedChessboard = false;
    }
    
    private PromotedPieceType showPawnPromotionBox(PlayerColor playerColor) {
        if (promotionBox == null) {
            JFrame mainFrame = singleFrameApplication.getMainFrame();
            promotionBox = new PawnPromotionWindow(mainFrame, playerColor);
            promotionBox.setLocationRelativeTo(mainFrame);
            promotionBox.setModal(true);
            
        }
        promotionBox.setColor(playerColor);
        singleFrameApplication.show(promotionBox);
        
        return promotionBox.getPromoted();
    }

    // MouseListener:
    public void mouseClicked(MouseEvent arg0) { }

    public void mousePressed(MouseEvent event) {
        if (event.getButton() == MouseEvent.BUTTON3) {
            updateTarget.undo();
        } else if (event.getButton() == MouseEvent.BUTTON2 && settings.gameType == Settings.gameTypes.local) {
            updateTarget.redo();
        } else if (event.getButton() == MouseEvent.BUTTON1) {
            // left button
            if (!blockedChessboard) {
                int x = event.getX(); // x position of mouse
                int y = event.getY(); // y position of mouse

                Square selected = chessboardView.getSquare(x, y);
                Square active = chessboardView.getActiveSquare();
                if (active != null) {

                    Collection<BoardCoordinate> availableMoves = chessboardView.getAvailableMoves();
                    for(BoardCoordinate coord : availableMoves) {
                        if(coord.x == selected.pozX && coord.y == selected.pozY) {
                            updateTarget.possibleDestinationMarkerClicked(coord);
                            break;
                        }
                    }

                    // deselect when a square was active
                    chessboardView.setActiveSquare(null);
                    updateTarget.chessboardFieldDeselected();
                }

                if (selected.piece != null && selected.piece.getColor() == activePlayer
                        && (active == null || active.pozX != selected.pozX || active.pozY != selected.pozY)) {
                    // select a square, only if it is different from the last selection
                    updateTarget.chessboardFieldSelected(new BoardCoordinate(selected.pozX, selected.pozY));
                    chessboardView.setActiveSquare(selected);
                }
            } else {
                System.out.println("ChessboardView is blocked");
            }
        }
    }

    public void mouseReleased(MouseEvent arg0) { }

    public void mouseEntered(MouseEvent arg0) { }

    public void mouseExited(MouseEvent arg0) { }

    public void componentResized(ComponentEvent e) {

        final int MARGIN_BETWEEN = 20; // between board and right components
        final int MARGIN_BOTTOM = 10;

        int rightComponentsWidth = players.size() * GameClock.FIELD_WIDTH;
        int availableWidth = getWidth();
        int availableHeight = getHeight();
        int boardWidth = (int) Math.min(availableWidth - MARGIN_BETWEEN - rightComponentsWidth - MARGIN_BETWEEN, (availableHeight - MARGIN_BOTTOM)*chessboardView.getWidthRatio());
        int boardHeight = (int) (boardWidth/chessboardView.getWidthRatio());

        int posX = (availableWidth - boardWidth - MARGIN_BETWEEN - rightComponentsWidth - MARGIN_BETWEEN) / 2; // x coordinate of the board, centered
        int componentsX = posX + boardWidth + MARGIN_BETWEEN; // x coordinate of the components on the right of the board

        // update chessboardView
        if (settings.renderLabels) {
            chessboardView.updateChessboardBounds(boardWidth - 2 * UsualChessboardView.LABEL_THICKNESS, posX, 0);
        }
        else {
            chessboardView.updateChessboardBounds(boardWidth, posX, 0);
        }

        // update components on the right
        gameClock.setLocation(componentsX, 0);
        gameClock.setSize(componentsX, gameClock.getHeight());
        if (chat != null) {
            chat.setLocation(0, 0); // TODO where should the chat go?
            chat.setSize(componentsX, getHeight() - boardHeight);
        }
        historyTable.getScrollPane().setLocation(componentsX, gameClock.getY() + gameClock.getHeight());
        historyTable.getScrollPane().setSize(rightComponentsWidth, boardHeight - gameClock.getY() - gameClock.getHeight());
    }

    public void componentMoved(ComponentEvent e) { }

    public void componentShown(ComponentEvent e) { }

    public void componentHidden(ComponentEvent e) { }

    public Chat getChat() {
        return chat;
    }

    public Settings getSettings() {
        return settings;
    }

    public void setSettings(Settings settings) {
        this.settings = settings;
    }
}

