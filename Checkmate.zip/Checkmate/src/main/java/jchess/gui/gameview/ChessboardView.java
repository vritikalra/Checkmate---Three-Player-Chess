/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jchess.gui.gameview;

import jchess.gamelogic.shared.BoardCoordinate;

import javax.swing.JPanel;
import java.util.Collection;

/**
 * managing GUI of
 * - chessboard
 * - labels (1,2,3... and a,b,c...)
 * - pieces
 */
public abstract class ChessboardView extends JPanel {

    /**
     * empty the chessboard
     * therefore remove all pieces from the chessboard
     */
    public abstract void resetPieces();

    /**
     * set the piece of the desired field
     * @param boardCoordinate coordinate of the field
     * @param piece the piece
     */
    public abstract void setPiece(BoardCoordinate boardCoordinate, Piece piece);

    /**
     * get the field of the click event (x, y) coordinate in pixels
     * @param x x pixel coordinate
     * @param y y pixel coordinate
     * @return field which was clicked, null if there is no field
     */
    public abstract Square getSquare(int x, int y);

    /**
     * @return the field which is highlighted
     */
    public abstract Square getActiveSquare();

    /**
     * set active square which will be highlighted (i.e. the user has selected a piece)
     * @param activeSquare square which should be highlighted
     */
    public abstract void setActiveSquare(Square activeSquare);

    /**
     * set available moves (i.e. the user has selected a piece)
     * @param possible
     */
    public abstract void setAvailableMoves(Collection<BoardCoordinate> possible);

    /**
     * @return available moves
     */
    public abstract Collection<BoardCoordinate> getAvailableMoves();

    /**
     * updates the position and the size of the chessboard
     * @param size size of the chessboard
     * @param x x coordinate
     * @param y y coordinate
     */
    public abstract void updateChessboardBounds(int size, int x, int y);

    /**
     * ratio = width / height
     * therefore height = width / ratio
     * if it is quadratic then the ratio is 1
     * @return width to height ratio
     */
    public abstract double getWidthRatio();
    
}
