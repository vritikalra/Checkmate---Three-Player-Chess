package jchess.gamelogic;

import jchess.gamelogic.core.Game;
import jchess.gamelogic.fantasychess.FantasyChess;
import jchess.gamelogic.fantasychess.FantasyChessPieceFactory;
import jchess.gamelogic.outerhexagonal.OuterHexagonalChess;
import jchess.gamelogic.shared.GameUpdateTarget;
import jchess.gamelogic.shared.GuiActionTarget;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.usualchess.UsualChess;
import jchess.gamelogic.usualchess.UsualChessPieceFactory;

import java.util.List;

public class GameFactory {
    
    public GameUpdateTarget createGame(GuiActionTarget guiActionTarget, List<PlayerColor> players, int startingPlayer, boolean isFantasyChess) {
        Game game;
        
        switch (players.size()) {
            case 2:
                if(isFantasyChess)
                    game = new FantasyChess(new FantasyChessPieceFactory(new UsualChessPieceFactory())).createGame(players, startingPlayer);
                else
                    game = new UsualChess(new UsualChessPieceFactory()).createGame(players, startingPlayer);
                break;

            case 3:
                game = new OuterHexagonalChess(new UsualChessPieceFactory()).createGame(players, startingPlayer);
                break;
            
            default:
                throw new RuntimeException("Number of players not supported: " + players.size());
        }
        
        game.setGuiListener(guiActionTarget);
        
        return game;
    }
    
}
