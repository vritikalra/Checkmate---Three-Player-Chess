package jchess.gamelogic.usualchess;

import jchess.gamelogic.core.Game;
import jchess.gamelogic.core.MateEndingRule;
import jchess.gamelogic.core.ThreateningAnalyzer;
import jchess.gamelogic.core.chessboard.BoardCreationHelper;
import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.GenericChessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.export.GenericExporter;
import jchess.gamelogic.core.movement.GenericMovementCalculator;
import jchess.gamelogic.core.round.history.TurnHistory;
import jchess.gamelogic.core.round.history.TurnHistoryImpl;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;

import java.util.List;

public class UsualChess {
    
    private UsualChessPieceFactory pieceFactory;
    
    public UsualChess(UsualChessPieceFactory pieceFactory) {
        this.pieceFactory = pieceFactory;
    }
    
    public Game createGame(List<PlayerColor> players, int startingPlayer) {
        GenericChessboard board = new GenericChessboard();
        board.setFields(createFields(board));
        setPiecesOnBoard(board);
    
        TurnHistory turnHistory = new TurnHistoryImpl();
        Game game = new Game(board, turnHistory, new GenericExporter(), new ThreateningAnalyzer(board, new GenericMovementCalculator(board, turnHistory)), players, startingPlayer);
        addRules(game, board, turnHistory);
        return game;
    }
    
    public static Field[] createFields(Field.ChessboardInformationProvider cip) {
        Field[][] boardTop = BoardCreationHelper.createRectangularBoard(8, 4, cip, new int[]{7,6,5,4,3,2,1,0}, new int[]{3,2,1,0});
        Field[][] boardBottom = BoardCreationHelper.createRectangularBoard(8, 4, cip, new int[]{0,1,2,3,4,5,6,7}, new int[]{4,5,6,7});
        
        BoardCreationHelper.linkBoardsTogether(boardTop, boardBottom, 0, 8);
        BoardCreationHelper.linkBoardsTogether(boardBottom, boardTop, 0, 8);
    
        return BoardCreationHelper.flatten(boardTop, boardBottom);
    }
    
    public void addRules(Game game, Chessboard board, TurnHistory turnHistory) {
        game.addRule(new PawnPromotionRule(pieceFactory));
        game.addRule(new MateEndingRule(new GenericMovementCalculator(board, turnHistory), new ThreateningAnalyzer(board, new GenericMovementCalculator(board, turnHistory))));
    }
    
    private void setPiecesOnBoard(Chessboard board) {
        setFigures(board, 0, PlayerColor.BLACK);
        setPawns(board, 1, PlayerColor.BLACK);
        
        setPawns(board, 6, PlayerColor.WHITE);
        setFigures(board, 7, PlayerColor.WHITE);
    }
    
    /**
     * method set Figures in row (and set Queen and King to right position)
     */
    private void setFigures(Chessboard board, int y, PlayerColor player) {
        board.putChessPiece(board.getField(new BoardCoordinate(0, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(7, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(1, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(6, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(2, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(5, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(3, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(4, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KING_BEHAVIOUR, player, NeighbourShip.NORTH));
    }
    
    /**
     * method set Pawns in row
     */
    private void setPawns(Chessboard board, int y, PlayerColor player) {
        for(int x=0; x<=7; x++) {
            board.putChessPiece(board.getField(new BoardCoordinate(x, y)), pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.PAWN_BEHAVIOUR, player, NeighbourShip.NORTH));
        }
    }
    
}
