package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class EnPassantMovementPattern implements MovementPattern {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        return moveHistory.getEnemiesPreviousMoves(player).stream()
                .map(enemyMove -> calculateEnPassantMove(player, origin, enemyMove.getTo(), enemyMove.getFrom()))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }
    
    public Collection<MoveBlueprint> calculateEnPassantMove(PlayerColor player, Field origin, Field enPassantTarget, Field enemyMoveOrigin) {
        try {
            // enPassantTarget will be killed en passant
            if (enPassantTarget == null || !enPassantTarget.hasEnemy(player))
                return Collections.emptyList();
    
            if (!new Navigator(enPassantTarget).down().down().field().equals(enemyMoveOrigin))
                return Collections.emptyList();
        
            if (!enPassantTarget.hasEnPassantPiece())
                return Collections.emptyList();
        
            if (!origin.hasEnPassantPiece())
                return Collections.emptyList();
        
            if (isBesides(origin, enPassantTarget)) {
                return Collections.singletonList(new MoveBlueprint(origin, new Navigator(enPassantTarget).down(), null, enPassantTarget, enPassantTarget.hasCheckablePiece()));
            } else {
                return Collections.emptyList();
            }
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error calculating " + getClass().getSimpleName(), e);
            return Collections.emptyList();
        }
    }
    
    private boolean isBesides(Field origin, Field enPassantTarget) throws FieldNotOccupiedException {
        return new Navigator(origin).left().field().equals(enPassantTarget) || new Navigator(origin).right().field().equals(enPassantTarget);
    }
    
    @Override
    public boolean canHit() {
        return true;
    }
    
}
