package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KnightMovementPattern implements MovementPattern {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        try {
            ArrayList<MoveBlueprint> possibleMoves = new ArrayList<>();
    
            addPossibleMove(player, origin, new Navigator(origin).up().upLeft(), possibleMoves);
            addPossibleMove(player, origin, new Navigator(origin).up().upRight(), possibleMoves);
    
            addPossibleMove(player, origin, new Navigator(origin).right().upRight(), possibleMoves);
            addPossibleMove(player, origin, new Navigator(origin).right().downRight(), possibleMoves);
    
            addPossibleMove(player, origin, new Navigator(origin).down().downRight(), possibleMoves);
            addPossibleMove(player, origin, new Navigator(origin).down().downLeft(), possibleMoves);
    
            addPossibleMove(player, origin, new Navigator(origin).left().downLeft(), possibleMoves);
            addPossibleMove(player, origin, new Navigator(origin).left().upLeft(), possibleMoves);
    
            return possibleMoves;
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error calculating " + getClass().getSimpleName(), e);
            return Collections.emptyList();
        }
    }
    
    @Override
    public boolean canHit() {
        return true;
    }
    
    private void addPossibleMove(PlayerColor player, Field origin, Navigator destination, ArrayList<MoveBlueprint> possibleMoves) {
        if(destination.field().isEmpty() || destination.field().hasEnemy(player))
            possibleMoves.add(new MoveBlueprint(origin, destination, null, null, destination.field().hasEnemy(player) && destination.field().hasCheckablePiece()));
    }
    
}
