package jchess.gamelogic.usualchess;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.PromotionGameAction;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PromotedPieceType;

import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PawnPromotionRule implements Rule {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    private final UsualChessPieceFactory pieceFactory;
    
    public PawnPromotionRule(UsualChessPieceFactory pieceFactory) {
        this.pieceFactory = pieceFactory;
    }
    
    @Override
    public List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer) {
        try {
            ChessPiece promotionCandidate = chessboard.getChessPiece(move.getTo());
            
            if (promotionCandidate.isPromotable() && !new Navigator(move.getTo()).up().field().isOnBoard()) {
                PromotedPieceType promotedPieceType = actionTarget.showPromotionChooser(activePlayer);
                if(promotedPieceType == null)
                    return Collections.emptyList();
                
                ChessPiece promoted = createChessPiece(promotedPieceType, promotionCandidate);
                return Collections.singletonList(new PromotionGameAction(promotionCandidate, promoted));
            }
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error applying " + getClass().getSimpleName(), e);
        }
        return Collections.emptyList();
    }
    
    private ChessPiece createChessPiece(PromotedPieceType pieceType, ChessPiece currentPiece) {
        switch (pieceType) {
            case BISHOP_PROMOTION:    return pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
            case KNIGHT_PROMOTION:    return pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
            case ROOK_PROMOTION:      return pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
            case QUEEN_PROMOTION:     return pieceFactory.create(UsualChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
        }
        return null;
    }
    
}
