package jchess.gamelogic.usualchess;

import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.chesspiece.GenericChessPiece;
import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.usualchess.movementpatterns.CastlingMovementPattern;
import jchess.gamelogic.usualchess.movementpatterns.EnPassantMovementPattern;
import jchess.gamelogic.usualchess.movementpatterns.InitialMoveTwoStraightMovementPattern;
import jchess.gamelogic.usualchess.movementpatterns.KnightMovementPattern;
import jchess.gamelogic.usualchess.movementpatterns.LinearMovementPattern;

public class UsualChessPieceFactory {
    
    public enum PieceBehaviour {
        BISHOP_BEHAVIOUR,
        KING_BEHAVIOUR,
        KNIGHT_BEHAVIOUR,
        PAWN_BEHAVIOUR,
        QUEEN_BEHAVIOUR,
        ROOK_BEHAVIOUR
    }
    
    public ChessPiece create(PieceBehaviour piece, PlayerColor color, NeighbourShip facing) {
        switch (piece) {
            case BISHOP_BEHAVIOUR:  return createBishop(color, facing);
            case KING_BEHAVIOUR:    return createKing(color, facing);
            case KNIGHT_BEHAVIOUR:  return createKnight(color, facing);
            case QUEEN_BEHAVIOUR:   return createQueen(color, facing);
            case ROOK_BEHAVIOUR:    return createRook(color, facing);
            
            default:
            case PAWN_BEHAVIOUR:    return createPawn(color, facing);
        }
    }
    
    private ChessPiece createBishop(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.BISHOP_FIGURE);
        piece.setSymbolForNotation("B");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new LinearMovementPattern(true, true, false, 0, 0, Integer.MAX_VALUE));
        
        piece.setCastlingPartner(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        
        return piece;
    }
    
    private ChessPiece createKing(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.KING_FIGURE);
        piece.setSymbolForNotation("K");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new LinearMovementPattern(true, true, false, 1, 1, 1));
        piece.addMovementPattern(new CastlingMovementPattern());
        
        piece.setCastlingPartner(false);
        piece.setCheckable(true);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        
        return piece;
    }
    
    private ChessPiece createKnight(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.KNIGHT_FIGURE);
        piece.setSymbolForNotation("N");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new KnightMovementPattern());
        
        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        
        return piece;
    }
    
    private ChessPiece createPawn(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.PAWN_FIGURE);
        piece.setSymbolForNotation("");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new InitialMoveTwoStraightMovementPattern());
        piece.addMovementPattern(new LinearMovementPattern(false, false, false, 1, 0, 0));
        piece.addMovementPattern(new LinearMovementPattern(false, true, true, 0, 0, 1));
        piece.addMovementPattern(new EnPassantMovementPattern());
        
        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(true);
        piece.setPromotable(true);
        
        return piece;
    }
    
    private ChessPiece createQueen(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.QUEEN_FIGURE);
        piece.setSymbolForNotation("Q");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new LinearMovementPattern(true, true, false, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE));
        
        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        
        return piece;
    }
    
    private ChessPiece createRook(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);
        
        piece.setGuiPieceFigure(GuiPieceFigure.ROOK_FIGURE);
        piece.setSymbolForNotation("R");
    
        piece.setFacing(facing);
        piece.addMovementPattern(new LinearMovementPattern(true, true, false, Integer.MAX_VALUE, Integer.MAX_VALUE, 0));
        
        piece.setCastlingPartner(true);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        
        return piece;
    }
    
}
