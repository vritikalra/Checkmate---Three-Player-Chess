package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CastlingMovementPattern implements MovementPattern {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        try {
            // The current piece must not have been moved and must not be threatened
            if(origin.hasMovedPiece() || threatenedFields.contains(origin))
                return Collections.emptyList();
        
            List<MoveBlueprint> castlingMoves = new ArrayList<>();
            castlingMoves.addAll(castlingTo(player, threatenedFields, origin, NeighbourShip.WEST)); // long castling
            castlingMoves.addAll(castlingTo(player, threatenedFields, origin, NeighbourShip.EAST)); // short castling
            return castlingMoves;
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error calculating " + getClass().getSimpleName(), e);
            return Collections.emptyList();
        }
    }
    
    @Override
    public boolean canHit() {
        return false;
    }
    
    private List<MoveBlueprint> castlingTo(PlayerColor player, Set<Field> threatenedFields, Field castlingOrigin, NeighbourShip direction) throws FieldNotOccupiedException {
        Navigator directionNavigator = new Navigator(castlingOrigin).navigate(direction).navigate(direction);
        
        Field castlingDestination = directionNavigator.field();
        Field castlingPartnerField = directionNavigator.navigate(direction).field();
        if(castlingPartnerField.isEmpty())
            castlingPartnerField = directionNavigator.navigate(direction).field();
        
        // a castling partner must sit on the castling partner field and it must not have been moved
        if(!castlingPartnerField.hasCastlingPiece() || castlingPartnerField.hasEnemy(player) || castlingPartnerField.hasMovedPiece())
            return Collections.emptyList();
        
        if(isWayToCastlingPartnerOccupied(castlingOrigin, castlingPartnerField, direction))
            return Collections.emptyList();
        
        if(isWayToCastlingDestinationThreatened(threatenedFields, castlingOrigin, castlingDestination, direction))
            return Collections.emptyList();
    
        MoveBlueprint castlingPartnerMove = new MoveBlueprint(castlingPartnerField, calculateCastlingPartnerTargetField(castlingOrigin, direction), null, null, false);
        return Collections.singletonList(new MoveBlueprint(castlingOrigin, new Navigator(castlingOrigin).navigate(direction).navigate(direction), castlingPartnerMove, null, false));
    }
    
    private boolean isWayToCastlingPartnerOccupied(Field origin, Field castlingPartnerField, NeighbourShip direction) throws FieldNotOccupiedException {
        Navigator step = new Navigator(origin).navigate(direction);
        while(step.field().isOnBoard() && !step.field().equals(castlingPartnerField)) {
            if(!step.field().isEmpty())
                return true;
            step.navigate(direction);
        }
        return false;
    }
    
    private boolean isWayToCastlingDestinationThreatened(Set<Field> threatenedFields, Field castlingOrigin, Field castlingDestination, NeighbourShip direction) throws FieldNotOccupiedException {
        Navigator step = new Navigator(castlingOrigin).navigate(direction);
        while(step.field().isOnBoard() && !step.field().equals(castlingDestination)) {
            if(threatenedFields.contains(step.field()))
                return true;
            step.navigate(direction);
        }
        return false;
    }
    
    private Navigator calculateCastlingPartnerTargetField(Field castlingOrigin, NeighbourShip direction) throws FieldNotOccupiedException {
        return new Navigator(castlingOrigin).navigate(direction);
    }
    
}
