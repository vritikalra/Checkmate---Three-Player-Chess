package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LinearMovementPattern implements MovementPattern {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    private boolean canActBackwards;
    private boolean canHit;
    private boolean mustHit;
    
    private int maxStraight;
    private int maxSideways;
    private int maxDiagonal;
    
    public LinearMovementPattern(boolean canActBackwards, boolean canHit, boolean mustHit, int maxStraight, int maxSideways, int maxDiagonal) {
        this.canActBackwards = canActBackwards;
        this.canHit = canHit;
        this.mustHit = mustHit;
        this.maxStraight = maxStraight;
        this.maxSideways = maxSideways;
        this.maxDiagonal = maxDiagonal;
    }
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        Set<MoveBlueprint> possibleMoves = new HashSet<>();
        addForwardMoves(player, origin, possibleMoves);
        if (canActBackwards) {
            addBackwardsMoves(player, origin, possibleMoves);
        }
        return possibleMoves;
    }
    
    @Override
    public boolean canHit() {
        return canHit;
    }
    
    private void addForwardMoves(PlayerColor player, Field origin, Set<MoveBlueprint> possibleMoves) {
        addLine(player, origin,  NeighbourShip.NORTH, maxStraight, possibleMoves);
        addLine(player, origin, NeighbourShip.NORTH_WEST, maxDiagonal, possibleMoves);
        addLine(player, origin, NeighbourShip.NORTH_EAST, maxDiagonal, possibleMoves);
        addLine(player, origin, NeighbourShip.WEST, maxSideways, possibleMoves);
        addLine(player, origin, NeighbourShip.EAST, maxSideways, possibleMoves);
    }
    
    private void addBackwardsMoves(PlayerColor player, Field origin, Set<MoveBlueprint> possibleMoves) {
        addLine(player, origin, NeighbourShip.SOUTH_WEST, maxDiagonal, possibleMoves);
        addLine(player, origin,  NeighbourShip.SOUTH, maxStraight, possibleMoves);
        addLine(player, origin, NeighbourShip.SOUTH_EAST, maxDiagonal, possibleMoves);
    }
    
    private void addLine(PlayerColor player, Field origin, NeighbourShip direction, int maxDistance, Set<MoveBlueprint> possibleMoves) {
        Navigator navigator;
        try {
            navigator = new Navigator(origin).navigate(direction);
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error calculating " + getClass().getSimpleName() + " line in direction of " + direction, e);
            return;
        }
        int distance = 1;
        while(navigator.field().isOnBoard() && distance <= maxDistance) {
            
            if(navigator.field().isEmpty() && !mustHit || canHit && navigator.field().hasEnemy(player)) {
                possibleMoves.add(new MoveBlueprint(origin, navigator, null, null, !navigator.field().isEmpty() && navigator.field().hasCheckablePiece()));
            }
            
            if(!navigator.field().isEmpty()) {
                break;
            }
            
            distance++;
            navigator.navigate(direction);
        }
    }
    
}
