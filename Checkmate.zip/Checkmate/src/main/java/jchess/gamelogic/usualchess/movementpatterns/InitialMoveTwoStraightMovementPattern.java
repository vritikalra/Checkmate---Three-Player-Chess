package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InitialMoveTwoStraightMovementPattern implements MovementPattern {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        try {
            if(origin.hasMovedPiece())
                return Collections.emptyList();
            
            Navigator destination = new Navigator(origin).up();
            
            if(!destination.field().isEmpty())
                return Collections.emptyList();
            
            destination.up();
            
            if(!destination.field().isEmpty())
                return Collections.emptyList();
            
            return Collections.singletonList(new MoveBlueprint(origin, destination, null, null, false));
        } catch (FieldNotOccupiedException e) {
            log.log(Level.WARNING, "Error calculating " + getClass().getSimpleName(), e);
            return Collections.emptyList();
        }
    }
    
    @Override
    public boolean canHit() {
        return false;
    }
    
}
