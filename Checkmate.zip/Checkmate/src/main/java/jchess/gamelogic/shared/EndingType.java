package jchess.gamelogic.shared;

public enum EndingType {
    CHECKMATE,
    STALEMATE,

    TIMEOUT,

    FANTASY_SORCERER_KILLS_ALL_ENEMY_PIECES
}
