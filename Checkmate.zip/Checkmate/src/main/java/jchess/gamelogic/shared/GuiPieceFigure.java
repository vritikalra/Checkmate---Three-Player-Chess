package jchess.gamelogic.shared;

public enum GuiPieceFigure {
    
    NO_FIGURE("no figure set"),
    
    BISHOP_FIGURE("Bishop"),
    KING_FIGURE("King"),
    KNIGHT_FIGURE("Knight"),
    PAWN_FIGURE("Pawn"),
    QUEEN_FIGURE("Queen"),
    ROOK_FIGURE("Rook"),

    SORCERER_FIGURE("Sorcerer"),
    FAIRY_FIGURE("Fairy"),
    SEAHORSE_FIGURE("SeaHorse")
    ;

    final public String imageName;

    GuiPieceFigure(String imageName) {
        this.imageName = imageName;
    }
}
