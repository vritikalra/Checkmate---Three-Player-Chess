package jchess.gamelogic.shared;

import java.awt.Color;

public enum PlayerColor {

    WHITE("White", "W", Color.WHITE, Color.BLACK),
    BLACK("Black", "B", Color.BLACK, Color.WHITE),
    RED("Red", "R", Color.RED, Color.WHITE),

    NEUTRAL("Neutral", "N", Color.GRAY, Color.WHITE)
    
    ;

    private String name, symbol;
    private Color textBackgroundColor, textColor;

    PlayerColor(String name, String symbol, Color textBackgroundColor, Color textColor) {
        this.name = name;
        this.symbol = symbol;
        this.textBackgroundColor = textBackgroundColor;
        this.textColor = textColor;
    }

    public String getName() {
        return name;
    }

    public String getSymbol() {
        return symbol;
    }

    public Color getTextBackgroundColor() {
        return textBackgroundColor;
    }

    public Color getTextColor() {
        return textColor;
    }
}
