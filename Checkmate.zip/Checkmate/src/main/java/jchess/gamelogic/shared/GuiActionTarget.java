package jchess.gamelogic.shared;

import java.util.Collection;
import java.util.Map;

public interface GuiActionTarget {
    
    void showActivePlayer(PlayerColor activePlayer);

    void showTime(Map<PlayerColor, Integer> playerTimes);
    
    void showGameEnded(EndingType endingType, PlayerColor winner);
    
    void showPossibleDestinationMarkers(Collection<BoardCoordinate> possible);
    
    void showPosition(PositionMessage message);
    
    PromotedPieceType showPromotionChooser(PlayerColor color);
    
    void unblockChessboard();
    
}
