package jchess.gamelogic.shared;

import java.util.List;

public class PositionMessage {
    
    public static class PiecePlacement {
        private BoardCoordinate boardCoordinate;
        private GuiPieceFigure figure;
        private PlayerColor playerColor;
    
        public PiecePlacement(BoardCoordinate boardCoordinate, GuiPieceFigure figure, PlayerColor playerColor) {
            this.boardCoordinate = boardCoordinate;
            this.figure = figure;
            this.playerColor = playerColor;
        }
    
        public BoardCoordinate getBoardCoordinate() {
            return boardCoordinate;
        }
    
        public GuiPieceFigure getFigure() {
            return figure;
        }

        public PlayerColor getPlayerColor() {
            return playerColor;
        }
    
        @Override
        public String toString() {
            return "PiecePlacement{" +
                    "boardCoordinate=" + boardCoordinate +
                    ", figure=" + figure +
                    ", playerColor=" + playerColor +
                    '}';
        }
    }
    
    private List<PiecePlacement> piecePlacements;
    
    public PositionMessage(List<PiecePlacement> piecePlacements) {
        this.piecePlacements = piecePlacements;
    }
    
    public List<PiecePlacement> getPiecePlacements() {
        return piecePlacements;
    }
}
