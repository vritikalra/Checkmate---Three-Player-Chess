package jchess.gamelogic.shared;

public class BoardCoordinate {
    
    public final int x, y;
    
    public BoardCoordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        BoardCoordinate that = (BoardCoordinate) o;
        
        if (x != that.x) return false;
        return y == that.y;
    }
    
    @Override
    public int hashCode() {
        int result = x;
        result = 31 * result + y;
        return result;
    }
    
    @Override
    public String toString() {
        return "BoardCoordinate{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
