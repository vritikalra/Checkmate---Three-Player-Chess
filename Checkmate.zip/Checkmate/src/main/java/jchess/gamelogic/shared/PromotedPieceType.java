package jchess.gamelogic.shared;

public enum PromotedPieceType {
    QUEEN_PROMOTION, ROOK_PROMOTION, KNIGHT_PROMOTION, BISHOP_PROMOTION
}
