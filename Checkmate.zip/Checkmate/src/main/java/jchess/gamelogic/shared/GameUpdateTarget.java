package jchess.gamelogic.shared;

public interface GameUpdateTarget {
    
    void start(Integer timeInSeconds);
    
    void chessboardFieldSelected(BoardCoordinate field);
    
    void chessboardFieldDeselected();
    
    void possibleDestinationMarkerClicked(BoardCoordinate field);

    void undo();

    void redo();
}
