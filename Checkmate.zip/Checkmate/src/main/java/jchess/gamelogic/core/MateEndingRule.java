package jchess.gamelogic.core;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.MovementCalculator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class MateEndingRule implements Rule {
    
    private class MateEndingAnalyzingGameAction implements GameAction {
        
        private final Chessboard chessboard;
        private final PlayerColor activePlayer;
    
        public MateEndingAnalyzingGameAction(Chessboard chessboard, PlayerColor activePlayer) {
            this.chessboard = chessboard;
            this.activePlayer = activePlayer;
        }
    
        @Override
        public void apply(GameActionTarget actionTarget) {
            Collection<PlayerColor> livingPlayers = extractLivingPlayerColors(chessboard);
            
            if(livingPlayers.size() == 1) {
                actionTarget.showGameEnded(EndingType.STALEMATE, livingPlayers.iterator().next());
            }
            
            threateningAnalyzer.updateThreateningFlags(actionTarget);
            
            livingPlayers.forEach(player -> {
                if (!canAnyPieceMove(chessboard, actionTarget, player, threateningAnalyzer.getFieldsOnWhichPlayerIsThreatened(player))) {
                    
                    if (movementCalculator.isPlayerChecked(actionTarget, player)) {
                        actionTarget.showGameEnded(EndingType.CHECKMATE, activePlayer);
                    } else {
                        actionTarget.showGameEnded(EndingType.STALEMATE, activePlayer);
                    }
                }
            });
        }
        
        @Override
        public void applyReverse(GameActionTarget actionTarget) {
            actionTarget.unblockChessboard();
        }
        
        private Collection<PlayerColor> extractLivingPlayerColors(Chessboard chessboard) {
            return chessboard.getOccupiedFields().stream()
                    .map(field -> chessboard.getChessPiece(field).getColor())
                    .filter(playerColor -> playerColor != PlayerColor.NEUTRAL)
                    .collect(Collectors.toSet());
        }
        
        private boolean canAnyPieceMove(Chessboard chessboard, GameActionTarget actionTarget, PlayerColor player, Set<Field> threatenedFields) {
            return chessboard.getOccupiedFields().stream()
                    .filter(field -> !field.hasEnemy(player))
                    .anyMatch(field -> !movementCalculator.calculatePossibleMoves(actionTarget, player, field, threatenedFields, true).isEmpty());
        }
        
    }
    
    
    private final MovementCalculator movementCalculator;
    private final ThreateningAnalyzer threateningAnalyzer;
    
    
    public MateEndingRule(MovementCalculator movementCalculator, ThreateningAnalyzer threateningAnalyzer) {
        this.movementCalculator = movementCalculator;
        this.threateningAnalyzer = threateningAnalyzer;
    }
    
    
    @Override
    public List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer) {
        return Collections.singletonList(new MateEndingAnalyzingGameAction(chessboard, activePlayer));
    }
    
}
