package jchess.gamelogic.core.chessboard.field;

public class FieldLink {
    
    private final Field target;
    private final boolean facingChange;
    
    public FieldLink(Field target, boolean facingChange) {
        this.target = target;
        this.facingChange = facingChange;
    }
    
    public Field getTarget() {
        return target;
    }
    
    public boolean isFacingChange() {
        return facingChange;
    }
}
