package jchess.gamelogic.core.chessboard.field;

import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class Field {
    
    private final Logger log = Logger.getLogger(getClass().getName());

    public interface ChessboardInformationProvider {
        boolean getHasBeenMoved(Field field);
        boolean isCastlingPartner(Field field);
        boolean isCheckable(Field field);
        boolean hasEnemy(Field field, PlayerColor player);
        boolean isEnPassantEnabled(Field field);
        boolean isFieldEmpty(Field field);
        boolean isNeutral(Field field);
        boolean isPromotable(Field field);
        boolean isHittable(Field field);
        NeighbourShip getPieceFacing(Field field) throws FieldNotOccupiedException;
    }
    
    public class OffBoardField extends Field {
        public OffBoardField() {
            super(chessboardInformationProvider, null);
        }
        
        @Override
        public boolean isOnBoard() {
            return false;
        }
    
        @Override
        public FieldLink getNeighbour(NeighbourShip neighbourShip) {
            log.fine("Navigating outside of chessboard");
            return new FieldLink(this, false);
        }
    }
    
    private final ChessboardInformationProvider chessboardInformationProvider;
    private final BoardCoordinate boardCoordinate;
    
    private Map<NeighbourShip, FieldLink> neighbours = new HashMap<>();
    
    public Field(ChessboardInformationProvider chessboardInformationProvider, BoardCoordinate boardCoordinate) {
        this.boardCoordinate = boardCoordinate;
        this.chessboardInformationProvider = chessboardInformationProvider;
    }
    
    
    public void addNeighbour(NeighbourShip neighbourShip, FieldLink link) {
        neighbours.put(neighbourShip, link);
    }
    
    public BoardCoordinate getBoardCoordinate() {
        return boardCoordinate;
    }
    
    public FieldLink getNeighbour(NeighbourShip neighbourShip) {
        FieldLink neighbour = neighbours.get(neighbourShip);
        
        if(neighbour == null || neighbour.getTarget() == null)
            return new FieldLink(new OffBoardField(), false);
        else
            return neighbour;
    }
    
    public boolean isOnBoard() {
        return true;
    }
    
    public boolean hasEnemy(PlayerColor player) {
        return chessboardInformationProvider.hasEnemy(this, player);
    }
    
    public boolean isEmpty() {
        return chessboardInformationProvider.isFieldEmpty(this);
    }
    
    public boolean hasEnPassantPiece() {
        return chessboardInformationProvider.isEnPassantEnabled(this);
    }
    
    public boolean hasCheckablePiece() {
        return chessboardInformationProvider.isCheckable(this);
    }
    
    public boolean hasMovedPiece() {
        return chessboardInformationProvider.getHasBeenMoved(this);
    }
    
    public boolean hasCastlingPiece() {
        return chessboardInformationProvider.isCastlingPartner(this);
    }

    public boolean hasPromotablePiece() {
        return chessboardInformationProvider.isPromotable(this);
    }

    public boolean hasNeutralPiece() {
        return chessboardInformationProvider.isNeutral(this);
    }

    public boolean hasHittable() {
        return chessboardInformationProvider.isHittable(this);
    }
    
    public NeighbourShip getPieceFacing() throws FieldNotOccupiedException {
        return chessboardInformationProvider.getPieceFacing(this);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        Field field = (Field) o;
    
        return boardCoordinate != null && boardCoordinate.equals(field.boardCoordinate);
    }
    
    @Override
    public int hashCode() {
        return boardCoordinate != null ? boardCoordinate.hashCode() : 0;
    }
    
}
