package jchess.gamelogic.core.chessboard.field;

/**
 * A navigation was started from a field, that has no piece on it.
 */
public class FieldNotOccupiedException extends Exception {
    
    public FieldNotOccupiedException(String message) {
        super(message);
    }
    
}
