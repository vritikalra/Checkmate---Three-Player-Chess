package jchess.gamelogic.core.rules;

import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.chesspiece.PiecePromoter;

public interface RuleActionTarget extends PiecePromoter.PiecePromoterActionTarget {
    
    ChessPiece getHitChessPieceOfThisRound();
    
    
    
}
