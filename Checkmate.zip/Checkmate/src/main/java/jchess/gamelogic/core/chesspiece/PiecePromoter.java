package jchess.gamelogic.core.chesspiece;

import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PromotedPieceType;

public interface PiecePromoter {
    
    interface PiecePromoterActionTarget {
        PromotedPieceType showPromotionChooser(PlayerColor color);
    }
    
    ChessPiece promote(PiecePromoterActionTarget actionTarget, ChessPiece wantsToBePromoted);
    
}
