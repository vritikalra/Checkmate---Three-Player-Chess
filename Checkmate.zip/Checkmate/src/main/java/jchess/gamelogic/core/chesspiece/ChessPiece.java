package jchess.gamelogic.core.chesspiece;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;

import java.util.List;

public interface ChessPiece {

    void setGuiPieceFigure(GuiPieceFigure guiPieceFigure);
    
    void setSymbolForNotation(String symbolForNotation);
    
    boolean isCastlingPartner();
    
    void setCastlingPartner(boolean castlingPartner);
    
    PlayerColor getColor();
    
    GuiPieceFigure getGuiPieceFigure();
    
    boolean isEnPassantEnabled();
    
    void setEnPassantEnabled(boolean enPassantEnabled);
    
    boolean isPromotable();
    
    void setPromotable(boolean promotable);
    
    void addMovementPattern(MovementPattern movementPattern);
    
    List<MovementPattern> getMovementPatterns();
    
    boolean getHasBeenMoved();
    
    void incrementMovesCount();
    
    void decrementMovesCount();
    
    boolean isCheckable();
    
    void setCheckable(boolean checkable);
    
    Field getField();
    
    void setField(Field field);
    
    NeighbourShip getFacing();
    
    void setFacing(NeighbourShip facing);

    void setPiecePromoter(PiecePromoter promoter);

    PiecePromoter getPiecePromoter();

    boolean isHittable();
}
