package jchess.gamelogic.core.round;

import jchess.gamelogic.core.chesspiece.ChessPiece;

public class PromotionGameAction implements GameAction {
    
    private final ChessPiece promotionCandidate;
    private final ChessPiece promotedPiece;
    
    public PromotionGameAction(ChessPiece promotionCandidate, ChessPiece promotedPiece) {
        this.promotionCandidate = promotionCandidate;
        this.promotedPiece = promotedPiece;
    }
    
    @Override
    public void apply(GameActionTarget actionTarget) {
        actionTarget.removeChessPiece(promotionCandidate.getField());
        actionTarget.putChessPiece(promotionCandidate.getField(), promotedPiece);
    }
    
    @Override
    public void applyReverse(GameActionTarget actionTarget) {
        actionTarget.removeChessPiece(promotedPiece.getField());
        actionTarget.putChessPiece(promotedPiece.getField(), promotionCandidate);
    }
    
}
