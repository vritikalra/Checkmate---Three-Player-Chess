package jchess.gamelogic.core.clock;

import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Map;

public interface ClockActionTarget {
    
    void showGameEnded(EndingType endingType, PlayerColor winner);
    
    void nextTurn(boolean reverse); // e.g. timeout of a player
    
    void showTime(Map<PlayerColor, Integer> playerTimes);
    
}
