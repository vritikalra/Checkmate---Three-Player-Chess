package jchess.gamelogic.core;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.clock.Clock;
import jchess.gamelogic.core.clock.ClockActionTarget;
import jchess.gamelogic.core.export.Exporter;
import jchess.gamelogic.core.movement.GenericMovementCalculator;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.core.round.Move;
import jchess.gamelogic.core.round.Turn;
import jchess.gamelogic.core.round.history.TurnHistory;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.GameUpdateTarget;
import jchess.gamelogic.shared.GuiActionTarget;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PositionMessage;
import jchess.gamelogic.shared.PromotedPieceType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Game implements GameUpdateTarget, RuleActionTarget, ClockActionTarget, GameActionTarget {
    
    private GuiActionTarget guiListener = new GuiActionTarget() {
        @Override public void showActivePlayer(PlayerColor activePlayer) { }
        @Override public void showTime(Map<PlayerColor, Integer> playerTimes) { }
        @Override public void showGameEnded(EndingType endingType, PlayerColor winner) { }
        @Override public void showPossibleDestinationMarkers(Collection<BoardCoordinate> possible) { }
        @Override public void showPosition(PositionMessage message) { }
        @Override public PromotedPieceType showPromotionChooser(PlayerColor color) { return null; }
        @Override public void unblockChessboard() { }
    };
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    private final Chessboard chessboard;
    private final TurnHistory turnHistory;
    private final ArrayList<Rule> rules = new ArrayList<>();
    private final Exporter exporter;
    private final ThreateningAnalyzer threateningAnalyzer;
    
    private Field selectedField = null;
    
    // TODO: which affect does an undo have on the clock?
    private Clock clock;

    // player state
    private List<PlayerColor> players;
    private Turn currentRound;
    
    public Game(Chessboard chessboard, TurnHistory turnHistory, Exporter exporter, ThreateningAnalyzer threateningAnalyzer, List<PlayerColor> players, int startingPlayer) {
        this.chessboard = chessboard;
        this.turnHistory = turnHistory;
        this.exporter = exporter;
        this.threateningAnalyzer = threateningAnalyzer;
        this.players = players;
        
        this.currentRound = new Turn(PlayerColor.values()[startingPlayer % players.size()]);
    }
    
    
    public void addRule(Rule rule) {
        rules.add(rule);
    }
    
    public void setGuiListener(GuiActionTarget guiListener) {
        this.guiListener = guiListener;
    }
    
    @Override
    public void start(Integer timeInSeconds) {
        threateningAnalyzer.updateThreateningFlags(this);
        guiListener.showPosition(exporter.export(chessboard));
        guiListener.showActivePlayer(currentRound.getPlayerTurn());
        if(timeInSeconds != null) {
            clock = new Clock(this, players, timeInSeconds);
            clock.startTimer(currentRound.getPlayerTurn());
        }
    }
    
    @Override
    public void showGameEnded(EndingType endingType, PlayerColor winner) {
        if(clock != null)
            clock.stopTimer();
        guiListener.showGameEnded(endingType, winner);
    }
    
    @Override
    public void unblockChessboard() {
        guiListener.unblockChessboard();
    }
    
    @Override
    public ChessPiece getChessPiece(Field field) {
        return chessboard.getChessPiece(field);
    }
    
    @Override
    public void putChessPiece(Field field, ChessPiece chessPiece) {
        chessboard.putChessPiece(field, chessPiece);
    }
    
    @Override
    public void removeChessPiece(Field field) {
        chessboard.removeChessPiece(field);
    }
    
    @Override
    public PromotedPieceType showPromotionChooser(PlayerColor color) {
        return guiListener.showPromotionChooser(color);
    }
    
    @Override
    public void nextTurn(boolean reverse) {
        currentRound = new Turn(rotatePlayerColor(currentRound.getPlayerTurn(), reverse));
        
        guiListener.showActivePlayer(currentRound.getPlayerTurn());
        if(clock != null)
            clock.setActivePlayer(currentRound.getPlayerTurn());
    
        threateningAnalyzer.updateThreateningFlags(this);
        guiListener.showPosition(exporter.export(chessboard));
    }
    
    @Override
    public void showTime(Map<PlayerColor, Integer> playerTimes) {
        guiListener.showTime(playerTimes);
    }
    
    @Override
    public void chessboardFieldSelected(BoardCoordinate field) {
        selectedField = chessboard.getChessPiece(field).getField();
        
        if(chessboard.getChessPiece(selectedField).getColor() != currentRound.getPlayerTurn()) {
            selectedField = null;
            return;
        }
        
        guiListener.showPossibleDestinationMarkers(
                new GenericMovementCalculator(chessboard, turnHistory).calculatePossibleMoves(this, currentRound.getPlayerTurn(), selectedField, threateningAnalyzer.getFieldsOnWhichPlayerIsThreatened(currentRound.getPlayerTurn()), true).stream()
                        .filter(move -> !move.isChecking())
                        .map(MoveBlueprint::getTo)
                        .map(Field::getBoardCoordinate)
                        .collect(Collectors.toList())
        );
    }
    
    @Override
    public void chessboardFieldDeselected() {
        selectedField = null;
        guiListener.showPossibleDestinationMarkers(Collections.emptyList());
    }
    
    @Override
    public void possibleDestinationMarkerClicked(BoardCoordinate boardCoordinate) {
        if(selectedField == null)
            return;
        if(chessboard.getChessPiece(selectedField).getColor() != currentRound.getPlayerTurn())
            return;
        
        handlePlayerMove(selectedField, chessboard.getField(boardCoordinate));
    
        chessboardFieldDeselected();
        selectedField = null;
    }
    
    private void handlePlayerMove(Field origin, Field destination) {
        MoveBlueprint moveBlueprint = mapToMoveBlueprint(origin, destination);
        // the current round is added to the history after the move mapping is done because the MovementCalculator
        // will use the MovementPattern.MoveHistoryInformationProvider looking on the old state while the
        // post move actions expect the current move to be already present
        turnHistory.addTurn(currentRound);
        
        Move move = new Move(moveBlueprint, chessboard);
        currentRound.setPlayerMove(move);
        currentRound.applyMove(this);
        
        currentRound.setPostMoveAction(applyRules(moveBlueprint));
        currentRound.applyPostMoveActions(this);
        
        nextTurn(false);
    }
    
    private MoveBlueprint mapToMoveBlueprint(Field origin, Field destination) {
        return new GenericMovementCalculator(chessboard, turnHistory).calculatePossibleMoves(this, currentRound.getPlayerTurn(), origin, threateningAnalyzer.getFieldsOnWhichPlayerIsThreatened(currentRound.getPlayerTurn()), true).stream()
                .filter(move -> !move.isChecking())
                .filter(move -> move.getTo().equals(destination))
                .findFirst()
                .orElseThrow(NoSuchElementException::new);
    }
    
    private List<GameAction> applyRules(MoveBlueprint move) {
        return rules.stream()
                .map(rule -> rule.createPostMoveActions(chessboard, move, this, currentRound.getPlayerTurn()))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }
    
    private PlayerColor rotatePlayerColor(PlayerColor color, boolean reverse) {
        int increment = reverse ? -1 : +1;
        int nextPlayer = (color.ordinal()+increment) % players.size();
        if(nextPlayer < 0)
            nextPlayer += players.size();
        return PlayerColor.values()[nextPlayer];
    }
    
    @Override
    public void undo() {
        Turn round = turnHistory.undo();
        if(round != null) {
            round.applyAllReverse(this);
            nextTurn(true);
            chessboardFieldDeselected();
        }
    }

    @Override
    public void redo() {
        Turn round = turnHistory.redo();
        if(round != null) {
            round.applyAll(this);
            nextTurn(false);
            chessboardFieldDeselected();
        }
    }
    
    @Override
    public ChessPiece getHitChessPieceOfThisRound() {
        return turnHistory.getHitChessPieceOfThisRound();
    }
    
    // TODO: turnHistory list in GUI
    
    // TODO save & load game
    
}
