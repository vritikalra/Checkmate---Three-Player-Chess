package jchess.gamelogic.core.round;

public interface GameAction {
    
    void apply(GameActionTarget actionTarget);
    
    void applyReverse(GameActionTarget actionTarget);
    
}
