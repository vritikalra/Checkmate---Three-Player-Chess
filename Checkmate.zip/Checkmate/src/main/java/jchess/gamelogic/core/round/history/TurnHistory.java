package jchess.gamelogic.core.round.history;

import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.core.round.Turn;

/**
TODO: JavaDoc
 
 have a TurnHistory class, that does manipulations of the Chessboard using removePiece and setPiece
    This way we can drop Chessboard.move, which is complicated because of the history that has to be kept.
    Also a move can then manipulate the chessboard on it's will, which would be good for embedded move actions like
    castling and en passant as well as for future crazy moves
    Another problem of the current solution is, that there are two different places for manipulating the
    chessboard's data structure: the Rules (post-move actions) and Chessboard.move. This would also be solved by a
    separated class handling the TurnHistory. TurnHistory can be made appliable to a chessboard, e.g. MoveBlueprint.apply(Chessboard).
    This way we would respect the Open-Closed-Principle.
 */
public interface TurnHistory extends MovementPattern.MoveHistoryInformationProvider {
    
    void addTurn(Turn round);
    
    Turn redo();
    
    Turn undo();
    
    ChessPiece getHitChessPieceOfThisRound();
    
}
