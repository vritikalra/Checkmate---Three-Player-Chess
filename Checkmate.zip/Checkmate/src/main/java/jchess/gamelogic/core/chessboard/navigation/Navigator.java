package jchess.gamelogic.core.chessboard.navigation;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldLink;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;

public class Navigator {
    
    private final NeighbourShip startingFacing;
    
    private Field currentField;
    private NeighbourShip currentFacing;
    
    public Navigator(Field startingField) throws FieldNotOccupiedException {
        this.currentField = startingField;
        this.startingFacing = startingField.getPieceFacing();
        this.currentFacing = startingField.getPieceFacing();
    }
    
    /**
     * Navigate one jump to the specified direction.
     * @param direction desired direction of movement from the perspective of the chess piece for which this Navigator was created
     * @return for convenience returns this Navigator sitting on the next field specified by direction, so calls like Navigator.up().up().right() are possible
     */
    @SuppressWarnings("unused")
    public Navigator navigate(NeighbourShip direction) {
        if(currentFacing == NeighbourShip.SOUTH) {
            direction = direction.invert();
        }
        
        FieldLink link = currentField.getNeighbour(direction);
        if(link.isFacingChange()) {
            currentFacing = currentFacing.invert();
        }
        
        currentField = link.getTarget();
        
        return this;
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.NORTH)
     */
    @SuppressWarnings("unused")
    public Navigator up() {
        return navigate(NeighbourShip.NORTH);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.SOUTH)
     */
    @SuppressWarnings("unused")
    public Navigator down() {
        return navigate(NeighbourShip.SOUTH);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.WEST)
     */
    @SuppressWarnings("unused")
    public Navigator left() {
        return navigate(NeighbourShip.WEST);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.EAST)
     */
    @SuppressWarnings("unused")
    public Navigator right() {
        return navigate(NeighbourShip.EAST);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.NORTH_WEST)
     */
    @SuppressWarnings("unused")
    public Navigator upLeft() {
        return navigate(NeighbourShip.NORTH_WEST);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.NORTH_EAST)
     */
    @SuppressWarnings("unused")
    public Navigator upRight() {
        return navigate(NeighbourShip.NORTH_EAST);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.SOUTH_WEST)
     */
    @SuppressWarnings("unused")
    public Navigator downLeft() {
        return navigate(NeighbourShip.SOUTH_WEST);
    }
    
    /**
     * @see #navigate navigate(NeighbourShip.SOUTH_EAST)
     */
    @SuppressWarnings("unused")
    public Navigator downRight() {
        return navigate(NeighbourShip.SOUTH_EAST);
    }
    
    /**
     * After navigating along the desired location path using this Navigator, use this method to retrieve the destination Field of the navigation path.
     * @return the current field which this Navigator sits on
     */
    public Field field() {
        return currentField;
    }
    
    public boolean isFacingInverted() {
        return startingFacing != currentFacing;
    }
    
}
