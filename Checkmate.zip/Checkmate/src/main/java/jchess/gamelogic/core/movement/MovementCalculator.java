package jchess.gamelogic.core.movement;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.Set;

public interface MovementCalculator {
    
    /**
     * Possible moves can only be calculate from a players own perspective.
     *
     *
     * @param actionTarget
     * @param player
     * @param origin field on chessboard which is occupied by a chess piece for that the possible moves are calculated
     * @return Collection of possible moves if origin is occupied by a player of current view perspective, else empty collection
     */
    Collection<MoveBlueprint> calculatePossibleMoves(GameActionTarget actionTarget, PlayerColor player, Field origin, Set<Field> threatenedFields, boolean keepCheckablesSafe);
    
    boolean isPlayerChecked(GameActionTarget actionTarget, PlayerColor color);
}
