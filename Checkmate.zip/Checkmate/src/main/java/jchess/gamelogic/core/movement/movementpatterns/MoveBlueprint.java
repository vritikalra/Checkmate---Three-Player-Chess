package jchess.gamelogic.core.movement.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.navigation.Navigator;

import java.util.Objects;

public class MoveBlueprint {
    
    private Field from;
    private Field to;
    
    // TODO: replace by move-additional action
    private MoveBlueprint castlingEmbeddedMove;
    
    // TODO: replace by move-additional action
    private Field enPassantEffect;
    
    // TODO detect checking instead of letting each movement pattern set it
    private boolean checking;
    
    private boolean facingInverted;
    
    
    public MoveBlueprint(Field from, Field to, MoveBlueprint castlingEmbeddedMove, Field enPassantEffect, boolean checking, boolean facingInverted) {
        this.from = from;
        this.to = to;
        this.castlingEmbeddedMove = castlingEmbeddedMove;
        this.enPassantEffect = enPassantEffect;
        this.checking = checking;
        this.facingInverted = facingInverted;
    }
    
    // TODO: use a path rather then a Navigator
    public MoveBlueprint(Field from, Navigator navigatorAtDestination, MoveBlueprint castlingEmbeddedMove, Field enPassantEffect, boolean checking) {
        this.from = from;
        this.to = navigatorAtDestination.field();
        this.castlingEmbeddedMove = castlingEmbeddedMove;
        this.enPassantEffect = enPassantEffect;
        this.checking = checking;
        this.facingInverted = navigatorAtDestination.isFacingInverted();
    }
    
    public Field getFrom() {
        return from;
    }
    
    public Field getTo() {
        return to;
    }
    
    public boolean isCastling() {
        return castlingEmbeddedMove != null;
    }
    
    public MoveBlueprint getCastlingEmbeddedMove() {
        return castlingEmbeddedMove;
    }
    
    public boolean isEnPassant() {
        return enPassantEffect != null;
    }
    
    public Field getEnPassantEffect() {
        return enPassantEffect;
    }
    
    public boolean isChecking() {
        return checking;
    }
    
    public boolean isFacingInverted() {
        return facingInverted;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MoveBlueprint move = (MoveBlueprint) o;
        return checking == move.checking &&
                Objects.equals(from, move.from) &&
                Objects.equals(to, move.to) &&
                Objects.equals(castlingEmbeddedMove, move.castlingEmbeddedMove) &&
                Objects.equals(enPassantEffect, move.enPassantEffect);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(from, to, castlingEmbeddedMove, enPassantEffect, checking);
    }
}
