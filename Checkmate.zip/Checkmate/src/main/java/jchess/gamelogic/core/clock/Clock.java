package jchess.gamelogic.core.clock;

import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Clock implements Runnable {

    private ClockActionTarget actionTarget;
    private Thread thread;
    private boolean running;

    private Map<PlayerColor, Integer> playerTimes;
    private PlayerColor active;
    private PlayerColor nextActive; // will be set from outside of the thread (thread safety)

    public Clock(ClockActionTarget actionTarget, List<PlayerColor> players, int timeInSeconds) {
        this.actionTarget = actionTarget;
        this.thread = new Thread(this);
        this.playerTimes = new HashMap<>(players.size());
        this.running = false;
        for(PlayerColor player : players)
            this.playerTimes.put(player, timeInSeconds);
    }

    public void startTimer(PlayerColor active) {
        this.active = active;
        this.nextActive = active;
        this.running = true;
        thread.start();
    }
    
    public void stopTimer() {
        running = false;
    }

    public void setActivePlayer(PlayerColor active) {
        this.nextActive = active; // changes will be applied in the next tick
    }

    @Override
    public void run() {
        while (true) {

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                System.out.println("Error in clock thread: " + e);
            }

            if(!running)
                return;

            if(active != nextActive)
                active = nextActive; // apply changes

            int time = playerTimes.get(active);
            time--;
            playerTimes.put(active, time);
            actionTarget.showTime(playerTimes);

            // check if the current player ran out of time
            if (time == 0) {
                PlayerColor winner = getWinner();
                if(winner != null) {
                    // game is over because only one player is left
                    actionTarget.showGameEnded(EndingType.TIMEOUT, winner);
                    return;
                } else {
                    actionTarget.nextTurn(false);
                }
            }
        }
    }

    /**
     * checks if there is any winner because of timeout
     * @return the winner or null if there is no winner
     */
    private PlayerColor getWinner() {
        List<Map.Entry<PlayerColor, Integer>> alive = playerTimes.entrySet().stream().filter(i -> i.getValue() != 0).collect(Collectors.toList());
        if(alive.size() == 1)
            return alive.get(0).getKey();
        else
            return null;
    }
}
