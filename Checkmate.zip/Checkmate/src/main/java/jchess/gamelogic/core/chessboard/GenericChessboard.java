package jchess.gamelogic.core.chessboard;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class GenericChessboard implements Chessboard {
    
    private List<ChessPiece> chessPieces = new ArrayList<>();
    private Field[] fields;

    public void setFields(Field[] fields) {
        this.fields = fields;
    }
    
    @Override
    public ChessPiece getChessPiece(BoardCoordinate coordinate) {
        return findChessPiece(coordinate);
    }
    
    @Override
    public ChessPiece getChessPiece(Field field) {
        return chessPieces.stream()
                .filter(chessPiece -> chessPiece.getField().equals(field))
                .findFirst().orElse(null);
    }
    
    @Override
    public Field getField(BoardCoordinate coordinate) {
        return findField(coordinate);
    }
    
    @Override
    public Collection<Field> getOccupiedFields() {
        return chessPieces.stream()
                .map(ChessPiece::getField)
                .collect(Collectors.toList());
    }
    
    @Override
    public void putChessPiece(Field field, ChessPiece chessPiece) {
        chessPieces.add(chessPiece);
        chessPiece.setField(field);
    }
    
    @Override
    public void removeChessPiece(Field field) {
        ChessPiece chessPiece = findChessPiece(field);
        chessPieces.remove(chessPiece);
    }

    @Override
    public Field getRandomField() {
        return fields[(int)(Math.random()*fields.length)];
    }
    
    private ChessPiece findChessPiece(BoardCoordinate coordinate) {
        Field field = findField(coordinate);
        return chessPieces.stream()
                .filter(piece -> field.equals(piece.getField()))
                .findFirst().orElse(null);
    }
    
    private ChessPiece findChessPiece(Field field) {
        return chessPieces.stream()
                .filter(piece -> field.equals(piece.getField()))
                .findFirst().orElse(null);
    }
    
    private Field findField(BoardCoordinate coordinate) {
        return Arrays.stream(fields)
                .filter(field -> coordinate.equals(field.getBoardCoordinate()))
                .findFirst().orElse(null);
    }
    
    @Override
    public boolean getHasBeenMoved(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.getHasBeenMoved();
    }
    
    @Override
    public boolean isCastlingPartner(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.isCastlingPartner();
    }
    
    @Override
    public boolean isCheckable(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.isCheckable();
    }
    
    public boolean hasEnemy(Field field, PlayerColor player) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.getColor() != player;
    }
    
    @Override
    public boolean isEnPassantEnabled(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.isEnPassantEnabled();
    }
    
    @Override
    public boolean isFieldEmpty(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece == null;
    }

    @Override
    public boolean isNeutral(Field field) {
        return getChessPiece(field).getColor() == PlayerColor.NEUTRAL;
    }

    @Override
    public boolean isPromotable(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.isPromotable();
    }

    @Override
    public boolean isHittable(Field field) {
        ChessPiece chessPiece = getChessPiece(field);
        return chessPiece != null && chessPiece.isHittable();
    }

    /**
     * Creates a Navigator that starts on the provided field.
     * It faces the same direction as the chess piece on that field.
     *
     * @param field Starting field for the Navigator
     * @return A Navigator facing into the direction like the chess piece that sits on the provided field.
     * @throws FieldNotOccupiedException if the provided field has no chess piece on it
     */
    @Override
    public NeighbourShip getPieceFacing(Field field) throws FieldNotOccupiedException {
        ChessPiece chessPiece = getChessPiece(field);
        if (chessPiece == null) {
            throw new FieldNotOccupiedException("Trying to get Navigator from unoccupied field " + field.getBoardCoordinate());
        }
        
        return chessPiece.getFacing();
    }
    
}
