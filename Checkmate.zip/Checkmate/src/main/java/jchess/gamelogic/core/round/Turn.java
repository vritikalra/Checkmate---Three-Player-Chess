package jchess.gamelogic.core.round;

import jchess.gamelogic.shared.PlayerColor;

import java.util.Collections;
import java.util.List;

public class Turn {
    
    private final PlayerColor playerTurn;
    
    private Move playerMove = null;
    private List<GameAction> postMoveActions = Collections.emptyList();
    
    
    public Turn(PlayerColor playerTurn) {
        this.playerTurn = playerTurn;
    }
    
    
    public PlayerColor getPlayerTurn() {
        return playerTurn;
    }
    
    public Move getPlayerMove() {
        return playerMove;
    }
    
    public void setPlayerMove(Move playerMove) {
        this.playerMove = playerMove;
    }
    
    public void setPostMoveAction(List<GameAction> postMoveActions) {
        this.postMoveActions = postMoveActions;
    }
    
    public void applyAll(GameActionTarget actionTarget) {
        playerMove.apply(actionTarget);
        postMoveActions.forEach(postMoveAction -> postMoveAction.apply(actionTarget));
    }
    
    public void applyMove(GameActionTarget actionTarget) {
        playerMove.apply(actionTarget);
    }
    
    public void applyPostMoveActions(GameActionTarget actionTarget) {
        postMoveActions.forEach(postMoveAction -> postMoveAction.apply(actionTarget));
    }
    
    public void applyAllReverse(GameActionTarget actionTarget) {
        Collections.reverse(postMoveActions);
        postMoveActions.forEach(postMoveAction -> postMoveAction.applyReverse(actionTarget));
        Collections.reverse(postMoveActions);
        playerMove.applyReverse(actionTarget);
    }
    
}
