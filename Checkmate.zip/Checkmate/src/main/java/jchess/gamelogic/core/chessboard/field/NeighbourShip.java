package jchess.gamelogic.core.chessboard.field;

public enum NeighbourShip {
    NORTH,
    SOUTH,
    EAST,
    WEST,
    NORTH_WEST,
    NORTH_EAST,
    SOUTH_WEST,
    SOUTH_EAST
    ;
    
    static {
        NORTH.opposite = SOUTH;
        SOUTH.opposite = NORTH;
        EAST.opposite = WEST;
        WEST.opposite = EAST;
        NORTH_WEST.opposite = SOUTH_EAST;
        SOUTH_EAST.opposite = NORTH_WEST;
        SOUTH_WEST.opposite = NORTH_EAST;
        NORTH_EAST.opposite = SOUTH_WEST;
    }
    
    private NeighbourShip opposite;
    public NeighbourShip invert() {
        return opposite;
    }
}
