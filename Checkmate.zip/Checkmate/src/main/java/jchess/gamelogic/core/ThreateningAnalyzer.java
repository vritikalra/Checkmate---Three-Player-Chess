package jchess.gamelogic.core;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.GenericMovementCalculator;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Identifies all fields on the chessboard that can be attacked within the next move of the regarding player.
 *
 * TODO: update a flag on the fields in order to have easier access to the threatening information, e.g. Field.isThreatenedFor(PlayerColor)
 */
public class ThreateningAnalyzer {
    
    private final Chessboard chessboard;
    private final GenericMovementCalculator movements;
    
    private Map<PlayerColor, Set<Field>> fieldsOnWhichPlayerIsThreatened = new HashMap<>();
    
    public ThreateningAnalyzer(Chessboard chessboard, GenericMovementCalculator movements) {
        this.chessboard = chessboard;
        this.movements = movements;
    }
    
    public void updateThreateningFlags(GameActionTarget actionTarget) {
        // TODO: does this work if the king is checked? Because the possible moves will be calculated in the absence of any threatening knowledge.
        fieldsOnWhichPlayerIsThreatened = invert(calculateFieldsThatAreThreatenedByPlayer(actionTarget));
    }
    
    private Map<PlayerColor, Set<Field>> invert(Map<PlayerColor, Set<Field>> fieldsThatAreThreatenedByPlayer) {
        Map<PlayerColor, Set<Field>> inverted = new HashMap<>();
        
        for(PlayerColor threateningPlayer : PlayerColor.values()) {
            for(PlayerColor threatenedPlayer : PlayerColor.values()) {
                if(threatenedPlayer == threateningPlayer)
                    continue;
                
                inverted.computeIfAbsent(threatenedPlayer, playerColor -> new HashSet<>()).addAll(fieldsThatAreThreatenedByPlayer.get(threateningPlayer));
            }
        }
        
        return inverted;
    }
    
    private Map<PlayerColor, Set<Field>> calculateFieldsThatAreThreatenedByPlayer(GameActionTarget actionTarget) {
        Map<PlayerColor, Set<Field>> fieldsThatAreThreatenedByPlayer = new HashMap<>();
        for(PlayerColor player : PlayerColor.values()) {
            fieldsThatAreThreatenedByPlayer.put(player, calculateFieldsThatAreThreatenedByPlayer(actionTarget, player));
        }
        return fieldsThatAreThreatenedByPlayer;
    }
    
    /**
     * Iterate over every piece and calculate all possible moves.
     */
    private Set<Field> calculateFieldsThatAreThreatenedByPlayer(GameActionTarget actionTarget, PlayerColor player) {
        // TODO: include potential movements, that are only allowed under certain circumstances, e.g. the pawn only being allowed to hit diagonally if there is a piece
        return chessboard.getOccupiedFields().stream()
                .map(field -> movements.calculatePossibleMoves(actionTarget, player, field, Collections.emptySet(), false))
                .flatMap(Collection::stream)
                .flatMap(move -> Stream.of(move.getTo(), move.getEnPassantEffect()))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
    }
    
    public Set<Field> getFieldsOnWhichPlayerIsThreatened(PlayerColor perspective) {
        return fieldsOnWhichPlayerIsThreatened.getOrDefault(perspective, Collections.emptySet());
    }
    
}
