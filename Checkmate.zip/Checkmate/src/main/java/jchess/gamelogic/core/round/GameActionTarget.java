package jchess.gamelogic.core.round;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

public interface GameActionTarget extends Move.ChessboardInformationProvider {
    
    ChessPiece getChessPiece(Field field);
    void putChessPiece(Field field, ChessPiece chessPiece);
    void removeChessPiece(Field field);
    
    void showGameEnded(EndingType endingType, PlayerColor winner);
    
    void unblockChessboard();
    
}
