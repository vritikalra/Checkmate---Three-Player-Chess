package jchess.gamelogic.core.export;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.shared.PositionMessage;

public interface Exporter {
    
    PositionMessage export(Chessboard view);
    
}
