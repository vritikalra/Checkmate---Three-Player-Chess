package jchess.gamelogic.core.chessboard;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldLink;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.shared.BoardCoordinate;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.IntStream;

public class BoardCreationHelper {
    
    public static Field[][] createRectangularBoard(int width, int height, Field.ChessboardInformationProvider chessboardInformationProvider, int[] boardCoordinateXValues, int[] boardCoordinateYValues) {
        return dropBorder(createRectangularBoardWithBorder(width, height, chessboardInformationProvider, boardCoordinateXValues, boardCoordinateYValues));
    }
    
    private static Field[][] createRectangularBoardWithBorder(int width, int height, Field.ChessboardInformationProvider chessboardInformationProvider, int[] boardCoordinateXValues, int[] boardCoordinateYValues) {
        Field[][] boardWithBorder = createFields(width, height, chessboardInformationProvider, boardCoordinateXValues, boardCoordinateYValues);
        
        addLinksInsideOfBoard(boardWithBorder);
        
        return boardWithBorder;
    }
    
    private static Field[][] createFields(int width, int height, Field.ChessboardInformationProvider chessboardInformationProvider, int[] boardCoordinateXValues, int[] boardCoordinateYValues) {
        Field[][] boardWithBorder = new Field[width + 2][height + 2];
        
        // create fields
        IntStream.rangeClosed(1, height).forEach(
                y -> IntStream.rangeClosed(1, width).forEach(
                        x -> {
                            Field field = new Field(chessboardInformationProvider, new BoardCoordinate(boardCoordinateXValues[x-1], boardCoordinateYValues[y-1]));
                            boardWithBorder[x][y] = field;
                        }));
        
        return boardWithBorder;
    }
    
    private static void addLinksInsideOfBoard(Field[][] pizzaPieceWithFrame) {
        IntStream.rangeClosed(1, pizzaPieceWithFrame[0].length-2).forEach(
                y -> IntStream.rangeClosed(1, pizzaPieceWithFrame.length-2).forEach(
                        x -> linkFieldInside(pizzaPieceWithFrame, x, y)
                ));
    }
    
    private static void linkFieldInside(Field[][] boardWithFrame, int x, int y) {
        Field field = boardWithFrame[x][y];
        linkField(NeighbourShip.NORTH,      field, boardWithFrame[x  ][y-1]);
        linkField(NeighbourShip.NORTH_WEST, field, boardWithFrame[x-1][y-1]);
        linkField(NeighbourShip.WEST,       field, boardWithFrame[x-1][y  ]);
        linkField(NeighbourShip.SOUTH_WEST, field, boardWithFrame[x-1][y+1]);
        linkField(NeighbourShip.SOUTH,      field, boardWithFrame[x  ][y+1]);
        linkField(NeighbourShip.SOUTH_EAST, field, boardWithFrame[x+1][y+1]);
        linkField(NeighbourShip.EAST,       field, boardWithFrame[x+1][y  ]);
        linkField(NeighbourShip.NORTH_EAST, field, boardWithFrame[x+1][y-1]);
    }
    
    private static void linkField(NeighbourShip neighbourShip, Field from, Field to) {
        if(to == null)
            return;
        
        from.addNeighbour(neighbourShip, new FieldLink(to, false));
    }
    
    private static Field[][] dropBorder(Field[][] boardWithBorder) {
        Field[][] board = new Field[boardWithBorder.length - 2][boardWithBorder[0].length - 2];
        IntStream.range(0, board[0].length).forEach(
                y -> IntStream.range(0, board.length).forEach(
                        x -> board[x][y] = boardWithBorder[x+1][y+1]
                ));
        return board;
    }
    
    public static Field[] flatten(Field[][]... boards) {
        return Arrays.stream(boards)
                .flatMap(Arrays::stream)
                .flatMap(Arrays::stream)
                .filter(Objects::nonNull)
                .toArray(Field[]::new);
    }
    
    public static void linkBoardsTogether(Field[][] board1, Field[][] board2, int xStartIndex, int xEndIndex) {
        IntStream.range(xStartIndex, xEndIndex).forEach(
                x -> {
                    Field northWest = x<=xStartIndex ? null : board2[board2.length-1 - x + 1][0];
                    Field northEast = x>=xEndIndex-1 ? null : board2[board2.length-1 - x - 1][0];
                    Field north = board2[board2.length-1 - x][0];
                    linkFieldAtEdge(board1[x][0], northWest, north, northEast);
                });
    }
    
    private static void linkFieldAtEdge(Field field, Field northWest, Field north, Field northEast) {
        field.addNeighbour(NeighbourShip.NORTH,         new FieldLink(north, true));
        if(northWest != null) {
            field.addNeighbour(NeighbourShip.NORTH_WEST, new FieldLink(northWest, true));
        }
        if(northEast != null) {
            field.addNeighbour(NeighbourShip.NORTH_EAST, new FieldLink(northEast, true));
        }
    }
    
}
