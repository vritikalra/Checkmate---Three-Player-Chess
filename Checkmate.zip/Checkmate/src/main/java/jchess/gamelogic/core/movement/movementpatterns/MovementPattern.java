package jchess.gamelogic.core.movement.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface MovementPattern {
    
    interface MoveHistoryInformationProvider {
        List<MoveBlueprint> getEnemiesPreviousMoves(PlayerColor player);
    }
    
    Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields);
    
    boolean canHit();
    
}
