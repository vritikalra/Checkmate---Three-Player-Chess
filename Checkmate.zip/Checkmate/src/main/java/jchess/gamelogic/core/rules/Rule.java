package jchess.gamelogic.core.rules;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.shared.PlayerColor;

import java.util.List;

public interface Rule {
    
    List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer);
    
}
