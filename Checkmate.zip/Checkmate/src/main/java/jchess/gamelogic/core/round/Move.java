package jchess.gamelogic.core.round;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;

public class Move implements GameAction {
    
    public interface ChessboardInformationProvider {
        ChessPiece getChessPiece(Field field);
    }
    
    private MoveBlueprint blueprint;
    
    private ChessPiece movedPiece;
    
    private ChessPiece hitPiece;
    
    // TODO: replace by move-additional action
    private ChessPiece enPassantHitPiece;
    
    // TODO: replace by move-additional action
    private Move castlingEmbeddedMove;
    
    private boolean facingInverted;
    
    // TODO: add promotionChosenPiece
    
    
    public Move(MoveBlueprint blueprint, ChessPiece movedPiece, ChessPiece enPassantHitPiece, Move castlingEmbeddedMove, boolean facingInverted) {
        this.blueprint = blueprint;
        this.movedPiece = movedPiece;
        this.enPassantHitPiece = enPassantHitPiece;
        this.castlingEmbeddedMove = castlingEmbeddedMove;
        this.facingInverted = facingInverted;
    }
    
    public Move(MoveBlueprint blueprint, ChessboardInformationProvider cip) {
        this.blueprint = blueprint;
        this.movedPiece = cip.getChessPiece(blueprint.getFrom());
        this.enPassantHitPiece = cip.getChessPiece(blueprint.getEnPassantEffect());
        if(blueprint.isCastling()) {
            this.castlingEmbeddedMove = new Move(blueprint.getCastlingEmbeddedMove(), cip);
        }
        this.facingInverted = blueprint.isFacingInverted();
    }
    
    
    @Override
    public void apply(GameActionTarget actionTarget) {
        if(!blueprint.getTo().isEmpty()) {
            hitPiece = actionTarget.getChessPiece(blueprint.getTo());
        }
        
        movePiece(actionTarget, blueprint.getFrom(), blueprint.getTo());
        
        if(enPassantHitPiece != null) {
            actionTarget.removeChessPiece(enPassantHitPiece.getField());
        }
        if(castlingEmbeddedMove != null) {
            castlingEmbeddedMove.apply(actionTarget);
        }
        
        movedPiece.incrementMovesCount();
        invertFacing();
    }
    
    @Override
    public void applyReverse(GameActionTarget actionTarget) {
        invertFacing();
        movedPiece.decrementMovesCount();
        
        if(castlingEmbeddedMove != null) {
            castlingEmbeddedMove.applyReverse(actionTarget);
        }
        if(enPassantHitPiece != null) {
            actionTarget.putChessPiece(enPassantHitPiece.getField(), enPassantHitPiece);
        }
    
        movePiece(actionTarget, blueprint.getTo(), blueprint.getFrom());
        
        if(hitPiece != null) {
            actionTarget.putChessPiece(hitPiece.getField(), hitPiece);
        }
    }
    
    private void movePiece(GameActionTarget actionTarget, Field from, Field to) {
        if (!to.isEmpty()) {
            actionTarget.removeChessPiece(to);
        }
        actionTarget.removeChessPiece(from);
        actionTarget.putChessPiece(to, movedPiece);
    }
    
    public MoveBlueprint getBlueprint() {
        return blueprint;
    }
    
    public ChessPiece getMovedPiece() {
        return movedPiece;
    }
    
    public ChessPiece getHitPiece() {
        return hitPiece;
    }
    
    private void invertFacing() {
        if(facingInverted) {
            movedPiece.setFacing(movedPiece.getFacing().invert());
        }
    }
    
}
