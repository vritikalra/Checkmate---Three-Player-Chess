package jchess.gamelogic.core.round.history;

import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.Move;
import jchess.gamelogic.core.round.Turn;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class TurnHistoryImpl implements TurnHistory {
    
    private List<Turn> history = new ArrayList<>();
    private int historyIndex = 0;
    
    @Override
    public void addTurn(Turn round) {
        removeFutureMoves();
        
        history.add(round);
        historyIndex++;
    }
    
    private void removeFutureMoves() {
        while(history.size() > historyIndex) {
            history.remove(history.size() - 1);
        }
    }
    
    @Override
    public Turn redo() {
        if(historyIndex == history.size()-1)
            return null;
    
        historyIndex++;
        
        return history.get(historyIndex);
    }
    
    @Override
    public Turn undo() {
        if(historyIndex == 0)
            return null;
    
        historyIndex--;
        
        return history.get(historyIndex);
    }
    
    @Override
    public ChessPiece getHitChessPieceOfThisRound() {
        if(historyIndex == 0)
            return null;
        
        return history.get(historyIndex - 1).getPlayerMove().getHitPiece();
    }
    
    @Override
    public List<MoveBlueprint> getEnemiesPreviousMoves(PlayerColor player) {
        if(historyIndex <= 1)
            return Collections.emptyList();
        
        ArrayList<MoveBlueprint> enemiesPreviousMoves = new ArrayList<>();
        
        ListIterator<Turn> iter = history.listIterator(historyIndex);
        while(iter.hasPrevious()) {
            Move move = iter.previous().getPlayerMove();
            
            if(player == move.getMovedPiece().getColor())
                break;
            
            enemiesPreviousMoves.add(move.getBlueprint());
        }
        
        return enemiesPreviousMoves;
    }
    
}
