package jchess.gamelogic.core.movement;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.core.round.Move;
import jchess.gamelogic.core.round.history.TurnHistory;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class GenericMovementCalculator implements MovementCalculator {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    private final Chessboard chessboard;
    private final TurnHistory moveHistoryInformationProvider;
    
    public GenericMovementCalculator(Chessboard chessboard, TurnHistory moveHistoryInformationProvider) {
        this.chessboard = chessboard;
        this.moveHistoryInformationProvider = moveHistoryInformationProvider;
    }
    
    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(GameActionTarget actionTarget, PlayerColor player, Field origin, Set<Field> threatenedFields, boolean keepCheckablesSafe) {
        if(origin.isEmpty() || origin.hasEnemy(player)) {
            return Collections.emptyList();
        }
        
        // TODO: plug in possible moves acceptors to filter out unwanted moves by special rule sets
        
        return chessboard.getChessPiece(origin).getMovementPatterns().stream()
                .filter(movementPattern -> keepCheckablesSafe || movementPattern.canHit())
                .map(movementPattern -> {
                    try {
                        return movementPattern.calculatePossibleMoves(player, origin, moveHistoryInformationProvider, threatenedFields);
                    } catch (Exception e) {
                        log.log(Level.WARNING, "Error calculating possible moves for " + origin, e);
                        return Collections.<MoveBlueprint>emptyList();
                    }
                })
                .flatMap(Collection::stream)
                .filter(move -> move.getTo().isOnBoard())
                .filter(move -> move.getTo().isEmpty() || move.getTo().hasHittable())
                .filter(move -> !keepCheckablesSafe || checkablePiecesAreSafeAfterMove(actionTarget, move, player))
                .filter(move -> onlyAllowPromotablePiecesToHitPromotionGrantingPieces(origin, move))
                .collect(Collectors.toSet());
    }

    private boolean onlyAllowPromotablePiecesToHitPromotionGrantingPieces(Field attacker, MoveBlueprint move) {
        return !moveTargetFieldGrantsPromotion(move) || attacker.hasPromotablePiece() && moveTargetFieldGrantsPromotion(move);
    }

    private boolean moveTargetFieldGrantsPromotion(MoveBlueprint move) {
        return !move.getTo().isEmpty() && chessboard.getChessPiece(move.getTo()).getPiecePromoter() != null;
    }
    
    private boolean checkablePiecesAreSafeAfterMove(GameActionTarget actionTarget, MoveBlueprint moveBlueprint, PlayerColor player) {
        Move move = new Move(moveBlueprint, actionTarget);
        
        move.apply(actionTarget);
        
        boolean safeFromAllOtherPlayers = !isPlayerChecked(actionTarget, player);
    
        move.applyReverse(actionTarget);
        
        return safeFromAllOtherPlayers;
    }
    
    @Override
    public boolean isPlayerChecked(GameActionTarget actionTarget, PlayerColor player) {
        Set<Field> checkablePieces = getCheckablePiecesFields(player);
        
        return Arrays.stream(PlayerColor.values())
                .filter(otherPlayer -> otherPlayer != player)
                .anyMatch(otherPlayer -> isPlayerChecking(actionTarget, otherPlayer, checkablePieces));
    }
    
    private boolean isPlayerChecking(GameActionTarget actionTarget, PlayerColor checkingPlayer, Set<Field> checkablePieces) {
        return chessboard.getOccupiedFields().stream()
                .filter(field -> !field.hasEnemy(checkingPlayer))
                .map(field -> calculatePossibleMoves(actionTarget, checkingPlayer, field, Collections.emptySet(), false))
                .flatMap(Collection::stream)
                .anyMatch(move -> move.isChecking() && checkablePieces.contains(move.getTo()));
    }
    
    private Set<Field> getCheckablePiecesFields(PlayerColor player) {
        return chessboard.getOccupiedFields().stream()
                .filter(field -> !field.hasEnemy(player) && chessboard.getChessPiece(field).isCheckable())
                .collect(Collectors.toSet());
    }
    
}
