package jchess.gamelogic.core.chessboard;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.round.Move;
import jchess.gamelogic.shared.BoardCoordinate;

import java.util.Collection;

public interface Chessboard extends Field.ChessboardInformationProvider, Move.ChessboardInformationProvider {
    
    ChessPiece getChessPiece(BoardCoordinate coordinate);
    
    ChessPiece getChessPiece(Field field);
    
    Field getField(BoardCoordinate coordinate);
    
    Collection<Field> getOccupiedFields();
    
    void putChessPiece(Field field, ChessPiece chessPiece);
    
    void removeChessPiece(Field field);

    Field getRandomField();

}
