package jchess.gamelogic.core.chesspiece;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GenericChessPiece implements ChessPiece {

    private GuiPieceFigure guiPieceFigure = GuiPieceFigure.NO_FIGURE;
    private String symbolForNotation = " ";
    private PlayerColor color;
    private List<MovementPattern> movementPatterns = new ArrayList<>();
    private boolean enPassantEnabled = false;
    private boolean castlingPartner = false;
    private boolean promotable = false;
    private int movesCount = 0;
    private boolean checkable = false;
    private boolean hittable = true;
    private PiecePromoter piecePromoter = null;
    private Field field = null;
    private NeighbourShip facing = null;
    
    public GenericChessPiece(PlayerColor color) {
        this.color = color;
    }


    public void setGuiPieceFigure(GuiPieceFigure guiPieceFigure) {
        this.guiPieceFigure = guiPieceFigure;
    }

    public void setSymbolForNotation(String symbolForNotation) {
        this.symbolForNotation = symbolForNotation;
    }

    @Override
    public boolean isCastlingPartner() {
        return castlingPartner;
    }

    public void setCastlingPartner(boolean castlingPartner) {
        this.castlingPartner = castlingPartner;
    }

    public PlayerColor getColor() {
        return color;
    }

    public GuiPieceFigure getGuiPieceFigure() {
        return guiPieceFigure;
    }

    @Override
    public boolean isEnPassantEnabled() {
        return enPassantEnabled;
    }

    public void setEnPassantEnabled(boolean enPassantEnabled) {
        this.enPassantEnabled = enPassantEnabled;
    }

    public boolean isPromotable() {
        return promotable;
    }

    public void setPromotable(boolean promotable) {
        this.promotable = promotable;
    }

    public void addMovementPattern(MovementPattern movementPattern) {
        movementPatterns.add(movementPattern);
    }

    public List<MovementPattern> getMovementPatterns() {
        return Collections.unmodifiableList(movementPatterns);
    }

    @Override
    public boolean getHasBeenMoved() {
        return movesCount > 0;
    }
    
    @Override
    public void incrementMovesCount() {
        movesCount++;
    }
    
    @Override
    public void decrementMovesCount() {
        movesCount--;
    }

    @Override
    public boolean isCheckable() {
        return checkable;
    }

    public void setCheckable(boolean checkable) {
        this.checkable = checkable;
    }


    public boolean isHittable() {
        return hittable;
    }

    public void setHittable(boolean hittable) {
        this.hittable = hittable;
    }

    @Override
    public PiecePromoter getPiecePromoter() {
        return piecePromoter;
    }

    @Override
    public void setPiecePromoter(PiecePromoter piecePromoter) {
        this.piecePromoter = piecePromoter;
    }

    @Override
    public Field getField() {
        return field;
    }

    @Override
    public void setField(Field field) {
        this.field = field;
    }

    @Override
    public NeighbourShip getFacing() {
        return facing;
    }

    public void setFacing(NeighbourShip facing) {
        this.facing = facing;
    }


}
