package jchess.gamelogic.core.export;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.shared.PositionMessage;

import java.util.stream.Collectors;

public class GenericExporter implements Exporter {
    
    @Override
    public PositionMessage export(Chessboard view) {
        return new PositionMessage(
                view.getOccupiedFields().stream()
                        .map(field -> new PositionMessage.PiecePlacement(field.getBoardCoordinate(), view.getChessPiece(field).getGuiPieceFigure(), view.getChessPiece(field).getColor()))
                        .collect(Collectors.toList())
        );
    }
    
}
