package jchess.gamelogic.core;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Set;

public interface MateAnalyzer {
    
    EndingType analyze(GameActionTarget actionTarget, PlayerColor player, Set<Field> threatenedFields);
    
}
