package jchess.gamelogic.fantasychess;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.GameActionTarget;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.EndingType;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SorcererCastingMagicRule implements Rule {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    @Override
    public List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer) {
        Field moveTarget = move.getTo();
        try {
            if(!moveTarget.isEmpty() && !moveTarget.hasHittable() && !new Navigator(moveTarget).up().field().isOnBoard()) {
                return Collections.singletonList(new GameAction() {
                    private List<ChessPiece> killedEnemies = new ArrayList<>();
                    
                    @Override
                    public void apply(GameActionTarget actionTarget) {
                        actionTarget.showGameEnded(EndingType.FANTASY_SORCERER_KILLS_ALL_ENEMY_PIECES, activePlayer);
                        killEnemyPieces(actionTarget, activePlayer);
                    }
                    
                    @Override
                    public void applyReverse(GameActionTarget actionTarget) {
                        restoreEnemyPieces(actionTarget);
                        actionTarget.unblockChessboard();
                    }
                    
                    private void killEnemyPieces(GameActionTarget actionTarget, PlayerColor survivor) {
                        for(Field field : chessboard.getOccupiedFields()) {
                            if(field.hasEnemy(survivor)) {
                                killedEnemies.add(actionTarget.getChessPiece(field));
                                actionTarget.removeChessPiece(field);
                            }
                        }
                    }
                    
                    private void restoreEnemyPieces(GameActionTarget actionTarget) {
                        killedEnemies.forEach(chessPiece -> actionTarget.putChessPiece(chessPiece.getField(), chessPiece));
                    }
                });
            }
        } catch (FieldNotOccupiedException e) {
            log.log(Level.INFO, "Unexpected exception", e);
        }
        
        return Collections.emptyList();
    }

}
