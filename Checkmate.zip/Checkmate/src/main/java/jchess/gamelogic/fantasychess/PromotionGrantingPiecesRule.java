package jchess.gamelogic.fantasychess;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.chesspiece.PiecePromoter;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.PromotionGameAction;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collections;
import java.util.List;

public class PromotionGrantingPiecesRule implements Rule {

    @Override
    public List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer) {
    
        ChessPiece hitPiece = actionTarget.getHitChessPieceOfThisRound();
        if(hitPiece != null) {

            PiecePromoter promoter = hitPiece.getPiecePromoter();

            if(promoter != null) {
                ChessPiece promotionCandidate = chessboard.getChessPiece(move.getTo());
                ChessPiece promoted = promoter.promote(actionTarget, promotionCandidate);
                return Collections.singletonList(new PromotionGameAction(hitPiece, promoted));
            }
        }
        
        return Collections.emptyList();
    }
    
}
