package jchess.gamelogic.fantasychess.movementPatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.PlayerColor;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

// TODO: delete this class
public class RandomMovementPattern implements MovementPattern {
    
    public RandomMovementPattern() {
    }

    @Override
    public Collection<MoveBlueprint> calculatePossibleMoves(PlayerColor player, Field origin, MoveHistoryInformationProvider moveHistory, Set<Field> threatenedFields) {
        Set<MoveBlueprint> possibleMoves = new HashSet<>();
        addForwardMoves(origin, possibleMoves);
        return possibleMoves;
    }

    @Override
    public boolean canHit() {
        return false;
    }

    private void addForwardMoves(Field origin, Set<MoveBlueprint> possibleMoves) {
        /*
         * TODO: implement the code here
         *
         *     public ArrayList<Square> getAllMoves() {
         *         ArrayList<Square> list = new ArrayList<>();
         *         Square sq;
         *         Square sq1;
         *         for (int i = 0; i <= 7; i++) {
         *             for (int y = 0; y <= 7; y++) {
         *                 if (!this.isout(i, y)) {//out of bounds protection
         *                     sq = this.getChessboard().squares[i][y];
         *                     if (this.getSquare() == sq) {//if we're checking square on which is Sorcerer
         *                         continue;
         *                     }
         *                     if (this.checkPiece(i, y)) {//if square is empty
         *                         list.add(sq);
         *                     }
         *                 }
         *             }
         *         }
         *         return list;
         *     }
         */
    }



}
