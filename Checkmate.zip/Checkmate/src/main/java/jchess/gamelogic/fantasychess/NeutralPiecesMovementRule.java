package jchess.gamelogic.fantasychess;

import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.GameAction;
import jchess.gamelogic.core.round.Move;
import jchess.gamelogic.core.rules.Rule;
import jchess.gamelogic.core.rules.RuleActionTarget;
import jchess.gamelogic.shared.PlayerColor;

import java.util.ArrayList;
import java.util.List;

public class NeutralPiecesMovementRule implements Rule {

    @Override
    public List<GameAction> createPostMoveActions(Chessboard chessboard, MoveBlueprint move, RuleActionTarget actionTarget, PlayerColor activePlayer) {
        List<GameAction> gameActions = new ArrayList<>();
        
        for(Field neutralPieceLocation : chessboard.getOccupiedFields()) {
            if(neutralPieceLocation.hasNeutralPiece()) {

                Field randomField = chessboard.getRandomField();
                while(!randomField.isEmpty())
                    randomField = chessboard.getRandomField();

                gameActions.add(new Move(new MoveBlueprint(neutralPieceLocation, randomField, null, null, false, false), chessboard));
            }
        }
        
        return gameActions;
    }

}
