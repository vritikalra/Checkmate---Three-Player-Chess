package jchess.gamelogic.fantasychess;


import jchess.gamelogic.core.Game;
import jchess.gamelogic.core.MateEndingRule;
import jchess.gamelogic.core.ThreateningAnalyzer;
import jchess.gamelogic.core.chessboard.Chessboard;
import jchess.gamelogic.core.chessboard.GenericChessboard;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.export.GenericExporter;
import jchess.gamelogic.core.movement.GenericMovementCalculator;
import jchess.gamelogic.core.round.history.TurnHistory;
import jchess.gamelogic.core.round.history.TurnHistoryImpl;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.usualchess.PawnPromotionRule;
import jchess.gamelogic.usualchess.UsualChess;

import java.util.List;

public class FantasyChess {

    private FantasyChessPieceFactory pieceFactory;

    public FantasyChess(FantasyChessPieceFactory pieceFactory) {
        this.pieceFactory = pieceFactory;
    }

    public Game createGame(List<PlayerColor> players, int startingPlayer) {
        GenericChessboard board = new GenericChessboard();
        board.setFields(UsualChess.createFields(board));
        setPiecesOnBoard(board);

        TurnHistory turnHistory = new TurnHistoryImpl();
        Game game = new Game(board, turnHistory, new GenericExporter(), new ThreateningAnalyzer(board, new GenericMovementCalculator(board, turnHistory)), players, startingPlayer);
        addRules(game, board, turnHistory);
        return game;
    }

    private void addRules(Game game, Chessboard board, TurnHistory turnHistory) {
        game.addRule(new PawnPromotionRule(pieceFactory.getUsualChessPieceFactory()));

        game.addRule(new PromotionGrantingPiecesRule());
        game.addRule(new NeutralPiecesMovementRule());
        game.addRule(new SorcererCastingMagicRule());
        
        // In case one player is blocked completely, e.g. if only the sorcerer is left there is an enemy piece on every target direction
        game.addRule(new MateEndingRule(new GenericMovementCalculator(board, turnHistory), new ThreateningAnalyzer(board, new GenericMovementCalculator(board, turnHistory))));

    }

    private void setPiecesOnBoard(Chessboard board) {
        setFigures(board, 0, PlayerColor.BLACK);
        setPawns(board, 1, PlayerColor.BLACK);

        setPawns(board, 6, PlayerColor.WHITE);
        setFigures(board, 7, PlayerColor.WHITE);

        setNeutrals(board);
        setSorcerer(board);
    }
//pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, PlayerColor.BLACK, NeighbourShip.NORTH)

    private void setSorcerer(Chessboard board ) {
        {
            board.putChessPiece(board.getField(new BoardCoordinate(4, 0)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.SORCERER_BEHAVIOUR, PlayerColor.BLACK, NeighbourShip.NORTH));
            board.putChessPiece(board.getField(new BoardCoordinate(3,7 )), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.SORCERER_BEHAVIOUR, PlayerColor.WHITE, NeighbourShip.NORTH));
            board.putChessPiece(board.getField(new BoardCoordinate(3, 0)),pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, PlayerColor.BLACK, NeighbourShip.NORTH));
            board.putChessPiece(board.getField(new BoardCoordinate(4, 7)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, PlayerColor.WHITE, NeighbourShip.NORTH));
        }
    }

    private void setNeutrals(Chessboard board) {
        board.putChessPiece(board.getField(new BoardCoordinate(0, 4)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.FAIRY_BEHAVIOUR, PlayerColor.NEUTRAL, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(7, 3)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.SEAHORSE_BEHAVIOUR, PlayerColor.NEUTRAL, NeighbourShip.NORTH));
    }

    /**
     * method set Figures in row (and set Queen and King to right position)
     */
    private void setFigures(Chessboard board, int y, PlayerColor player) {
        board.putChessPiece(board.getField(new BoardCoordinate(0, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(7, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(1, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(6, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(2, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, player, NeighbourShip.NORTH));
        board.putChessPiece(board.getField(new BoardCoordinate(5, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, player, NeighbourShip.NORTH));
    }

    /**
     * method set Pawns in row
     */
    private void setPawns(Chessboard board, int y, PlayerColor player) {
        for(int x=0; x<=7; x++) {
            board.putChessPiece(board.getField(new BoardCoordinate(x, y)), pieceFactory.create(FantasyChessPieceFactory.PieceBehaviour.PAWN_BEHAVIOUR, player, NeighbourShip.NORTH));
        }
    }

}
