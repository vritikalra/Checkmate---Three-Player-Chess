package jchess.gamelogic.fantasychess;

import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.chesspiece.GenericChessPiece;
import jchess.gamelogic.core.chesspiece.PiecePromoter;
import jchess.gamelogic.fantasychess.movementPatterns.RandomMovementPattern;
import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;
import jchess.gamelogic.shared.PromotedPieceType;
import jchess.gamelogic.usualchess.UsualChessPieceFactory;
import jchess.gamelogic.usualchess.movementpatterns.LinearMovementPattern;

public class FantasyChessPieceFactory {

    public enum PieceBehaviour {
        // usual pieces
        BISHOP_BEHAVIOUR,
        //KING_BEHAVIOUR,
        KNIGHT_BEHAVIOUR,
        PAWN_BEHAVIOUR,
        QUEEN_BEHAVIOUR,
        ROOK_BEHAVIOUR,

        // fairy pieces
        FAIRY_BEHAVIOUR,
        SORCERER_BEHAVIOUR,
        SEAHORSE_BEHAVIOUR
    }

    private final UsualChessPieceFactory usualChessPieceFactory;

    public FantasyChessPieceFactory(UsualChessPieceFactory usualChessPieceFactory) {
        this.usualChessPieceFactory = usualChessPieceFactory;
    }

    public UsualChessPieceFactory getUsualChessPieceFactory() {
        return usualChessPieceFactory;
    }

    public ChessPiece create(PieceBehaviour piece, PlayerColor color, NeighbourShip facing) {
        switch (piece) {
            // usual pieces
            case BISHOP_BEHAVIOUR:  return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, color, facing);
            //case KING_BEHAVIOUR:    return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KING_BEHAVIOUR, color, facing);
            case KNIGHT_BEHAVIOUR:  return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, color, facing);
            case QUEEN_BEHAVIOUR:   return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, color, facing);
            case ROOK_BEHAVIOUR:    return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, color, facing);

            default:
            case PAWN_BEHAVIOUR:    return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.PAWN_BEHAVIOUR, color, facing);

            // fairy pieces
            case FAIRY_BEHAVIOUR:   return createFairy(color, facing);
            case SORCERER_BEHAVIOUR:return createSorcerer(color, facing);
            case SEAHORSE_BEHAVIOUR:   return createSeaHorse(color, facing);
        }
    }

    private ChessPiece createSorcerer(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);

        piece.setGuiPieceFigure(GuiPieceFigure.SORCERER_FIGURE);
        piece.setSymbolForNotation("S");

        piece.setFacing(facing);
        piece.addMovementPattern(new LinearMovementPattern(false, false, false, 1, 0, 1));

        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(false);
        //piece.setHittableDisabled(false);
        piece.setHittable(false);
        piece.setPiecePromoter(null);


        return piece;
    }

    private ChessPiece createFairy(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);

        piece.setGuiPieceFigure(GuiPieceFigure.FAIRY_FIGURE);
        piece.setSymbolForNotation("F");

        piece.setFacing(facing);
        piece.addMovementPattern(new RandomMovementPattern());

        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(true);
        piece.setHittable(true);

        piece.setPiecePromoter(new PiecePromoter() {
            @Override
            public ChessPiece promote(PiecePromoterActionTarget actionTarget, ChessPiece wantsToBePromoted) {
                PromotedPieceType pieceType = actionTarget.showPromotionChooser(wantsToBePromoted.getColor());
                if(pieceType == null)
                    return wantsToBePromoted;
                
                return createChessPiece(pieceType, wantsToBePromoted);
            }
    
            private ChessPiece createChessPiece(PromotedPieceType pieceType, ChessPiece currentPiece) {
                switch (pieceType) {
                    case BISHOP_PROMOTION:    return create(FantasyChessPieceFactory.PieceBehaviour.BISHOP_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
                    case KNIGHT_PROMOTION:    return create(FantasyChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
                    case ROOK_PROMOTION:      return create(FantasyChessPieceFactory.PieceBehaviour.ROOK_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
                    case QUEEN_PROMOTION:     return create(FantasyChessPieceFactory.PieceBehaviour.QUEEN_BEHAVIOUR, currentPiece.getColor(), currentPiece.getFacing());
            }
                return currentPiece;
            }
        });

        return piece;
    }

    private ChessPiece createSeaHorse(PlayerColor player, NeighbourShip facing) {
        GenericChessPiece piece = new GenericChessPiece(player);

        piece.setGuiPieceFigure(GuiPieceFigure.SEAHORSE_FIGURE);
        piece.setSymbolForNotation("SH");

        piece.setFacing(facing);
        piece.addMovementPattern(new RandomMovementPattern());

        piece.setCastlingPartner(false);
        piece.setCheckable(false);
        piece.setEnPassantEnabled(false);
        piece.setPromotable(true);
        piece.setHittable(true);
        piece.setPiecePromoter((actionTarget, promotionCandidate) -> {
            if(promotionCandidate.isPromotable()) {
                return usualChessPieceFactory.create(UsualChessPieceFactory.PieceBehaviour.KNIGHT_BEHAVIOUR, promotionCandidate.getColor(), promotionCandidate.getFacing());
            }
            return promotionCandidate;
        });

        return piece;
    }

}
