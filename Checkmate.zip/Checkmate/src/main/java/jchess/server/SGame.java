/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.server;

import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Player;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Holds players, observers and the move history
 */
class SGame implements Participant {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private NetworkGameMessageHub messageHub = new NetworkGameMessageHub();
    private Participant clientPlayer1;
    private Participant clientPlayer2;
    private String encryptedPassword;
    private ArrayList<Participant> clientObservers = new ArrayList<>();
    private Settings player1Set;
    private Settings player2Set;
    private Settings observerSettings;
    private boolean observersPermitted;
    private boolean chatEnabled;
    private ArrayList<MoveCoordinates> movesList = new ArrayList<>();
    
    SGame(String encryptedPassword, boolean observersPermitted, boolean chatEnabled) {
        this.encryptedPassword = encryptedPassword;
        this.chatEnabled = chatEnabled;
        this.observersPermitted = observersPermitted;
        
        messageHub.addConnectionExceptionListener(this::handleConnectionException);
        messageHub.addTarget(this);
    }
    
    private void generateSettings() //generate settings for both players and observers
    {
        
        player1Set = new Settings();
        player2Set = new Settings();
        
        player1Set.gameMode = Settings.gameModes.newGame;
        player1Set.playerWhite.setName(clientPlayer1.getNick());
        player1Set.playerBlack.setName(clientPlayer2.getNick());
        player1Set.playerWhite.setType(Player.playerTypes.localUser);
        player1Set.playerBlack.setType(Player.playerTypes.networkUser);
        player1Set.gameType = Settings.gameTypes.network;
        player1Set.whiteOnTop = true;
        
        player2Set.gameMode = Settings.gameModes.newGame;
        player2Set.playerWhite.setName(clientPlayer1.getNick());
        player2Set.playerBlack.setName(clientPlayer2.getNick());
        player2Set.playerWhite.setType(Player.playerTypes.networkUser);
        player2Set.playerBlack.setType(Player.playerTypes.localUser);
        player2Set.gameType = Settings.gameTypes.network;
        player2Set.whiteOnTop = false;
    
        if (observersPermitted) {
            observerSettings = new Settings();
            
            observerSettings.gameMode = Settings.gameModes.newGame;
            observerSettings.playerWhite.setName(clientPlayer1.getNick());
            observerSettings.playerBlack.setName(clientPlayer2.getNick());
            observerSettings.playerWhite.setType(Player.playerTypes.networkUser);
            observerSettings.playerBlack.setType(Player.playerTypes.networkUser);
            observerSettings.gameType = Settings.gameTypes.network;
            observerSettings.whiteOnTop = true;
        }
    }
    
    private void sendSettingsToAll() //send generated settings to all clients on this game
    {
        LOGGER.fine("running function: sendSettingsToAll()");
    
        sendTo(clientPlayer1, participant -> participant.sendSettings(player1Set));
        sendTo(clientPlayer2, participant -> participant.sendSettings(player2Set));
    
        if (observersPermitted) {
            for (Participant observer : clientObservers) {
                sendTo(observer, participant -> participant.sendSettings(observerSettings));
            }
        }
    }
    
    //send all settings and moves to new observer
    //warning: used only if game is already started
    private void sendSettingsAndMovesToNewObserver(Participant newObserver) {
        sendTo(newObserver, participant -> participant.sendSettings(observerSettings));
        
        for (MoveCoordinates move : movesList) {
            sendTo(newObserver, participant -> participant.sendMove(move));
        }
    }
    
    private void sendTo(Participant target, ParticipantFunction sendFunction) {
        if (target == null)
            return;
        
        try {
            sendFunction.send(target);
        } catch (IOException e) {
            handleConnectionException(target, e);
        }
    }
    
    private void handleConnectionException(Participant errorSource, IOException e) {
        Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e);
        messageHub.sendConnectionExceptionOccurred(errorSource);
    }
    
    boolean isPlayerSlotsOccupied() {//is it all playing players?
        return clientPlayer1 != null && clientPlayer2 != null;
    }
    
    private void startGame() {
        generateSettings();
    
        LOGGER.fine("Send settings to all");
        sendSettingsToAll();
    
        messageHub.sendChatMessage(this, "** Nowa gra, zaczna: " + clientPlayer1.getNick() + "**");
    }
    
    void addPlayer(Participant player) {
        LOGGER.fine("Player joins");
        
        messageHub.addTarget(player);
        player.setGameMessageHub(messageHub);
        
        if (clientPlayer1 == null) {
            clientPlayer1 = player;
            LOGGER.fine("Player1 connected");
        } else if (clientPlayer2 == null) {
            clientPlayer2 = player;
            LOGGER.fine("Player2 connected");
        }
        messageHub.sendChatMessage(this, "** Gracz " + player.getNick() + " dołączył do gry **");
        
        if (isPlayerSlotsOccupied()) {
            startGame();
        } else {
            messageHub.sendChatMessage(this, "** Oczekiwanie na drugiego gracza **");
        }
    }
    
    void addObserver(Participant observer) {
        LOGGER.fine("Observer joins");
        
        messageHub.addTarget(observer);
        observer.setGameMessageHub(messageHub);
        
        clientObservers.add(observer);
        
        messageHub.sendChatMessage(this, "** Obserwator " + observer.getNick() + " dołączył do gry **");
        
        if (isPlayerSlotsOccupied()) {
            // a game already has begun
            sendSettingsAndMovesToNewObserver(observer);
        }
    }
    
    Participant getClientPlayer1() {
        return clientPlayer1;
    }
    
    Participant getClientPlayer2() {
        return clientPlayer2;
    }
    
    String getEncryptedPassword() {
        return encryptedPassword;
    }
    
    boolean isObserversPermitted() {
        return observersPermitted;
    }
    
    @Override
    public void sendMove(MoveCoordinates move) {
        movesList.add(move);
    }
    
    @Override
    public void sendUndoPositive() {
        if (movesList.isEmpty()) {
            LOGGER.info("No moves present, yet and undo was agreed");
            return;
        }
        
        movesList.remove(movesList.size() - 1);
    }
    
    @Override
    public String getNick() {
        return "Server";
    }
    
    @Override
    public void sendChatMessage(Participant originator, String message) {
    }
    
    @Override
    public void sendErrorConnection() {
    }
    
    @Override
    public void sendSettings(Settings settings) {
    }
    
    @Override
    public void sendUndoAsk() {
    }
    
    @Override
    public void sendUndoNegative() {
    }
    
    @Override
    public void setGameMessageHub(GameMessageHub hub) {
    }
    
}