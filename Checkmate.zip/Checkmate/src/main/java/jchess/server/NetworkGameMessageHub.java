package jchess.server;

import jchess.network.gamemessages.MoveCoordinates;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NetworkGameMessageHub implements GameMessageHub {
    
    interface ConnectionExceptionListener {
        void connectionExceptionOccurred(Participant originator, IOException e);
    }
    
    private List<Participant> targets = new ArrayList<>();
    private List<ConnectionExceptionListener> connectionExceptionListeners = new ArrayList<>();
    
    void addTarget(Participant target) {
        targets.add(target);
    }
    
    void addConnectionExceptionListener(ConnectionExceptionListener listener) {
        connectionExceptionListeners.add(listener);
    }
    
    @Override
    public void sendChatMessage(Participant originator, String message) {
        sendToOthers(originator, participant -> participant.sendChatMessage(originator, message));
    }
    
    @Override
    public void sendConnectionExceptionOccurred(Participant originator) {
        sendToOthers(originator, Participant::sendErrorConnection);
    }
    
    @Override
    public void sendMove(Participant originator, MoveCoordinates move) {
        sendToOthers(originator, participant -> participant.sendMove(move));
    }
    
    @Override
    public void sendUndoAsk(Participant originator) {
        sendToOthers(originator, Participant::sendUndoAsk);
    }
    
    @Override
    public void sendUndoNegative(Participant originator) {
        sendToOthers(originator, Participant::sendUndoNegative);
    }
    
    @Override
    public void sendUndoPositive(Participant originator) {
        sendToOthers(originator, Participant::sendUndoPositive);
    }
    
    private void sendToOthers(Participant originator, Participant.ParticipantFunction sendFunction) {
        targets.stream()
                .filter(target -> target != originator)
                .forEach(target -> sendTo(target, sendFunction));
    }
    
    private void sendTo(Participant target, Participant.ParticipantFunction sendFunction) {
        try {
            sendFunction.send(target);
        } catch (IOException e) {
            notifyConnectionExceptionListeners(target, e);
        }
    }
    
    private void notifyConnectionExceptionListeners(Participant originator, IOException e) {
        connectionExceptionListeners.forEach(listener -> listener.connectionExceptionOccurred(originator, e));
    }
    
}
