package jchess.server;

import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;

public interface Participant {
    
    interface ParticipantFunction {
        void send(Participant function) throws IOException;
    }
    
    String getNick();
    
    void sendChatMessage(Participant originator, String message) throws IOException;
    
    void sendErrorConnection() throws IOException;
    
    void sendMove(MoveCoordinates move) throws IOException;
    
    void sendSettings(Settings settings) throws IOException;
    
    void sendUndoAsk() throws IOException;
    
    void sendUndoPositive() throws IOException;
    
    void sendUndoNegative() throws IOException;
    
    void setGameMessageHub(GameMessageHub hub);
    
}
