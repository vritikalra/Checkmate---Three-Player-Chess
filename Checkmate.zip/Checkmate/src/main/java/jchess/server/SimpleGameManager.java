package jchess.server;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class SimpleGameManager implements GameManager {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private Map<Integer, SGame> games = new HashMap<>();
    
    public SGame getGame(int gameId) throws BadGameIdException {
        LOGGER.fine("read gameId: " + gameId);
        
        SGame game = games.get(gameId);
        if (game == null) {
            throw new BadGameIdException();
        }
        
        return game;
    }
    
    public void createGame(int gameId, String encryptedPassword, boolean withObserver, boolean chatEnabled) throws BadGameIdException {
        LOGGER.fine("create new game with gameId: " + gameId);
        if (games.containsKey(gameId)) {
            LOGGER.fine("game with gameId " + gameId + " already exists");
            throw new BadGameIdException();
        }
        games.put(gameId, new SGame(encryptedPassword, withObserver, chatEnabled));
    }
    
    public Map<Integer, SGame> getGames() {
        return games;
    }
    
}
