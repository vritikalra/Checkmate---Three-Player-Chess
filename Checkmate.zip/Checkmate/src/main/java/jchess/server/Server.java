/*
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server implements Runnable {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    public static final int PORT = 4449;
    private static Server instance = null;
    
    private ServerSocket serverSocket;
    private GameManager gameManager;
    
    public static synchronized Server getInstance() {
        if (instance == null) {
            instance = new Server(new SimpleGameManager());
        }
        return instance;
    }
    
    private Server(GameManager gameManager) {
        this.gameManager = gameManager;
        
        runServer();
        
        Thread thread = new Thread(this);
        thread.start();
    }
    
    private void runServer() {//run server
        try {
            serverSocket = new ServerSocket(PORT);
            LOGGER.fine("running");
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void run() //listening
    {
        LOGGER.fine("listening port: " + PORT);
        while (true) {
            Socket socket;
            try {
                socket = serverSocket.accept();
                LOGGER.fine("new connection");
                new ClientJoinHandler(socket, gameManager);
                
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public GameManager getGameManager() {
        return gameManager;
    }
    
}
