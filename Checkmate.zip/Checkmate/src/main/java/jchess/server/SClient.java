/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.server;

import jchess.network.GameMessagePushReader;
import jchess.network.GameMessageWriter;
import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

class SClient implements GameMessagePushReader.GameMessageListener, Participant, AutoCloseable {
    
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private Socket socket;
    private GameMessagePushReader gameMessagePushReader;
    private GameMessageWriter gameMessageWriter;
    private GameMessageHub gameMessageHub = null;
    private String nick;
    private boolean isObserver;
    
    SClient(Socket socket, GameMessagePushReader gameMessagePushReader, GameMessageWriter gameMessageWriter, String nick, boolean isObserver) {
        this.socket = socket;
        this.gameMessagePushReader = gameMessagePushReader;
        this.gameMessageWriter = gameMessageWriter;
        this.nick = nick;
        this.isObserver = isObserver;
    }
    
    void startListening() {
        gameMessagePushReader.addGameMessageListener(this);
    }
    
    public String getNick() {
        return nick;
    }
    
    @Override
    public void close() {
        try {
            gameMessagePushReader.close();
            gameMessageWriter.close();
            socket.close();
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing connection to client: " + nick, e);
        }
    }
    
    // ======= GameMessageListener ======
    
    @Override
    public void receiveChatMessage(String message) {
        gameMessageHub.sendChatMessage(this, nick + ": " + message);
    }
    
    @Override
    public void receiveConnectionInfo(ConnectionInfo connectionInfo) {
        LOGGER.warning("Unexpected connection info message for " + nick + ": " + connectionInfo.name());
    }
    
    @Override
    public void receiveErrorConnection() {
        LOGGER.warning("Unexpected error connection message for " + nick);
    }
    
    @Override
    public void receiveLoginMessage(LoginMessage loginMessage) {
        LOGGER.warning("Unexpected login message for " + nick + ": " + loginMessage);
    }
    
    @Override
    public void receiveMove(MoveCoordinates move) {
        gameMessageHub.sendMove(this, move);
    }
    
    @Override
    public void receiveSettings(Settings settings) {
        LOGGER.warning("Unexpected settings message for " + nick + ": " + settings);
    }
    
    @Override
    public void receiveUndoAsk() {
        gameMessageHub.sendUndoAsk(this);
    }
    
    @Override
    public void receiveUndoPositive() {
        gameMessageHub.sendUndoPositive(this);
    }
    
    @Override
    public void receiveUndoNegative() {
        gameMessageHub.sendUndoNegative(this);
    }
    
    @Override
    public void connectionExceptionOccurred(Exception e) {
        if (!isObserver) {
            gameMessageHub.sendConnectionExceptionOccurred(this);
        }
        close();
    }
    
    // ======= GameMessageWriter ======
    
    @Override
    public void sendChatMessage(Participant originator, String message) throws IOException {
        gameMessageWriter.writeChatMessage(originator.getNick() + ": " + message);
    }
    
    @Override
    public void sendErrorConnection() throws IOException {
        gameMessageWriter.writeErrorConnection();
    }
    
    @Override
    public void sendMove(MoveCoordinates move) throws IOException {
        gameMessageWriter.writeMove(move);
    }
    
    @Override
    public void sendSettings(Settings settings) throws IOException {
        gameMessageWriter.writeSettings(settings);
    }
    
    @Override
    public void sendUndoAsk() throws IOException {
        gameMessageWriter.writeUndoAsk();
    }
    
    @Override
    public void sendUndoPositive() throws IOException {
        gameMessageWriter.writeUndoPositive();
    }
    
    @Override
    public void sendUndoNegative() throws IOException {
        gameMessageWriter.writeUndoNegative();
    }
    
    @Override
    public void setGameMessageHub(GameMessageHub gameMessageHub) {
        this.gameMessageHub = gameMessageHub;
    }
}