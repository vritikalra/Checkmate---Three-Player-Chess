/*
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Authors:
 * Mateusz Sławomir Lach ( matlak, msl )
 * Damian Marciniak
 */
package jchess.server;

import jchess.network.MD5;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Console {
    
    public static void main(String[] args) {
        System.out.println("JChess Server Start!");
        
        Server server = Server.getInstance(); //create server
        
        boolean isOK = true;
        while (isOK) {
            System.out.println("--------------------");
            System.out.println("[1] Nowy stół");
            System.out.println("[2] Lista aktywnych stołów");
            System.out.println("[3] Włącz/wyłącz komunikaty serwera");
            System.out.println("[4] Wyłącz serwer");
            System.out.print("-> ");
            String str = readString();
            
            switch (str) {
                case "1":
                    //new game
                    
                    System.out.print("ID gry: ");
                    int gameID = Integer.parseInt(readString());
                    
                    System.out.print("Hasło: ");
                    String pass = MD5.encrypt(readString().toCharArray());
                    
                    String observer;
                    do {
                        System.out.print("Gra z obserwatorami[t/n]: ");
                        observer = readString();
                    }
                    while (!observer.equalsIgnoreCase("t") && !observer.equalsIgnoreCase("n"));
                    
                    boolean canObserver = observer.equalsIgnoreCase("t");
    
                    try {
                        server.getGameManager().createGame(gameID, pass, canObserver, true); //create new game
                    } catch (GameManager.BadGameIdException e) {
                        System.out.println("A game with the given game ID already exists.");
                        continue;
                    }
    
                    break;
                case "2":
                    //list of games
    
                    for (Map.Entry<Integer, SGame> entry : server.getGameManager().getGames().entrySet()) {
                        Integer id = entry.getKey();
                        SGame game = entry.getValue();
                        
                        String p1, p2;
    
                        if (game.getClientPlayer1() == null || game.getClientPlayer1().getNick() == null) {
                            p1 = "empty";
                        } else {
                            p1 = game.getClientPlayer1().getNick();
                        }
    
                        if (game.getClientPlayer2() == null || game.getClientPlayer2().getNick() == null) {
                            p2 = "empty";
                        } else {
                            p2 = game.getClientPlayer2().getNick();
                        }
                        
                        System.out.println("\t" + id + ": " + p1 + " vs " + p2);
                    }
                    break;
                case "3":
                    //exit
                    
                    isOK = false;
                    break;
                default:
                    //bad commant
                    
                    System.out.println("Nierozpoznane polecenie");
                    break;
            }
        }
        System.exit(0);
    }
    
    private static String readString() //read string from console
    {
        int ch;
        StringBuilder sb = new StringBuilder();
        try {
            while ((ch = System.in.read()) != 10) {
                sb.append((char) ch);
            }
        } catch (IOException ex) {
            Logger.getLogger(Console.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return sb.toString();
    }
}
