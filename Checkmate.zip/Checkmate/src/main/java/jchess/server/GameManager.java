package jchess.server;

import java.util.Map;

/**
 * Holds a list of games and provides methods to add and search games.
 */
public interface GameManager {
    
    class BadGameIdException extends Exception {
    }
    
    SGame getGame(int gameId) throws BadGameIdException;
    
    void createGame(int gameId, String encryptedPassword, boolean withObserver, boolean chatEnabled) throws BadGameIdException;
    
    Map<Integer, SGame> getGames();
}
