package jchess.server;

import jchess.network.GameMessagePushReader;
import jchess.network.GameMessageWriter;
import jchess.network.NetworkGameMessagePushReader;
import jchess.network.NetworkGameMessageWriter;
import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Listens on new incoming connections for the login message and registers the new client to the game.
 * Ends the connection if any other message is coming before the login message.
 */
class ClientJoinHandler implements GameMessagePushReader.GameMessageListener, AutoCloseable {
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    
    private Socket socket;
    private GameManager gameManager;
    
    private GameMessagePushReader gameMessagePushReader;
    private GameMessageWriter gameMessageWriter;
    
    ClientJoinHandler(Socket socket, GameManager gameManager) {
        this.socket = socket;
        this.gameManager = gameManager;
        
        try {
            this.gameMessageWriter = new NetworkGameMessageWriter(new ObjectOutputStream(socket.getOutputStream()));
            this.gameMessagePushReader = new NetworkGameMessagePushReader(new ObjectInputStream(socket.getInputStream()));
        } catch (IOException e) {
            close();
            return;
        }
        
        gameMessagePushReader.addGameMessageListener(this);
    }
    
    @Override
    public void receiveLoginMessage(LoginMessage loginMessage) {
        gameMessagePushReader.removeGameMessageListener(this);
    
        LOGGER.fine("Login message received: " + loginMessage);
        
        try {
            SGame game = gameManager.getGame(loginMessage.getGameId());
    
            if (!game.getEncryptedPassword().equals(loginMessage.getEncryptedGamePassword())) {
                LOGGER.fine("New player " + loginMessage.getNick() + " cannot join game because the password is wrong.");
                sendConnectionInfo(gameMessageWriter, ConnectionInfo.ERR_BAD_PASSWORD);
                close();
                return;
            }
    
            if (loginMessage.isObserver() && !game.isObserversPermitted()) {
                LOGGER.fine("New player " + loginMessage.getNick() + " cannot join game because observers are not permitted.");
                sendConnectionInfo(gameMessageWriter, ConnectionInfo.ERR_GAME_WITHOUT_OBSERVER);
                close();
                return;
            }
    
            if (!loginMessage.isObserver() && game.isPlayerSlotsOccupied()) {
                LOGGER.fine("New player " + loginMessage.getNick() + " cannot join game because the game is full.");
                sendConnectionInfo(gameMessageWriter, ConnectionInfo.ERR_GAME_IS_FULL);
                close();
            }
    
            SClient client = new SClient(socket, gameMessagePushReader, gameMessageWriter, loginMessage.getNick(), loginMessage.isObserver());
            gameMessageWriter.writeConnectionInfo(ConnectionInfo.ALL_IS_OK);
            client.startListening();
    
            if (loginMessage.isObserver()) {
                game.addObserver(client);
            } else {
                game.addPlayer(client);
            }
            
        } catch (GameManager.BadGameIdException e) {
            LOGGER.fine("New player " + loginMessage.getNick() + " cannot join game because no game was found using ID: " + loginMessage.getGameId());
            sendConnectionInfo(gameMessageWriter, ConnectionInfo.ERR_BAD_GAME_ID);
            close();
        } catch (IOException e) {
            LOGGER.log(Level.INFO, "New player " + loginMessage.getNick() + " cannot join game because a connection error occurred", e);
            close();
        }
    }
    
    private void sendConnectionInfo(GameMessageWriter output, ConnectionInfo value) {
        try {
            output.writeConnectionInfo(value);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Error sending connection info '" + value.name() + "' to client", e);
            close();
        }
    }
    
    @Override
    public void close() {
        try {
            if (gameMessagePushReader != null)
                gameMessagePushReader.close();
            if (gameMessageWriter != null)
                gameMessageWriter.close();
            if (socket != null)
                socket.close();
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error closing connection to client", e);
        }
    }
    
    private void endConnectionDueToWrongMessage() {
        LOGGER.warning("login message expected but received message of another type");
        close();
    }
    
    @Override
    public void receiveChatMessage(String message) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveConnectionInfo(ConnectionInfo connectionInfo) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveErrorConnection() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveMove(MoveCoordinates move) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveSettings(Settings settings) {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoAsk() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoPositive() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void receiveUndoNegative() {
        endConnectionDueToWrongMessage();
    }
    
    @Override
    public void connectionExceptionOccurred(Exception e) {
        endConnectionDueToWrongMessage();
    }
}
