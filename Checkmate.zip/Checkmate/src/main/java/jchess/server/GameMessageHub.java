package jchess.server;

import jchess.network.gamemessages.MoveCoordinates;

public interface GameMessageHub {
    
    void sendChatMessage(Participant originator, String message);
    
    void sendConnectionExceptionOccurred(Participant originator);
    
    void sendMove(Participant originator, MoveCoordinates move);
    
    void sendUndoAsk(Participant originator);
    
    void sendUndoNegative(Participant originator);
    
    void sendUndoPositive(Participant originator);
    
}
