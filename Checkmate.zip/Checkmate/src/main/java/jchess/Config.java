package jchess;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URISyntaxException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Config {
    
    private static final Logger log = Logger.getLogger(Config.class.getName());
    
    public static Properties getConfigFile() {
        File configFile = new File(getJarPath(), "config.txt");
        
        if (!configFile.exists()) {
            try {
                Properties config = loadConfigFromJar();
                config.store(new FileOutputStream(configFile), null);
                return config;
            } catch (java.io.IOException e) {
                log.log(Level.INFO, "Error creating config file", e);
            }
        }
        
        Properties config = new Properties();
        try {
            config.load(new FileInputStream(configFile));
        } catch (java.io.IOException e) {
            log.log(Level.INFO, "Error loading config file", e);
        }
        return config;
    }
    
    private static Properties loadConfigFromJar() {
        Properties result = new Properties();
        try {
            result.load(Config.class.getResourceAsStream("/config.txt"));
        } catch (java.io.IOException e) {
            log.log(Level.INFO, "Error loading config file from jar", e);
        }
        return result;
    }
    
    private static String getJarPath() {
        String path;
        try {
            path = Config.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
        } catch (URISyntaxException e) {
            // the following methods produces some clutter, so we have to remove it
            path = Config.class.getProtectionDomain().getCodeSource().getLocation().getFile();
            // remove clutter
            path = path.replace("%20", " ");
        }
        
        // remove jar filename to get the base path
        path = path.replaceAll("[^/]*\\.jar$", "");
        
        return path;
    }
    
}
