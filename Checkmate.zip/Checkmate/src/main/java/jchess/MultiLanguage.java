package jchess;

import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.logging.Logger;

public class MultiLanguage {
    
    private static final Logger log = Logger.getLogger(MultiLanguage.class.getName());
    
    private static ResourceBundle localization = null;
    
    public static String get(String key) {
        if (localization == null) {
            localization = getResourceBundle();
        }
        
        try {
            return localization.getString(key);
        } catch (java.util.MissingResourceException e) {
            log.info("Cannot find language resource for key = '" + key + "' -> using '" + key + "' as text");
            return key;
        }
    }
    
    private static ResourceBundle getResourceBundle() {
        Locale.setDefault(Locale.ENGLISH);
        ResourceBundle loc = PropertyResourceBundle.getBundle("i18n.main");
        log.fine("Settings.loc.getLocale() = " + loc.getLocale().toString());
        return loc;
    }
    
}
