package jchess.gamelogic.core.chessboard;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.chesspiece.PiecePromoter;
import jchess.gamelogic.core.movement.movementpatterns.MovementPattern;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.GuiPieceFigure;
import jchess.gamelogic.shared.PlayerColor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.List;

class GenericChessboardTest {
    
    private static class ChessPieceMock implements ChessPiece {
        private Field field;
        @Override public Field getField() {
            return field;
        }
        @Override public void setField(Field field) {
            this.field = field;
        }
        
        // unused
        @Override public void setGuiPieceFigure(GuiPieceFigure guiPieceFigure) {  }
        @Override public void setSymbolForNotation(String symbolForNotation) {  }
        @Override public void setCastlingPartner(boolean castlingPartner) {  }
        @Override public PlayerColor getColor() { return null; }
        @Override public GuiPieceFigure getGuiPieceFigure() { return null; }
        @Override public void setEnPassantEnabled(boolean enPassantEnabled) {  }
        @Override public boolean isPromotable() { return false; }
        @Override public void setPromotable(boolean promotable) {  }
        @Override public void addMovementPattern(MovementPattern movementPattern) {  }
        @Override public List<MovementPattern> getMovementPatterns() { return null; }
        @Override public void setCheckable(boolean checkable) {  }
        @Override public boolean getHasBeenMoved() { return false; }
        @Override public void incrementMovesCount() { }
        @Override public void decrementMovesCount() { }
        @Override public boolean isCastlingPartner() { return false; }
        @Override public boolean isEnPassantEnabled() { return false; }
        @Override public boolean isCheckable() { return false; }
        @Override public NeighbourShip getFacing() { return null; }
        @Override public void setFacing(NeighbourShip facing) { }
        @Override public void setPiecePromoter(PiecePromoter promoter) { }
        @Override public PiecePromoter getPiecePromoter() { return null; }
        @Override public boolean isHittable() {
            return false;
        }
    }
    
    @Test
    void getChessPiece() {
        Chessboard board = createBoard();
    
        getChessPieceTest(board, new BoardCoordinate(3, 4));
        getChessPieceTest(board, new BoardCoordinate(0, 0));
        getChessPieceTest(board, new BoardCoordinate(0, 7));
        getChessPieceTest(board, new BoardCoordinate(7, 0));
        getChessPieceTest(board, new BoardCoordinate(7, 7));
    }
    
    @Test
    void getOccupiedFields_noOccupation() {
        Chessboard board = createBoard();
        Assertions.assertTrue(board.getOccupiedFields().isEmpty());
    }
    
    @Test
    void getOccupiedFields_oneOccupation() {
        Chessboard board = createBoard();
        board.putChessPiece(board.getField(new BoardCoordinate(3, 4)), new ChessPieceMock());
        Assertions.assertEquals(1, board.getOccupiedFields().size());
    }
    
    @Test
    void getOccupiedFields_manyOccupations() {
        Chessboard board = createBoard();
        board.putChessPiece(board.getField(new BoardCoordinate(3, 4)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(0, 0)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(0, 7)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(7, 0)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(7, 7)), new ChessPieceMock());
        Assertions.assertEquals(5, board.getOccupiedFields().size());
    }
    
    @Test
    void putChessPiece() {
        Chessboard board = createBoard();
        board.putChessPiece(board.getField(new BoardCoordinate(3, 4)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(0, 0)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(0, 7)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(7, 0)), new ChessPieceMock());
        board.putChessPiece(board.getField(new BoardCoordinate(7, 7)), new ChessPieceMock());
    }
    
    @Test
    void removeChessPiece() {
        Chessboard board = createBoard();
    
        removeChessPieceTest(board, new BoardCoordinate(3, 4));
        removeChessPieceTest(board, new BoardCoordinate(0, 0));
        removeChessPieceTest(board, new BoardCoordinate(0, 7));
        removeChessPieceTest(board, new BoardCoordinate(7, 0));
        removeChessPieceTest(board, new BoardCoordinate(7, 7));
    }
    
    private void getChessPieceTest(Chessboard board, BoardCoordinate coordinate) {
        Assertions.assertNull(board.getChessPiece(coordinate));
        board.putChessPiece(board.getField(coordinate), new ChessPieceMock());
        Assertions.assertNotNull(board.getChessPiece(coordinate));
    }
    
    private void removeChessPieceTest(Chessboard board, BoardCoordinate coordinate) {
        Assertions.assertNull(board.getChessPiece(coordinate));
        board.putChessPiece(board.getField(coordinate), new ChessPieceMock());
        Assertions.assertNotNull(board.getChessPiece(coordinate));
        board.removeChessPiece(board.getField(coordinate));
        Assertions.assertNull(board.getChessPiece(coordinate));
    }
    
    private GenericChessboard createBoard() {
        GenericChessboard board = new GenericChessboard();
        board.setFields(createFields(board));
        return board;
    }
    
    private Field[] createFields(Field.ChessboardInformationProvider cip) {
        Field[][] boardTop = BoardCreationHelper.createRectangularBoard(8, 4, cip, new int[]{7,6,5,4,3,2,1,0}, new int[]{3,2,1,0});
        Field[][] boardBottom = BoardCreationHelper.createRectangularBoard(8, 4, cip, new int[]{0,1,2,3,4,5,6,7}, new int[]{4,5,6,7});
        
        BoardCreationHelper.linkBoardsTogether(boardTop, boardBottom, 0, 8);
        BoardCreationHelper.linkBoardsTogether(boardBottom, boardTop, 0, 8);
        
        return BoardCreationHelper.flatten(boardTop, boardBottom);
    }
    
}