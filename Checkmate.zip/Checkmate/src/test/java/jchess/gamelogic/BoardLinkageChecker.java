package jchess.gamelogic;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BoardLinkageChecker {
    
    public static void assertCorrectLinkageOfFieldsInBoard(Field[] fields) {
        Arrays.stream(fields).forEach(BoardLinkageChecker::assertCorrectLinkage);
    }
    
    private static void assertCorrectLinkage(Field field) {
        assertCorrectAmountOfNeighbours(field);
        
        assertFieldHasItselfNotAsNeighbour(field);
    }
    
    private static void assertFieldHasItselfNotAsNeighbour(Field field) {
        Arrays.stream(NeighbourShip.values()).forEach(neighbourShip ->  {
            Field target = field.getNeighbour(neighbourShip).getTarget();
            if(target.equals(field) || field.getBoardCoordinate().equals(target.getBoardCoordinate()))
                Assertions.fail("Field " + field.getBoardCoordinate() + " has itself as neighbour in direction " + neighbourShip);
        });
    }
    
    private static void assertCorrectAmountOfNeighbours(Field field) {
        List<NeighbourShip> neighbourShips = getOccupiedNeighbourShips(field);
        switch (neighbourShips.size()) {
            case 3:
                // corner of the board -> correct
                break;
            case 5:
                // edge of the board -> correct
                break;
            case 8:
                // within the board -> correct
                break;
        
            default:
                Assertions.fail("Field " + field.getBoardCoordinate() + " not correctly linked. Linked neighbours: " + neighbourShips);
        }
    }
    
    private static List<NeighbourShip> getOccupiedNeighbourShips(Field field) {
        return Arrays.stream(NeighbourShip.values())
                .filter(direction -> field.getNeighbour(direction).getTarget().isOnBoard())
                .collect(Collectors.toList());
    }
    
}
