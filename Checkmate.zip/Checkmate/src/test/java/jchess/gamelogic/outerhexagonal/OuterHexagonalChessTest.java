package jchess.gamelogic.outerhexagonal;

import jchess.gamelogic.BoardCoordinateChecker;
import jchess.gamelogic.BoardLinkageChecker;
import jchess.gamelogic.core.chessboard.field.Field;
import org.junit.jupiter.api.Test;

class OuterHexagonalChessTest {
    
    @Test
    void checkLinkageOfFieldsInBoard() {
        Field[] fields = OuterHexagonalChess.createFields(null);
        BoardLinkageChecker.assertCorrectLinkageOfFieldsInBoard(fields);
    }
    
    @Test
    void checkBoardCoordinateUniqueness() {
        Field[] fields = OuterHexagonalChess.createFields(null);
        BoardCoordinateChecker.assertUniqueBoardCoordinates(fields);
    }
    
}