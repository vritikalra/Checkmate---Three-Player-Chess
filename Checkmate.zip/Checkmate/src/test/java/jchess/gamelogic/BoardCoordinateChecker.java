package jchess.gamelogic;

import jchess.gamelogic.core.chessboard.field.Field;
import org.junit.jupiter.api.Assertions;

import java.util.Arrays;
import java.util.stream.Collectors;

public class BoardCoordinateChecker {
    
    public static void assertUniqueBoardCoordinates(Field[] fields) {
        Arrays.stream(fields)
                .map(Field::getBoardCoordinate)
                .collect(Collectors.toMap(boardCoordinate -> boardCoordinate, boardCoordinate -> 1, Integer::sum))
                .forEach((boardCoordinate, count) -> Assertions.assertEquals(1, count, "BoardCoordinate " + boardCoordinate + " is used for " + count + " fields"));
    }
    
}
