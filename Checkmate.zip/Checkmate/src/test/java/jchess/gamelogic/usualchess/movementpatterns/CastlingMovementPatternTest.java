package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldLink;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

class CastlingMovementPatternTest {
    
    /**
     * The chessboard for this test only consisting of 5 fields in a row.
     */
    private static class TestBoard {
        Field castlingOrigin;
        Field castlingPartnerDestination;
        Field castlingDestination;
        Field intermediate2;
        Field castlingPartnerOrigin;
    }
    
    @Test
    void shortCastling_successful() {
        TestBoard board = initShortCastlingField();
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.emptySet());
        
        Assertions.assertEquals(1, moves.size());
    
        MoveBlueprint move = moves.iterator().next();
        Assertions.assertEquals(move.getFrom(), board.castlingOrigin);
        Assertions.assertEquals(move.getTo(), board.castlingDestination);
        Assertions.assertEquals(move.getCastlingEmbeddedMove().getFrom(), board.castlingPartnerOrigin);
        Assertions.assertEquals(move.getCastlingEmbeddedMove().getTo(), board.castlingPartnerDestination);
    }
    
    @Test
    void longCastling_successful() {
        TestBoard board = initLongCastlingField(true, false, false);
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.emptySet());
        
        Assertions.assertEquals(1, moves.size());
    
        MoveBlueprint move = moves.iterator().next();
        Assertions.assertEquals(move.getFrom(), board.castlingOrigin);
        Assertions.assertEquals(move.getTo(), board.castlingDestination);
        Assertions.assertEquals(move.getCastlingEmbeddedMove().getFrom(), board.castlingPartnerOrigin);
        Assertions.assertEquals(move.getCastlingEmbeddedMove().getTo(), board.castlingPartnerDestination);
    }
    
    @Test
    void longCastling_noCastlingPartner() {
        TestBoard board = initLongCastlingField(false, false, false);
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.emptySet());
    
        Assertions.assertEquals(0, moves.size());
    }
    
    @Test
    void longCastling_wayIsThreatened() {
        TestBoard board = initLongCastlingField(true, false, false);
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.singleton(board.castlingPartnerDestination));
        
        Assertions.assertEquals(0, moves.size());
    }
    
    @Test
    void longCastling_wayIsOccupied() {
        TestBoard board = initLongCastlingField(true, false, true);
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.singleton(board.castlingPartnerDestination));
        
        Assertions.assertEquals(0, moves.size());
    }
    
    @Test
    void longCastling_castlingPartnerHasMoved() {
        TestBoard board = initLongCastlingField(true, true, false);
        Collection<MoveBlueprint> moves = testLongCasting(board, Collections.singleton(board.castlingPartnerDestination));
        
        Assertions.assertEquals(0, moves.size());
    }
    
    
    private Collection<MoveBlueprint> testLongCasting(TestBoard board, Set<Field> threatenedFields) {
        return new CastlingMovementPattern().calculatePossibleMoves(PlayerColor.BLACK, board.castlingOrigin, null, threatenedFields);
    }
    
    /**
     * Legend:
     *      K: piece that initiates castling (castling origin)
     *      d: castling partner destination
     *      C: castling destination, K will move here on successful castling
     *      i: intermediate field connecting C and P
     *      P: castling partner
     *
     * |_|_|_|_|_|_|_|_|7
     * |_|_|_|_|_|_|_|_|6
     * |_|_|_|_|_|_|_|_|5
     * |_|_|_|_|_|_|_|_|4
     * |_|_|_|_|_|_|_|_|3
     * |_|_|_|_|_|_|_|_|2
     * |_|_|_|_|_|_|_|_|1
     * |P|i|C|d|K|_|_|_|0
     * 0 1 2 3 4 5 6 7
     */
    private TestBoard initLongCastlingField(boolean castlingPartnerPresent, boolean castlingPartnerHasMoved, boolean intermediateFieldIsOccupied) {
        TestBoard board = new TestBoard();
        
        board.castlingOrigin = new Field(new ChessboardInformationProviderMock(false, false, false, false, false), new BoardCoordinate(4, 0));
        board.castlingPartnerDestination = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(3, 0));
        board.castlingDestination = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(2, 0));
        board.intermediate2 = new Field(new ChessboardInformationProviderMock(false, false, false, !intermediateFieldIsOccupied, false), new BoardCoordinate(1, 0));
        board.castlingPartnerOrigin = new Field(new ChessboardInformationProviderMock(false, false, castlingPartnerPresent, false, castlingPartnerHasMoved), new BoardCoordinate(0, 0));
    
        board.castlingOrigin.addNeighbour(NeighbourShip.EAST,  new FieldLink(board.castlingPartnerDestination, false));
        board.castlingPartnerDestination.addNeighbour(NeighbourShip.EAST,  new FieldLink(board.castlingDestination, false));
        board.castlingDestination.addNeighbour(NeighbourShip.EAST,  new FieldLink(board.intermediate2, false));
        board.intermediate2.addNeighbour(NeighbourShip.EAST,  new FieldLink(board.castlingPartnerOrigin, false));
        
        return board;
    }
    
    /**
     * Legend:
     *      K: piece that initiates castling (castling origin)
     *      d: castling partner destination
     *      C: castling destination, K will move here on successful castling
     *      P: castling partner
     *
     * |_|_|_|_|_|_|_|_|7
     * |_|_|_|_|_|_|_|_|6
     * |_|_|_|_|_|_|_|_|5
     * |_|_|_|_|_|_|_|_|4
     * |_|_|_|_|_|_|_|_|3
     * |_|_|_|_|_|_|_|_|2
     * |_|_|_|_|_|_|_|_|1
     * |P|C|d|K|_|_|_|_|0
     * 0 1 2 3 4 5 6 7
     */
    private TestBoard initShortCastlingField() {
        TestBoard board = new TestBoard();
        
        board.castlingOrigin = new Field(new ChessboardInformationProviderMock(false, false, false, false, false), new BoardCoordinate(3, 0));
        board.castlingPartnerDestination = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(2, 0));
        board.castlingDestination = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(1, 0));
        board.castlingPartnerOrigin = new Field(new ChessboardInformationProviderMock(false, false, true, false, false), new BoardCoordinate(0, 0));
        
        board.castlingOrigin.addNeighbour(NeighbourShip.EAST, new FieldLink(board.castlingPartnerDestination, false));
        board.castlingPartnerDestination.addNeighbour(NeighbourShip.EAST, new FieldLink(board.castlingDestination, false));
        board.castlingDestination.addNeighbour(NeighbourShip.EAST, new FieldLink(board.castlingPartnerOrigin, false));
        
        return board;
    }
    
}