package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.shared.PlayerColor;

class ChessboardInformationProviderMock implements Field.ChessboardInformationProvider {
    
    private final boolean hasEnemy;
    private final boolean isEnPassantEnabled;
    private final boolean isCastlingPartner;
    private final boolean isFieldEmpty;
    private final boolean getHasBeenMoved;
    
    public ChessboardInformationProviderMock(boolean hasEnemy, boolean isEnPassantEnabled, boolean isCastlingPartner, boolean isFieldEmpty, boolean getHasBeenMoved) {
        this.hasEnemy = hasEnemy;
        this.isEnPassantEnabled = isEnPassantEnabled;
        this.isCastlingPartner = isCastlingPartner;
        this.isFieldEmpty = isFieldEmpty;
        this.getHasBeenMoved = getHasBeenMoved;
    }
    
    @Override
    public NeighbourShip getPieceFacing(Field field) throws FieldNotOccupiedException {
        if(field.isEmpty())
            throw new FieldNotOccupiedException("");
        return NeighbourShip.NORTH;
    }
    
    @Override
    public boolean hasEnemy(Field field, PlayerColor player) {
        return hasEnemy;
    }
    
    @Override
    public boolean isEnPassantEnabled(Field field) {
        return isEnPassantEnabled;
    }
    
    @Override
    public boolean isCastlingPartner(Field field) {
        return isCastlingPartner;
    }
    
    @Override
    public boolean getHasBeenMoved(Field field) {
        return getHasBeenMoved;
    }
    
    @Override
    public boolean isFieldEmpty(Field field) {
        return isFieldEmpty;
    }

    @Override
    public boolean isNeutral(Field field) {
        return false;
    }

    @Override
    public boolean isPromotable(Field field) {
        return false;
    }

    @Override
    public boolean isHittable(Field field) {
        return false;
    }

    @Override
    public boolean isCheckable(Field field) {
        return false;
    }
    
}
