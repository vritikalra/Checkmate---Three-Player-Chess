package jchess.gamelogic.usualchess;

import jchess.gamelogic.BoardCoordinateChecker;
import jchess.gamelogic.BoardLinkageChecker;
import jchess.gamelogic.core.chessboard.field.Field;
import org.junit.jupiter.api.Test;

class UsualChessTest {
    
    @Test
    void checkLinkageOfFieldsInBoard() {
        Field[] fields = UsualChess.createFields(null);
        BoardLinkageChecker.assertCorrectLinkageOfFieldsInBoard(fields);
    }
    
    @Test
    void checkBoardCoordinateUniqueness() {
        Field[] fields = UsualChess.createFields(null);
        BoardCoordinateChecker.assertUniqueBoardCoordinates(fields);
    }
    
    
}