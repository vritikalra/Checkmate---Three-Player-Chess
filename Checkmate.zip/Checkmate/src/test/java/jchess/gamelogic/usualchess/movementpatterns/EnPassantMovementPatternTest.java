package jchess.gamelogic.usualchess.movementpatterns;

import jchess.gamelogic.core.chessboard.field.Field;
import jchess.gamelogic.core.chessboard.field.FieldLink;
import jchess.gamelogic.core.chessboard.field.FieldNotOccupiedException;
import jchess.gamelogic.core.chessboard.field.NeighbourShip;
import jchess.gamelogic.core.chessboard.navigation.Navigator;
import jchess.gamelogic.core.chesspiece.ChessPiece;
import jchess.gamelogic.core.movement.movementpatterns.MoveBlueprint;
import jchess.gamelogic.core.round.Turn;
import jchess.gamelogic.core.round.history.TurnHistory;
import jchess.gamelogic.shared.BoardCoordinate;
import jchess.gamelogic.shared.PlayerColor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

class EnPassantMovementPatternTest {
    
    /**
     * The chessboard for this test only consisting of few fields.
     */
    private static class TestBoard {
        Field previousMoveDestination;
        Field previousMoveIntermediate;
        Field previousMoveOrigin;
        
        Field attackingPawn;
        Field behindAttackingPawn;
    }
    
    private static class TurnHistoryMock implements TurnHistory {
        
        private TestBoard board;
        
        public TurnHistoryMock(TestBoard board) {
            this.board = board;
        }
        
        public List<MoveBlueprint> getEnemiesPreviousMoves(PlayerColor player) {
            try {
                return Collections.singletonList(new MoveBlueprint(
                        board.previousMoveOrigin,
                        new Navigator(board.previousMoveDestination),
                        null,
                        null,
                        false));
            } catch (FieldNotOccupiedException e) {
                Assertions.fail(e);
                return Collections.emptyList();
            }
        }
        
        // not used
        @Override public void addTurn(Turn round) { throw new UnsupportedOperationException(); }
        @Override public Turn redo() { throw new UnsupportedOperationException(); }
        @Override public Turn undo() { throw new UnsupportedOperationException(); }
        @Override public ChessPiece getHitChessPieceOfThisRound() { throw new UnsupportedOperationException(); }
    }
    
    @Test
    void enPassant_successful() {
        TestBoard board = initBoard(true);
        Collection<MoveBlueprint> possibleMoves = new EnPassantMovementPattern().calculatePossibleMoves(PlayerColor.WHITE, board.attackingPawn, new TurnHistoryMock(board), Collections.emptySet());
        Assertions.assertEquals(1, possibleMoves.size());
        
        MoveBlueprint move = possibleMoves.iterator().next();
        Assertions.assertEquals(board.previousMoveIntermediate, move.getTo());
    }
    
    @Test
    void enPassant_pawnTooFarAwayToAttack() {
        TestBoard board = initBoard(false);
        Collection<MoveBlueprint> possibleMoves = new EnPassantMovementPattern().calculatePossibleMoves(PlayerColor.WHITE, board.behindAttackingPawn, new TurnHistoryMock(board), Collections.emptySet());
        Assertions.assertEquals(0, possibleMoves.size());
    }
    
    /**
     * Legend:
     *      E: pawn that will be killed en passant
     *      e: previous location of pawn that will be killed by en passant before it has been moved
     *      A: attacking pawn that will kill en passant
     *      X: destination for the en passant kill. A will sit on it after the en passant kill. (pawnInAttackingPosition = true)
     *      a: a pawn that is not permitted to kill en passant (pawnInAttackingPosition = false)
     *
     * |_|_|_|_|_|_|_|_|7
     * |_|_|_|_|_|_|_|_|6
     * |_|_|_|_|_|_|_|_|5
     * |_|_|_|_|a|_|_|_|4
     * |_|_|_|E|A|_|_|_|3
     * |_|_|_|X|_|_|_|_|2
     * |_|_|_|e|_|_|_|_|1
     * |_|_|_|_|_|_|_|_|0
     * 0 1 2 3 4 5 6 7
     */
    private TestBoard initBoard(boolean pawnInAttackingPosition) {
        TestBoard board = new TestBoard();
        
        board.previousMoveDestination = new Field(new ChessboardInformationProviderMock(true, true, false, false, true), new BoardCoordinate(3, 4));
        board.previousMoveIntermediate = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(3, 5));
        board.previousMoveOrigin = new Field(new ChessboardInformationProviderMock(false, false, false, true, false), new BoardCoordinate(3, 6));
        board.previousMoveDestination.addNeighbour(NeighbourShip.SOUTH, new FieldLink(board.previousMoveIntermediate, false));
        board.previousMoveIntermediate.addNeighbour(NeighbourShip.SOUTH, new FieldLink(board.previousMoveOrigin, false));
        
        
        board.attackingPawn = new Field(new ChessboardInformationProviderMock(false, pawnInAttackingPosition, false, !pawnInAttackingPosition, pawnInAttackingPosition), new BoardCoordinate(4, 4));
        board.attackingPawn.addNeighbour(NeighbourShip.EAST, new FieldLink(board.previousMoveDestination, false));
        board.previousMoveDestination.addNeighbour(NeighbourShip.WEST, new FieldLink(board.attackingPawn, false));
        
        board.behindAttackingPawn = new Field(new ChessboardInformationProviderMock(false, !pawnInAttackingPosition, false, pawnInAttackingPosition, !pawnInAttackingPosition), new BoardCoordinate(4, 3));
        board.behindAttackingPawn.addNeighbour(NeighbourShip.NORTH, new FieldLink(board.attackingPawn, false));
        board.attackingPawn.addNeighbour(NeighbourShip.SOUTH, new FieldLink(board.behindAttackingPawn, false));
        
        board.behindAttackingPawn.addNeighbour(NeighbourShip.SOUTH_WEST, new FieldLink(board.previousMoveDestination, false));
        board.previousMoveDestination.addNeighbour(NeighbourShip.NORTH_EAST, new FieldLink(board.behindAttackingPawn, false));
        
        return board;
    }
    
}