package jchess.gui.image;

import org.junit.jupiter.api.Test;

class ThemesTest {
    
    /**
     * Tests that a missing folder does not lead to an Exception.
     */
    @Test
    void getChildrenOfResourceFolder() {
        Themes.listChildrenOfResourceFolder("non-existent");
    }
}
