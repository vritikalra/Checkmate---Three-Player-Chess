package jchess.gui.gameview;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CountDownTest {
    
    @Test
    void decrement() {
        CountDown countDown = new CountDown();
        countDown.setTimeLeft(3);
        Assertions.assertEquals(countDown.getTimeLeft(), 3);

        /*
        Assertions.assertEquals(countDown.decrement(), true);
        Assertions.assertEquals(countDown.getTimeLeft(), 2);
        
        Assertions.assertEquals(countDown.decrement(), true);
        Assertions.assertEquals(countDown.getTimeLeft(), 1);
        
        Assertions.assertEquals(countDown.decrement(), true);
        Assertions.assertEquals(countDown.getTimeLeft(), 0);
        
        Assertions.assertEquals(countDown.decrement(), false);
        Assertions.assertEquals(countDown.getTimeLeft(), 0);
         */
    }
    
    @Test
    void testToString() {
        CountDown countDown = new CountDown();
        
        countDown.setTimeLeft(62);
        Assertions.assertEquals(countDown.getTimeLeftString(), "01:02");
        
        countDown.setTimeLeft(3612);
        Assertions.assertEquals(countDown.getTimeLeftString(), "60:12");
    }
}