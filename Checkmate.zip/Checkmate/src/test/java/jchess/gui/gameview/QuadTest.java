package jchess.gui.gameview;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class QuadTest {

    @Test
    void contains() {

       Quad q=new Quad("",1,1,3,1,1,3,3,3);

        assertTrue(q.contains(2, 2));
        assertFalse(q.contains(4, 4));
    }

}