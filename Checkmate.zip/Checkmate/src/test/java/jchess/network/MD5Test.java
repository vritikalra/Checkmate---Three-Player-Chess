package jchess.network;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class MD5Test {
    
    @Test
    void encrypt() {
        Assertions.assertEquals(MD5.encrypt("".toCharArray()), "d41d8cd98f00b204e9800998ecf8427e");
        Assertions.assertEquals(MD5.encrypt("The quick brown fox jumps over the lazy dog.".toCharArray()), "e4d909c290d0fb1ca068ffaddf22cbd0");
    }
}
