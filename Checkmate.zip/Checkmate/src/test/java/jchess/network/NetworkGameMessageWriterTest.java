package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;

class NetworkGameMessageWriterTest {
    
    @Test
    void writeChatMessage() throws IOException, ClassNotFoundException {
        String message = "Hello, привет!¿";
    
        testWriteAndCompareOutput(writer -> writer.writeChatMessage(message), "#message", message);
    }
    
    @Test
    void writeConnectionInfo() throws IOException, ClassNotFoundException {
        ConnectionInfo message = ConnectionInfo.ERR_BAD_PASSWORD;
    
        testWriteAndCompareOutput(writer -> writer.writeConnectionInfo(message), "#connectionInfo", message);
    }
    
    @Test
    void writeErrorConnection() throws IOException, ClassNotFoundException {
        testWriteAndCompareOutput(NetworkGameMessageWriter::writeErrorConnection, "#errorConnection");
    }
    
    @Test
    void writeLoginMessage() throws IOException, ClassNotFoundException {
        LoginMessage message = new LoginMessage(4, true, "Peter Pan", "!@#ß¿");
    
        testWriteAndCompareOutput(writer -> writer.writeLoginMessage(message), "#login", message);
    }
    
    @Test
    void writeMove() throws IOException, ClassNotFoundException {
        MoveCoordinates message = new MoveCoordinates(1, 5, -1, 0);
    
        testWriteAndCompareOutput(writer -> writer.writeMove(message), "#move", message);
    }
    
    @Test
    void writeSettings() throws IOException, ClassNotFoundException {
        Settings message = new Settings();
        message.timeForGame = 500;
    
        testWriteAndCompareOutput(writer -> writer.writeSettings(message), "#settings", message);
    }
    
    @Test
    void writeUndoAsk() throws IOException, ClassNotFoundException {
        testWriteAndCompareOutput(NetworkGameMessageWriter::writeUndoAsk, "#undoAsk");
    }
    
    @Test
    void writeUndoPositive() throws IOException, ClassNotFoundException {
        testWriteAndCompareOutput(NetworkGameMessageWriter::writeUndoPositive, "#undoAnswerPositive");
    }
    
    @Test
    void writeUndoNegative() throws IOException, ClassNotFoundException {
        testWriteAndCompareOutput(NetworkGameMessageWriter::writeUndoNegative, "#undoAnswerNegative");
    }
    
    private interface TestExecution {
        void execute(NetworkGameMessageWriter writer) throws IOException;
    }
    
    private void testWriteAndCompareOutput(TestExecution testExecution, String expectedMessageIdentifier, Object... expectedMessageObjects) throws IOException, ClassNotFoundException {
        ByteArrayOutputStream outputBuffer = new ByteArrayOutputStream();
        NetworkGameMessageWriter writer = new NetworkGameMessageWriter(new ObjectOutputStream(outputBuffer));
        
        testExecution.execute(writer);
        
        ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(outputBuffer.toByteArray()));
        Assertions.assertEquals(expectedMessageIdentifier, in.readUTF());
        for (Object expected : expectedMessageObjects) {
            try {
                Assertions.assertEquals(expected, in.readObject());
            } catch (OptionalDataException e) {
                Assertions.assertEquals(expected, in.readUTF());
            }
        }
        Assertions.assertEquals(0, in.available());
    }
    
}
