package jchess.network;

import jchess.network.gamemessages.ConnectionInfo;
import jchess.network.gamemessages.LoginMessage;
import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;
import net.jodah.concurrentunit.Waiter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertNull;

class NetworkGameMessagePushReaderTest {
    
    private final Logger log = Logger.getLogger(getClass().getName());
    
    private Waiter waiter = null;
    
    private static class ErrorRaisingObjectInputStreamMock extends ObjectInputStream {
        ErrorRaisingObjectInputStreamMock() throws IOException, SecurityException {
        }
        
        @Override
        public String readUTF() throws IOException {
            throw new IOException("TEST EXCEPTION");
        }
    }
    
    private class ObjectInputStreamMock extends ObjectInputStream {
        
        private Queue<String> mockedReadUTFs;
        private Queue<Object> mockedReadObjects;
        
        private ObjectInputStreamMock(Queue<String> mockedReadUTFs, Queue<Object> mockedReadObjects) throws IOException, SecurityException {
            super();
            this.mockedReadUTFs = mockedReadUTFs;
            this.mockedReadObjects = mockedReadObjects;
        }
        
        @Override
        public String readUTF() {
            if (mockedReadUTFs.isEmpty()) {
                waiter.resume();
                Thread.currentThread().interrupt();
                return "";
            } else {
                log.fine(mockedReadUTFs.element());
                return mockedReadUTFs.remove();
            }
        }
        
        @Override
        protected Object readObjectOverride() {
            if (mockedReadObjects.isEmpty())
                waiter.fail();
            return mockedReadObjects.remove();
        }
    }
    
    private class RecordingGameMessageListener implements GameMessagePushReader.GameMessageListener {
        private String receivedMessageIdentifier;
        private Object receivedObject;
        
        @Override
        public void receiveChatMessage(String message) {
            receivedMessageIdentifier = "#message";
            receivedObject = message;
            waiter.resume();
        }
        
        @Override
        public void receiveConnectionInfo(ConnectionInfo connectionInfo) {
            receivedMessageIdentifier = "#connectionInfo";
            receivedObject = connectionInfo;
            waiter.resume();
        }
        
        @Override
        public void receiveErrorConnection() {
            receivedMessageIdentifier = "#errorConnection";
            receivedObject = null;
            waiter.resume();
        }
        
        @Override
        public void receiveLoginMessage(LoginMessage loginMessage) {
            receivedMessageIdentifier = "#login";
            receivedObject = loginMessage;
            waiter.resume();
        }
        
        @Override
        public void receiveMove(MoveCoordinates move) {
            receivedMessageIdentifier = "#move";
            receivedObject = move;
            waiter.resume();
        }
        
        @Override
        public void receiveSettings(Settings settings) {
            receivedMessageIdentifier = "#settings";
            receivedObject = settings;
            waiter.resume();
        }
        
        @Override
        public void receiveUndoAsk() {
            receivedMessageIdentifier = "#undoAsk";
            receivedObject = null;
            waiter.resume();
        }
        
        @Override
        public void receiveUndoPositive() {
            receivedMessageIdentifier = "#undoAnswerPositive";
            receivedObject = null;
            waiter.resume();
        }
        
        @Override
        public void receiveUndoNegative() {
            receivedMessageIdentifier = "#undoAnswerNegative";
            receivedObject = null;
            waiter.resume();
            System.out.println("resume receive");
        }
        
        @Override
        public void connectionExceptionOccurred(Exception e) {
            receivedMessageIdentifier = null;
            receivedObject = null;
            waiter.resume();
        }
    }
    
    @Test
    void testReceiveChatMessage() throws Throwable {
        String message = "Hello, привет!¿";
        testReceiveAndCompareOutput(Arrays.asList("#message", message), Collections.emptyList());
    }
    
    @Test
    void testReceiveConnectionInfo() throws Throwable {
        ConnectionInfo message = ConnectionInfo.ERR_BAD_PASSWORD;
        testReceiveAndCompareOutput(Collections.singletonList("#connectionInfo"), Collections.singletonList(message));
    }
    
    @Test
    void testReceiveErrorConnection() throws Throwable {
        testReceiveAndCompareOutput(Collections.singletonList("#errorConnection"), Collections.emptyList());
    }
    
    @Test
    void testReceiveLoginMessage() throws Throwable {
        LoginMessage message = new LoginMessage(4, true, "Peter Pan", "!@#ß¿");
        testReceiveAndCompareOutput(Collections.singletonList("#login"), Collections.singletonList(message));
    }
    
    @Test
    void testReceiveMove() throws Throwable {
        MoveCoordinates message = new MoveCoordinates(2, -10, 9999, 1);
        testReceiveAndCompareOutput(Collections.singletonList("#move"), Collections.singletonList(message));
    }
    
    @Test
    void testReceiveSettings() throws Throwable {
        Settings message = new Settings();
        message.timeForGame = 100;
        testReceiveAndCompareOutput(Collections.singletonList("#settings"), Collections.singletonList(message));
    }
    
    @Test
    void testReceiveUndoAsk() throws Throwable {
        testReceiveAndCompareOutput(Collections.singletonList("#undoAsk"), Collections.emptyList());
    }
    
    @Test
    void testReceiveUndoPositive() throws Throwable {
        testReceiveAndCompareOutput(Collections.singletonList("#undoAnswerPositive"), Collections.emptyList());
    }
    
    @Test
    void testReceiveUndoNegative() throws Throwable {
        testReceiveAndCompareOutput(Collections.singletonList("#undoAnswerNegative"), Collections.emptyList());
    }
    
    @Test
    void testConnectionExceptionOccurred() throws Throwable {
        waiter = new Waiter();
        RecordingGameMessageListener messageRecorder = new RecordingGameMessageListener();
        GameMessagePushReader pushReader = new NetworkGameMessagePushReader(new ErrorRaisingObjectInputStreamMock());
        pushReader.addGameMessageListener(messageRecorder);
        waiter.await(2000, 1);
        assertNull(messageRecorder.receivedMessageIdentifier);
        assertNull(messageRecorder.receivedObject);
        Assertions.assertThrows(NullPointerException.class, pushReader::close);
    }
    
    private void testReceiveAndCompareOutput(List<String> mockedReadUTFs, List<Object> mockedReadObjects) throws Throwable {
        waiter = new Waiter();
        
        RecordingGameMessageListener messageRecorder = new RecordingGameMessageListener();
        
        ObjectInputStreamMock input = new ObjectInputStreamMock(new LinkedList<>(mockedReadUTFs), new LinkedList<>(mockedReadObjects));
        GameMessagePushReader pushReader = new NetworkGameMessagePushReader(input);
        pushReader.addGameMessageListener(messageRecorder);
        
        waiter.await(2000, 2);
        
        Assertions.assertEquals(mockedReadUTFs.get(0), messageRecorder.receivedMessageIdentifier);
        if (mockedReadUTFs.size() == 2) {
            Assertions.assertEquals(mockedReadUTFs.get(1), messageRecorder.receivedObject);
        } else if (mockedReadObjects.size() == 1) {
            Assertions.assertEquals(mockedReadObjects.get(0), messageRecorder.receivedObject);
        } else {
            assertNull(messageRecorder.receivedObject);
        }
        
        Assertions.assertThrows(NullPointerException.class, pushReader::close);
    }
    
}