package jchess.server;

import jchess.network.gamemessages.MoveCoordinates;
import jchess.network.gamemessages.Settings;
import net.jodah.concurrentunit.Waiter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.function.BiConsumer;
import java.util.function.Function;

class NetworkGameMessageHubTest {
    
    private static class ErrorRaisingParticipantMock implements Participant {
        @Override
        public String getNick() {
            return null;
        }
        
        @Override
        public void sendChatMessage(Participant originator, String message) throws IOException {
            throw new IOException();
        }
        
        @Override
        public void sendErrorConnection() {
        }
        
        @Override
        public void sendMove(MoveCoordinates move) {
        }
        
        @Override
        public void sendSettings(Settings settings) {
        }
        
        @Override
        public void sendUndoAsk() {
        }
        
        @Override
        public void sendUndoPositive() {
        }
        
        @Override
        public void sendUndoNegative() {
        }
    
        @Override
        public void setGameMessageHub(GameMessageHub hub) {
        }
    
    }
    
    private static class RecordingParticipantMock implements Participant {
        
        private String chatMessage = null;
        private boolean errorConnection = false;
        private MoveCoordinates move = null;
        private boolean undoAsk = false;
        private boolean undoNegative = false;
        private boolean undoPositive = false;
        
        @Override
        public String getNick() {
            return null;
        }
        
        @Override
        public void sendChatMessage(Participant originator, String message) {
            chatMessage = message;
        }
        
        @Override
        public void sendErrorConnection() {
            errorConnection = true;
        }
        
        @Override
        public void sendMove(MoveCoordinates move) {
            this.move = move;
        }
        
        @Override
        public void sendSettings(Settings settings) {
        }
        
        @Override
        public void sendUndoAsk() {
            this.undoAsk = true;
        }
        
        @Override
        public void sendUndoNegative() {
            this.undoNegative = true;
        }
    
        @Override
        public void setGameMessageHub(GameMessageHub hub) {
        
        }
    
        @Override
        public void sendUndoPositive() {
            this.undoPositive = true;
        }
        
    }
    
    /**
     * Setup a NetworkGameMessageHub having one target, that will throw an IOException.
     * It is checked whether the ConnectionErrorListener registered to the NetworkGameMessageHub is notified.
     */
    @Test
    void addConnectionExceptionListener() throws Throwable {
        NetworkGameMessageHub distributor = new NetworkGameMessageHub();
        distributor.addTarget(new ErrorRaisingParticipantMock());
        
        Waiter waiter = new Waiter();
        distributor.addConnectionExceptionListener((originator, e) -> waiter.resume());
        distributor.sendChatMessage(null, "");
        waiter.await();
    }
    
    @Test
    void sendChatMessage() {
        String message = "a";
        
        doTest((distributor, originator) -> distributor.sendChatMessage(originator, message), mock -> mock.chatMessage, null, message);
    }
    
    @Test
    void sendConnectionExceptionOccurred() {
        doTest(GameMessageHub::sendConnectionExceptionOccurred, mock -> mock.errorConnection, false, true);
    }
    
    @Test
    void sendMove() {
        MoveCoordinates message = new MoveCoordinates(1, 2, 3, 4);
        
        doTest((distributor, originator) -> distributor.sendMove(originator, message), mock -> mock.move, null, message);
    }
    
    @Test
    void sendUndoAsk() {
        doTest(GameMessageHub::sendUndoAsk, mock -> mock.undoAsk, false, true);
    }
    
    @Test
    void sendUndoNegative() {
        doTest(GameMessageHub::sendUndoNegative, mock -> mock.undoNegative, false, true);
    }
    
    @Test
    void sendUndoPositive() {
        doTest(GameMessageHub::sendUndoPositive, mock -> mock.undoPositive, false, true);
    }
    
    /**
     * Two targets are added to a NetworkGameMessageHub.
     * Only the first target sends the message (sendFunction) to the distributor.
     */
    private void doTest(BiConsumer<GameMessageHub, Participant> sendFunction, Function<RecordingParticipantMock, Object> mockElement, Object expected1, Object expected2) {
        RecordingParticipantMock participant1 = new RecordingParticipantMock();
        RecordingParticipantMock participant2 = new RecordingParticipantMock();
        NetworkGameMessageHub distributor = new NetworkGameMessageHub();
        distributor.addTarget(participant1);
        distributor.addTarget(participant2);
        
        sendFunction.accept(distributor, participant1);
        
        Assertions.assertEquals(expected1, mockElement.apply(participant1));
        Assertions.assertEquals(expected2, mockElement.apply(participant2));
    }
}