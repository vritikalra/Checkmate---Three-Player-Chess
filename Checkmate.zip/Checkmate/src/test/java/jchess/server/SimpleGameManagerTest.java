package jchess.server;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SimpleGameManagerTest {
    
    @Test
    void getGame() throws GameManager.BadGameIdException {
        GameManager gameManager = new SimpleGameManager();
        gameManager.createGame(1, "", true, true);
        gameManager.createGame(2, "", true, true);
        gameManager.createGame(3, "", true, true);
        Assertions.assertNotNull(gameManager.getGame(1));
        Assertions.assertThrows(GameManager.BadGameIdException.class, () -> gameManager.getGame(4));
    }
    
    @Test
    void createGame() throws GameManager.BadGameIdException {
        GameManager gameManager = new SimpleGameManager();
    
        gameManager.createGame(1, "", true, true);
        Assertions.assertEquals(1, gameManager.getGames().size());
    
        Assertions.assertThrows(GameManager.BadGameIdException.class, () -> gameManager.createGame(1, "", true, true));
        Assertions.assertEquals(1, gameManager.getGames().size());
    }
    
}