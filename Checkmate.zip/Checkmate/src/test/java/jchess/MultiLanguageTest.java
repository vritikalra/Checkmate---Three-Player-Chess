package jchess;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * Tests existence of resource bundle and ability to resolve it.
 * It uses the knowledge that MultiLanguage.get(key) will return
 * the key if the key was not found inside the resource bundle.
 */
class MultiLanguageTestIT {
    
    @Test
    void get_KeyIsPresent() {
        String key = "local_game";
        String expressionInCurrentLanguage = MultiLanguage.get(key);
        Assertions.assertNotEquals(key, expressionInCurrentLanguage);
    }
    
    @Test
    void get_KeyIsMissing() {
        String key = "This key is not present in the multi-language resource bundle.";
        String expressionInCurrentLanguage = MultiLanguage.get(key);
        Assertions.assertEquals(key, expressionInCurrentLanguage);
    }
    
}